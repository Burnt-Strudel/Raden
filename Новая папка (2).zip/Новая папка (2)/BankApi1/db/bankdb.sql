-- Fixed init script for banking_db
-- Includes CREATE TABLE + original data

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `role` enum('client','manager') NOT NULL DEFAULT 'client',
  `status` enum('active','blocked','deleted') NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for clients
-- ----------------------------
DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `passport_number` varchar(20) DEFAULT NULL,
  `address` text,
  `date_of_birth` date DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `passport_number` (`passport_number`),
  CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for accounts
-- ----------------------------
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_number` varchar(20) NOT NULL,
  `user_id` int NOT NULL,
  `account_type` enum('regular','savings') NOT NULL DEFAULT 'regular',
  `balance` decimal(15,2) NOT NULL DEFAULT '0.00',
  `currency` enum('RUB','USD','EUR') NOT NULL DEFAULT 'RUB',
  `status` enum('active','frozen','closed') NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `accounts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for applications
-- ----------------------------
DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `description` text,
  `processed_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `processed_by` (`processed_by`),
  CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `applications_ibfk_2` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for deposits
-- ----------------------------
DROP TABLE IF EXISTS `deposits`;
CREATE TABLE `deposits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `interest_rate` decimal(5,2) NOT NULL DEFAULT '5.00',
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','closed','matured') DEFAULT 'active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `deposits_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for freeze_requests
-- ----------------------------
DROP TABLE IF EXISTS `freeze_requests`;
CREATE TABLE `freeze_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `user_id` int NOT NULL,
  `reason` text,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `requested_by_manager` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `freeze_requests_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `freeze_requests_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for transactions
-- ----------------------------
DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `from_account_id` int DEFAULT NULL,
  `to_account_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `transaction_type` enum('deposit','withdrawal','transfer','interest','fee') NOT NULL,
  `status` enum('pending','completed','cancelled','rejected') DEFAULT 'completed',
  `description` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `from_account_id` (`from_account_id`),
  KEY `to_account_id` (`to_account_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`from_account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`to_account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `transactions_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for operation_history
-- ----------------------------
DROP TABLE IF EXISTS `operation_history`;
CREATE TABLE `operation_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `action` varchar(100) NOT NULL,
  `details` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `operation_history_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`),
  CONSTRAINT `operation_history_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Data
-- ----------------------------

LOCK TABLES `users` WRITE;
INSERT INTO `users` (`id`,`username`,`password_hash`,`email`,`phone`,`first_name`,`last_name`,`role`,`status`) VALUES
(1,'client1','qwe123','client1@example.com','+79161234567','Иван','Иванов','client','active'),
(2,'client2','asd123','client2@example.com','+79162345678','Мария','Петрова','client','active'),
(3,'manager1','manager','manager1@bank.ru','+79169876543','Алексей','Сидоров','manager','active'),
(4,'aidares','qwerty','','','Радмир','Сальманов','client','active'),
(5,'ivan','qwerty123','ivan_289@bank.ru','+79998137494','Иван','Иванов','client','active'),
(6,'qwe','qwe12345','qwe_778@bank.ru','+79999477860','Радмир','Сальманов','client','active'),
(7,'qweqwe','qweqwe','qweqwe_978@bank.ru','+79993140045','qwe','qwe','client','active');
UNLOCK TABLES;

LOCK TABLES `clients` WRITE;
INSERT INTO `clients` (`id`,`user_id`,`passport_number`,`address`,`date_of_birth`) VALUES
(1,1,'1234567890','Москва, ул. Ленина 10','1995-03-15'),
(2,2,'0987654321','Санкт-Петербург, Невский 25','1998-07-22'),
(3,3,'5432107896','Уфа, ул. Кирова 65\\2','2000-01-01');
UNLOCK TABLES;

LOCK TABLES `accounts` WRITE;
INSERT INTO `accounts` (`id`,`account_number`,`user_id`,`account_type`,`balance`,`currency`,`status`) VALUES
(1,'40817810000000000001',1,'regular',0.00,'RUB','closed'),
(2,'40817810000000000002',1,'savings',0.00,'RUB','closed'),
(3,'40817810000000000003',2,'regular',8500.00,'RUB','active'),
(4,'40820810000008322471',1,'savings',0.00,'RUB','closed'),
(5,'40820810000006682001',1,'savings',0.00,'RUB','closed'),
(6,'40817810000007547894',4,'regular',160000.00,'RUB','active'),
(7,'40820810000004242264',4,'savings',5000.00,'RUB','active'),
(8,'40820810000003690241',1,'savings',0.00,'RUB','closed'),
(9,'40817810000006414245',5,'regular',0.00,'RUB','closed'),
(10,'40820810000001290871',1,'savings',0.00,'RUB','frozen'),
(11,'40817810000003796236',6,'regular',0.00,'RUB','closed'),
(12,'40820810000004444896',6,'savings',0.00,'RUB','closed'),
(13,'40820810000008315266',6,'savings',0.00,'RUB','active'),
(14,'40817810000005103277',7,'regular',0.00,'RUB','active'),
(15,'40820810000005604037',7,'savings',0.00,'RUB','active'),
(16,'40820810000005746911',1,'savings',0.00,'RUB','active');
UNLOCK TABLES;

LOCK TABLES `applications` WRITE;
INSERT INTO `applications` (`id`,`user_id`,`type`,`status`,`description`) VALUES
(1,1,'account_open','approved','Открытие накопительного счета'),
(2,2,'card_issue','pending','Выпуск дебетовой карты'),
(3,1,'account_open','approved','Открытие накопительного счета пользователя через приложение'),
(4,1,'account_open','approved','Открытие накопительного счета пользователя через приложение'),
(5,4,'account_open','approved','Открытие накопительного счета пользователя через приложение'),
(6,1,'account_open','approved','Открытие накопительного счета пользователя через приложение'),
(7,1,'account_open','approved','Открытие накопительного счета пользователя через приложение'),
(8,6,'account_open','approved','Открытие накопительного счета пользователя через приложение'),
(9,6,'account_open','approved','Открытие накопительного счета пользователя через приложение'),
(10,7,'account_open','approved','Открытие накопительного счета пользователя через приложение'),
(11,1,'account_open','approved','Открытие накопительного счета пользователя через приложение');
UNLOCK TABLES;

LOCK TABLES `deposits` WRITE;
INSERT INTO `deposits` (`id`,`account_id`,`amount`,`interest_rate`,`start_date`,`end_date`,`status`) VALUES
(1,4,0.00,5.00,'2026-06-24',NULL,'active'),
(2,5,0.00,5.00,'2026-06-24',NULL,'active'),
(3,7,0.00,5.00,'2026-06-24',NULL,'active'),
(4,8,0.00,5.00,'2026-06-24',NULL,'active'),
(5,10,0.00,5.00,'2026-06-25',NULL,'active'),
(6,12,0.00,5.00,'2026-06-25',NULL,'active'),
(7,13,0.00,5.00,'2026-06-25',NULL,'active'),
(8,15,0.00,5.00,'2026-09-07',NULL,'active'),
(9,16,0.00,5.00,'2026-09-16',NULL,'active');
UNLOCK TABLES;

LOCK TABLES `freeze_requests` WRITE;
INSERT INTO `freeze_requests` (`id`,`account_id`,`user_id`,`reason`,`status`,`requested_by_manager`) VALUES
(1,1,1,'Подозрительная активность','approved',3),
(2,2,1,'Запрос пользователя на блокировку счета','rejected',3),
(3,10,1,'Запрос пользователя на блокировку счета','approved',3),
(4,2,1,'Запрос пользователя на блокировку счета','pending',NULL);
UNLOCK TABLES;

LOCK TABLES `transactions` WRITE;
INSERT INTO `transactions` (`id`,`from_account_id`,`to_account_id`,`user_id`,`amount`,`transaction_type`,`status`,`description`) VALUES
(1,1,NULL,1,5000.00,'deposit','completed','Пополнение наличными'),
(2,NULL,1,1,3000.00,'withdrawal','completed','Снятие в банкомате'),
(3,1,3,1,15000.00,'transfer','completed','Перевод другу'),
(4,2,NULL,1,6000.00,'interest','completed','Начисление процентов по вкладу'),
(5,1,6,1,5000.00,'transfer','completed','Перевод клиенту на счет 40817810000007547894'),
(6,2,6,1,50000.00,'transfer','completed','[Ожидает одобрения (>10к)] Перевод клиенту на счет 40817810000007547894'),
(7,6,7,4,5000.00,'transfer','completed','Перевод клиенту на счет 40820810000004242264'),
(8,2,1,1,60000.00,'transfer','pending','[Ожидает одобрения (>10к)] Перевод клиенту на счет 40817810000000000001'),
(9,2,9,1,5000.00,'transfer','completed','Перевод клиенту на счет 40817810000006414245'),
(10,9,1,5,5000.00,'transfer','completed','Перевод клиенту на счет 40817810000000000001'),
(11,2,1,1,15000.00,'transfer','completed','[Ожидает одобрения (>10к)] Перевод клиенту на счет 40817810000000000001'),
(12,1,2,1,15000.00,'transfer','rejected','[Ожидает одобрения (>10к)] Перевод клиенту на счет 40817810000000000002'),
(13,1,6,1,5000.00,'transfer','completed','Перевод клиенту на счет 40817810000007547894'),
(14,1,6,1,20000.00,'transfer','rejected','[Ожидает одобрения (>10к)] Перевод клиенту на счет 40817810000007547894'),
(15,2,1,1,50000.00,'transfer','completed','[Ожидает одобрения (>10к)] Перевод клиенту на счет 40817810000000000001'),
(16,1,6,1,105000.00,'transfer','completed','[Ожидает одобрения (>10к)] Перевод клиенту на счет 40817810000007547894');
UNLOCK TABLES;

LOCK TABLES `operation_history` WRITE;
INSERT INTO `operation_history` (`id`,`transaction_id`,`user_id`,`action`,`details`) VALUES
(1,1,1,'Пополнение счета','Сумма: 5000 RUB'),
(2,3,1,'Перевод средств','Переведено 15000 RUB на счет 40817810000000000003');
UNLOCK TABLES;

SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
