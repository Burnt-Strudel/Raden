﻿using System;
using System.Collections.Generic;

namespace BankApi.Models;

public partial class Account
{
    public int Id { get; set; }

    public string AccountNumber { get; set; } = null!;

    public int UserId { get; set; }

    public string AccountType { get; set; } = null!;

    public decimal Balance { get; set; }

    public string Currency { get; set; } = null!;

    public string Status { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<Deposit> Deposits { get; set; } = new List<Deposit>();

    public virtual ICollection<FreezeRequest> FreezeRequests { get; set; } = new List<FreezeRequest>();

    public virtual ICollection<Transaction> TransactionFromAccounts { get; set; } = new List<Transaction>();

    public virtual ICollection<Transaction> TransactionToAccounts { get; set; } = new List<Transaction>();

    public virtual User User { get; set; } = null!;
}
