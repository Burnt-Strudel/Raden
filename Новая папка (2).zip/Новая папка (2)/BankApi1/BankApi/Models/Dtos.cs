namespace BankApi.Models
{
    public record LoginDto(string Username, string Password);
    public record RegisterDto(string Username, string Password, string Email, string FirstName, string LastName, string Phone);
    public record TransferDto(int FromAccountId, string TargetAccountNumber, decimal Amount, string Description);
    public record ManagerActionDto(int RequestId, bool Approve, int ManagerUserId);

    public sealed class PhoneRecipientDto
    {
        public int UserId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public int AccountId { get; set; }
        public string AccountNumber { get; set; } = string.Empty;
        public string AccountType { get; set; } = string.Empty;
    }

    public sealed class TransferByPhoneDto
    {
        public int FromAccountId { get; set; }
        public string Phone { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string? Description { get; set; }
    }

    public sealed class TransferResultDto
    {
        public bool RequiresApproval { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}
