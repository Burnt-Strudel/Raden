using System.Windows;

namespace BankingApp
{
    public partial class AuthWindow : Window
    {
        public AuthWindow() => InitializeComponent();

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            new LoginWindow().Show();
            Close();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            new RegisterWindow().Show();
            Close();
        }

        private void BtnGuest_Click(object sender, RoutedEventArgs e)
        {
            new GuestWindow().Show();
            Close();
        }
    }
}
