using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using BankingApp.Models;

namespace BankingApp
{
    public partial class TransferWindow : Window
    {
        private readonly MainClientWindow _parent;
        private PhoneRecipientResponse? _recipient;
        private bool _isBusy;

        public TransferWindow(MainClientWindow parent)
        {
            InitializeComponent();
            _parent = parent;

            if (_parent.SelectedAccount == null)
            {
                Loaded += (_, _) =>
                {
                    BankMessageBox.Show("Сначала выберите счёт, с которого будут списаны деньги.", "Перевод");
                    Close();
                };
                return;
            }

            TxtFrom.Text = $"Счёт: {_parent.SelectedAccount.AccountNumber}\n" +
                           $"Доступно: {_parent.SelectedAccount.Balance:N2} ₽";
        }

        private static string? NormalizeRussianPhone(string? value)
        {
            if (string.IsNullOrWhiteSpace(value) || value.Contains('@'))
                return null;

            string digits = new(value.Where(char.IsDigit).ToArray());
            if (digits.Length == 10)
                digits = "7" + digits;
            else if (digits.Length == 11 && digits[0] == '8')
                digits = "7" + digits[1..];

            return digits.Length == 11 && digits[0] == '7' ? "+" + digits : null;
        }

        private void TxtPhone_TextChanged(object sender, TextChangedEventArgs e)
        {
            _recipient = null;
            if (RecipientPanel != null)
                RecipientPanel.Visibility = Visibility.Collapsed;
            if (BtnSend != null)
                BtnSend.IsEnabled = false;
        }

        private async void BtnFindRecipient_Click(object sender, RoutedEventArgs e)
        {
            if (_isBusy) return;

            string? phone = NormalizeRussianPhone(TxtPhone.Text);
            if (phone == null)
            {
                BankMessageBox.Show(TxtPhone.Text.Contains('@')
                    ? "Введите номер телефона, а не Email."
                    : "Введите корректный российский номер. Пример: +79991234567",
                    "Проверка телефона");
                return;
            }

            TxtPhone.Text = phone;
            BtnSend.IsEnabled = false;
            RecipientPanel.Visibility = Visibility.Collapsed;
            SetBusy(true);

            try
            {
                var lookup = await ApiClient.FindRecipientByPhoneDetailedAsync(phone);
                _recipient = lookup.Recipient;

                if (_recipient == null)
                {
                    BankMessageBox.Show(
                        string.IsNullOrWhiteSpace(lookup.Error)
                            ? "Пользователь с таким номером не найден или у него нет активного счёта."
                            : "Не удалось найти получателя.\n\n" + lookup.Error,
                        "Поиск получателя");
                    return;
                }

                if (_parent.SelectedAccount != null && _recipient.UserId == _parent.SelectedAccount.UserId)
                {
                    _recipient = null;
                    BankMessageBox.Show("Нельзя переводить деньги самому себе.", "Перевод");
                    return;
                }

                TxtRecipient.Text =
                    $"{_recipient.FirstName} {_recipient.LastName}\n" +
                    $"Телефон: {_recipient.Phone}\n" +
                    $"Счёт: {_recipient.AccountNumber}" +
                    (string.IsNullOrWhiteSpace(_recipient.AccountType) ? "" : $"\nТип счёта: {_recipient.AccountType}");

                RecipientPanel.Visibility = Visibility.Visible;
                BtnSend.IsEnabled = true;
            }
            catch (Exception ex)
            {
                _recipient = null;
                BankMessageBox.Show("Ошибка поиска получателя: " + ex.Message, "Ошибка");
            }
            finally
            {
                SetBusy(false);
            }
        }

        private async void BtnSend_Click(object sender, RoutedEventArgs e)
        {
            if (_isBusy) return;
            if (_recipient == null || _parent.SelectedAccount == null)
            {
                BankMessageBox.Show("Сначала найдите получателя.", "Перевод");
                return;
            }

            string amountText = TxtSum.Text.Trim().Replace(',', '.');
            if (!decimal.TryParse(amountText, NumberStyles.AllowDecimalPoint,
                    CultureInfo.InvariantCulture, out decimal amount) || amount <= 0)
            {
                BankMessageBox.Show("Введите положительную сумму. Например: 1500 или 1500,50.", "Проверка суммы");
                return;
            }

            if (amount > _parent.SelectedAccount.Balance)
            {
                BankMessageBox.Show("Недостаточно средств на выбранном счёте.", "Перевод");
                return;
            }

            

            bool confirmed = BankMessageBox.ShowConfirm(
                $"Получатель: {_recipient.FirstName} {_recipient.LastName}\n" +
                $"Телефон: {_recipient.Phone}\nСчёт: {_recipient.AccountNumber}\n" +
                $"Сумма: {amount:N2} ₽\n\nПодтвердить перевод?",
                "Подтверждение перевода");
            if (!confirmed) return;

            SetBusy(true);
            try
            {
                var request = new PhoneTransferRequest
                {
                    FromAccountId = _parent.SelectedAccount.Id,
                    Phone = _recipient.Phone,
                    Amount = amount,
                    Description = $"Перевод по телефону {_recipient.Phone}"
                };

                var result = await ApiClient.MakeTransferByPhoneAsync(request);
                if (!result.Success)
                {
                    BankMessageBox.Show(result.Error, "Перевод не выполнен");
                    return;
                }

                BankMessageBox.Show(
                    result.Result?.Message ?? "Сервер принял запрос на перевод.",
                    result.Result?.RequiresApproval == true ? "Ожидает одобрения" : "Перевод выполнен");
                _parent.RefreshData();
                Close();
            }
            catch (Exception ex)
            {
                BankMessageBox.Show("Ошибка соединения при переводе: " + ex.Message, "Ошибка");
            }
            finally
            {
                if (IsVisible) SetBusy(false);
            }
        }

        private void SetBusy(bool busy)
        {
            _isBusy = busy;
            BtnFind.IsEnabled = !busy;
            BtnSend.IsEnabled = !busy && _recipient != null;
            TxtPhone.IsEnabled = !busy;
            TxtSum.IsEnabled = !busy;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e) => Close();
    }
}
