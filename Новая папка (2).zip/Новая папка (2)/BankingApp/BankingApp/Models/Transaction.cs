﻿using System;

namespace BankingApp.Models
{
    public class Transaction
    {
        public int Id { get; set; }
        public int? FromAccountId { get; set; }
        public int? ToAccountId { get; set; }
        public int UserId { get; set; }
        public decimal Amount { get; set; }
        public string TransactionType { get; set; } = string.Empty; 
        public string Status { get; set; } = "completed"; 
        public string Description { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }
}
