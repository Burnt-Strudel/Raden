﻿namespace BankingApp.Models
{
    public class Account
    {
        public int Id { get; set; }
        public string AccountNumber { get; set; } = string.Empty;
        public int UserId { get; set; }
        public string AccountType { get; set; } = "regular"; 
        public decimal Balance { get; set; }
        public string Currency { get; set; } = "RUB";
        public string Status { get; set; } = "active"; 
    }
}
