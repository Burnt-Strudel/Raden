namespace BankingApp.Models
{
    // Клиентские DTO имеют отдельные имена, чтобы не конфликтовать
    // с DTO серверного проекта BankApi.Models.
    public sealed class PhoneRecipientResponse
    {
        public int UserId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public int AccountId { get; set; }
        public string AccountNumber { get; set; } = string.Empty;
        public string AccountType { get; set; } = string.Empty;
    }

    public sealed class PhoneTransferRequest
    {
        public int FromAccountId { get; set; }
        public string Phone { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Description { get; set; } = string.Empty;
    }

    public sealed class PhoneTransferResponse
    {
        public bool RequiresApproval { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}
