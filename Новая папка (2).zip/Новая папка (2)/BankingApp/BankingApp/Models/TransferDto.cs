﻿namespace BankingApp.Models
{
    public class TransferDto
    {
        public int FromAccountId { get; set; }
        public string TargetAccountNumber { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Description { get; set; } = string.Empty;
    }
}
