using System;
using System.Windows;
using BankingApp.Models;

namespace BankingApp
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        private async void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string first = TxtFirst.Text.Trim();
            string last = TxtLast.Text.Trim();
            string login = TxtUser.Text.Trim();
            string email = TxtEmail.Text.Trim();
            string phone = TxtPhone.Text.Trim();
            string password = TxtPass.Password;

            if (string.IsNullOrWhiteSpace(first) ||
                string.IsNullOrWhiteSpace(last) ||
                string.IsNullOrWhiteSpace(login) ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(phone) ||
                string.IsNullOrWhiteSpace(password))
            {
                BankMessageBox.Show("Заполните все поля регистрации.");
                return;
            }

            if (!email.Contains("@") || !email.Contains("."))
            {
                BankMessageBox.Show("Введите корректный Email.");
                return;
            }

            if (password.Length < 6)
            {
                BankMessageBox.Show("Пароль должен содержать минимум 6 символов.");
                return;
            }

            var user = new User
            {
                Username = login,
                FirstName = first,
                LastName = last,
                Email = email,
                Phone = phone
            };

            bool success = await ApiClient.RegisterAsync(user, password);
            if (success)
            {
                BankMessageBox.Show("Аккаунт успешно создан. Теперь войдите.");
                new LoginWindow().Show();
                Close();
            }
            else
            {
                BankMessageBox.Show("Ошибка регистрации. Проверьте данные и подключение к серверу.");
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            new AuthWindow().Show();
            Close();
        }
    }
}
