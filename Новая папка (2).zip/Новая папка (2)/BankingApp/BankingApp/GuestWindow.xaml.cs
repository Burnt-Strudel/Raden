﻿using System.Windows;

namespace BankingApp
{
    public partial class GuestWindow : Window
    {
        public GuestWindow() => InitializeComponent();
        private void BtnExit_Click(object sender, RoutedEventArgs e) { new AuthWindow().Show(); this.Close(); }
    }
}
