using System.Windows;

namespace BankingApp
{
    public partial class LoginWindow : Window
    {
        public LoginWindow() => InitializeComponent();

        private async void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            var user = await ApiClient.LoginAsync(TxtUser.Text.Trim(), TxtPass.Password.Trim());
            if (user != null)
            {
                if (user.Role == "manager")
                    new MainManagerWindow(user).Show();
                else
                    new MainClientWindow(user).Show();
                Close();
            }
            else
            {
                BankMessageBox.Show("Неверные данные или сервер недоступен.\nПроверьте, что Docker API запущен на порту 8080.");
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            new AuthWindow().Show();
            Close();
        }
    }
}
