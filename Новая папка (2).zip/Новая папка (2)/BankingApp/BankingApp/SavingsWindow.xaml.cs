﻿using System.Windows;

namespace BankingApp
{
    public partial class SavingsWindow : Window
    {
        private int _userId;
        public SavingsWindow(int userId) { InitializeComponent(); _userId = userId; }

        private async void BtnOpen_Click(object sender, RoutedEventArgs e)
        {
            if (await ApiClient.OpenSavingsAccountAsync(_userId))
            {
                BankMessageBox.Show("Накопительный счет успешно открыт!");
                this.Close();
            }
        }
    }
}
