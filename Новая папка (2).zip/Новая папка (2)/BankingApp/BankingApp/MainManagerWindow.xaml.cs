﻿using System.Collections.Generic;
using System.Windows;
using BankingApp.Models;

namespace BankingApp
{
    public partial class MainManagerWindow : Window
    {
        private User _manager;

        public MainManagerWindow(User manager)
        {
            InitializeComponent();
            _manager = manager;
            TxtManager.Text = $"Менеджер: {manager.FirstName} {manager.LastName}";
            LoadRequests();
        }

        private async void LoadRequests()
        {
            var response = await ApiClient.GetPendingActionsAsync();
            if (response == null) return;

            var allRequests = new List<ManagerRequestItem>();
            allRequests.AddRange(response.Transfers);
            allRequests.AddRange(response.Freezes);

            LstRequests.ItemsSource = allRequests;
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            new AuthWindow().Show();
            this.Close();
        }

        private async void Approve_Click(object sender, RoutedEventArgs e) => await HandleAction(true);
        private async void Reject_Click(object sender, RoutedEventArgs e) => await HandleAction(false);

        private async System.Threading.Tasks.Task HandleAction(bool approve)
        {
            if (LstRequests.SelectedItem is ManagerRequestItem selectedItem)
            {
                bool success = false;

                if (selectedItem.Type == "Transfer")
                {
                    success = await ApiClient.ProcessTransferAsync(selectedItem.Id, approve, _manager.Id);
                }
                else if (selectedItem.Type == "Freeze")
                {
                    success = await ApiClient.ProcessFreezeAsync(selectedItem.Id, approve, _manager.Id);
                }

                if (success)
                {
                    BankMessageBox.Show("Операция успешно обработана.");
                    LoadRequests(); 
                }
                else
                {
                    BankMessageBox.Show("Ошибка при обработке операции на сервере.");
                }
            }
            else
            {
                BankMessageBox.Show("Пожалуйста, выберите заявку из списка!");
            }
        }
    }
}
