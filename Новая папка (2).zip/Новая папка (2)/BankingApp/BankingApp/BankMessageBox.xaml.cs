﻿using System.Windows;

namespace BankingApp
{
    public partial class BankMessageBox : Window
    {
        public bool Result { get; private set; } = false;

        public BankMessageBox()
        {
            InitializeComponent();
        }

        public static void Show(string message, string title = "Уведомление")
        {
            var msgBox = new BankMessageBox();
            msgBox.TxtMessage.Text = message;
            msgBox.TxtTitle.Text = title.ToUpper();

            msgBox.BtnOk.Visibility = Visibility.Visible;
            msgBox.PanelConfirm.Visibility = Visibility.Collapsed;

            msgBox.ShowDialog();
        }

        public static bool ShowConfirm(string message, string title = "Подтверждение")
        {
            var msgBox = new BankMessageBox();
            msgBox.TxtMessage.Text = message;
            msgBox.TxtTitle.Text = title.ToUpper();

            msgBox.BtnOk.Visibility = Visibility.Collapsed;
            msgBox.PanelConfirm.Visibility = Visibility.Visible;

            msgBox.ShowDialog();
            return msgBox.Result;
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e) => this.Close();

        private void BtnYes_Click(object sender, RoutedEventArgs e)
        {
            Result = true;
            this.Close();
        }

        private void BtnNo_Click(object sender, RoutedEventArgs e)
        {
            Result = false;
            this.Close();
        }
    }
}
