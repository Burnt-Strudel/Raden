using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using BankingApp.Models;

namespace BankingApp
{
    public partial class TransactionHistoryWindow : Window
    {
        private List<Transaction> _allTransactions = new List<Transaction>();
        private int _userId;

        public TransactionHistoryWindow(int userId)
        {
            InitializeComponent();
            _userId = userId;
            LoadHistory();
        }

        private async void LoadHistory()
        {
            CmbType.ItemsSource = new List<string> { "Все", "Пополнения", "Снятия", "Переводы", "Проценты", "Комиссии" };
            CmbType.SelectedIndex = 0;

            CmbPeriod.ItemsSource = new List<string> { "Все время", "Неделя", "Месяц", "Год" };
            CmbPeriod.SelectedIndex = 0;

            _allTransactions = await ApiClient.GetTransactionsAsync(_userId);

            ApplyFilters();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void FilterChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_allTransactions != null)
            {
                ApplyFilters();
            }
        }

        private void ApplyFilters()
        {
            var filtered = _allTransactions.AsEnumerable();

            if (CmbType.SelectedItem is string selectedType && selectedType != "Все")
            {
                string dbType = selectedType switch
                {
                    "Пополнения" => "deposit",
                    "Снятия" => "withdrawal",
                    "Переводы" => "transfer",
                    "Проценты" => "interest",
                    "Комиссии" => "fee",
                    _ => ""
                };

                filtered = filtered.Where(t => t.TransactionType.Equals(dbType, StringComparison.OrdinalIgnoreCase));
            }

            if (CmbPeriod.SelectedItem is string selectedPeriod && selectedPeriod != "Все время")
            {
                DateTime now = DateTime.Now;
                filtered = selectedPeriod switch
                {
                    "Неделя" => filtered.Where(t => t.CreatedAt >= now.AddDays(-7)),
                    "Месяц" => filtered.Where(t => t.CreatedAt >= now.AddMonths(-1)),
                    "Год" => filtered.Where(t => t.CreatedAt >= now.AddYears(-1)),
                    _ => filtered
                };
            }

            GridHistory.ItemsSource = filtered.ToList();
        }
    }
}
