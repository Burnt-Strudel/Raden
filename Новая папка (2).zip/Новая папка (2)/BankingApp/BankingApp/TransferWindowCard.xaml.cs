using System;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using BankingApp.Models;

namespace BankingApp
{
    public partial class TransferWindowCard : Window
    {
        private readonly MainClientWindow _parent;
        private bool _busy;

        public TransferWindowCard(MainClientWindow parent)
        {
            InitializeComponent();
            _parent = parent;

            if (_parent.SelectedAccount == null)
            {
                Loaded += (_, _) => Close();
                return;
            }

            TxtFrom.Text =
                $"Счёт: {_parent.SelectedAccount.AccountNumber}\n" +
                $"Доступно: {_parent.SelectedAccount.Balance:N2} ₽";
        }

        private async void BtnSend_Click(object sender, RoutedEventArgs e)
        {
            if (_busy)
                return;

            var account = _parent.SelectedAccount;
            if (account == null)
                return;

            // В текущей схеме БД получатель идентифицируется AccountNumber,
            // а не номером банковской карты. Удаляем только разделители.
            string targetAccountNumber = new string(
                TxtTarget.Text.Where(char.IsDigit).ToArray());

            if (string.IsNullOrWhiteSpace(targetAccountNumber) || targetAccountNumber.Length > 20)
            {
                BankMessageBox.Show(
                    "Введите номер банковского счёта получателя (до 20 цифр).",
                    "Проверка реквизитов");
                return;
            }

            string amountText = TxtSum.Text.Trim().Replace(',', '.');
            if (!decimal.TryParse(amountText, NumberStyles.AllowDecimalPoint,
                    CultureInfo.InvariantCulture, out decimal amount) || amount <= 0)
            {
                BankMessageBox.Show("Введите корректную сумму перевода.", "Ошибка");
                return;
            }

            if (decimal.Round(amount, 2) != amount)
            {
                BankMessageBox.Show("Сумма не может содержать больше двух знаков после запятой.", "Ошибка");
                return;
            }

            if (amount > account.Balance)
            {
                BankMessageBox.Show("Недостаточно средств на выбранном счёте.", "Ошибка");
                return;
            }

            bool confirm = BankMessageBox.ShowConfirm(
                $"Счёт получателя: {targetAccountNumber}\n" +
                $"Сумма: {amount:N2} ₽\n\nПодтвердить перевод?",
                "Подтверждение перевода");

            if (!confirm)
                return;

            _busy = true;
            BtnSend.IsEnabled = false;

            try
            {
                var dto = new TransferDto
                {
                    FromAccountId = account.Id,
                    TargetAccountNumber = targetAccountNumber,
                    Amount = amount,
                    Description = $"Перевод на счёт {targetAccountNumber}"
                };

                var result = await ApiClient.MakeTransferDetailedAsync(dto);

                if (!result.Success)
                {
                    BankMessageBox.Show(result.Message, "Перевод не выполнен");
                    return;
                }

                BankMessageBox.Show(
                    string.IsNullOrWhiteSpace(result.Message)
                        ? "Перевод обработан сервером."
                        : result.Message,
                    result.RequiresApproval ? "Перевод ожидает подтверждения" : "Успешно");

                await _parent.RefreshDataAsync();
                Close();
            }
            catch (Exception ex)
            {
                BankMessageBox.Show("Не удалось выполнить перевод: " + ex.Message, "Ошибка");
            }
            finally
            {
                _busy = false;
                if (IsVisible)
                    BtnSend.IsEnabled = true;
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
