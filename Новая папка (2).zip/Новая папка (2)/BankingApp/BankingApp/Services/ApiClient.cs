﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using BankingApp.Models;

public static class ApiClient
{
    private static readonly HttpClient client = new HttpClient
    {
        BaseAddress = new Uri("http://localhost:8080/api/") 
    };

    public static async Task<User?> LoginAsync(string username, string password)
    {
        var response = await client.PostAsJsonAsync("auth/login", new { Username = username, Password = password });
        return response.IsSuccessStatusCode ? await response.Content.ReadFromJsonAsync<User>() : null;
    }

    public static async Task<bool> RegisterAsync(User user, string password)
    {
        var dto = new
        {
            user.Username,
            Password = password,
            user.Email,
            user.FirstName,
            user.LastName,
            user.Phone
        };

        var response = await client.PostAsJsonAsync("auth/register", dto);
        return response.IsSuccessStatusCode;
    }


    public static async Task<List<Account>> GetAccountsAsync(int userId)
    {
        var response = await client.GetAsync($"accounts/{userId}");
        return response.IsSuccessStatusCode ? await response.Content.ReadFromJsonAsync<List<Account>>() ?? new() : new();
    }

    public static async Task<bool> MakeTransferAsync(TransferDto dto)
    {
        var result = await MakeTransferDetailedAsync(dto);
        return result.Success;
    }

    public static async Task<(bool Success, bool RequiresApproval, string Message)> MakeTransferDetailedAsync(TransferDto dto)
    {
        try
        {
            using var response = await client.PostAsJsonAsync("accounts/transfer", dto);
            string body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                return (false, false, FormatApiError((int)response.StatusCode, body));

            if (string.IsNullOrWhiteSpace(body))
                return (true, false, "Перевод успешно обработан сервером.");

            try
            {
                using var document = System.Text.Json.JsonDocument.Parse(body);
                var root = document.RootElement;
                bool approval = root.ValueKind == System.Text.Json.JsonValueKind.Object &&
                    root.TryGetProperty("requiresApproval", out var approvalValue) &&
                    approvalValue.ValueKind == System.Text.Json.JsonValueKind.True;
                string message = root.ValueKind == System.Text.Json.JsonValueKind.Object &&
                    root.TryGetProperty("message", out var messageValue) &&
                    messageValue.ValueKind == System.Text.Json.JsonValueKind.String
                        ? messageValue.GetString() ?? string.Empty
                        : "Перевод успешно обработан сервером.";
                return (true, approval, message);
            }
            catch (System.Text.Json.JsonException)
            {
                return (true, false, "Перевод успешно обработан сервером.");
            }
        }
        catch (HttpRequestException ex)
        {
            return (false, false, "Не удалось подключиться к API по адресу " + client.BaseAddress + ". " + ex.Message);
        }
        catch (TaskCanceledException)
        {
            return (false, false, "API не ответил вовремя. Проверьте, запущен ли сервер.");
        }
    }

    // Поиск выполняется через query-параметр: номер с "+" безопасно кодируется.
    public static async Task<(PhoneRecipientResponse? Recipient, string Error)> FindRecipientByPhoneDetailedAsync(string phone)
    {
        try
        {
            string encodedPhone = Uri.EscapeDataString(phone.Trim());
            using var response = await client.GetAsync($"accounts/recipient-by-phone?phone={encodedPhone}");
            string body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                return (null, FormatApiError((int)response.StatusCode, body));

            var recipient = System.Text.Json.JsonSerializer.Deserialize<PhoneRecipientResponse>(
                body,
                new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            return recipient == null
                ? (null, "Сервер вернул пустой ответ при поиске получателя.")
                : (recipient, string.Empty);
        }
        catch (HttpRequestException ex)
        {
            return (null, "Не удалось подключиться к API. Проверьте, запущен ли BankApi на http://localhost:5025. " + ex.Message);
        }
        catch (TaskCanceledException)
        {
            return (null, "Сервер не ответил вовремя. Попробуйте ещё раз.");
        }
        catch (Exception ex)
        {
            return (null, "Ошибка обработки ответа API: " + ex.Message);
        }
    }

    // Совместимость с существующими вызовами в проекте.
    public static async Task<PhoneRecipientResponse?> FindRecipientByPhoneAsync(string phone)
    {
        var result = await FindRecipientByPhoneDetailedAsync(phone);
        return result.Recipient;
    }

    private static string FormatApiError(int statusCode, string body)
    {
        if (string.IsNullOrWhiteSpace(body))
            return $"API вернул HTTP {statusCode}.";

        try
        {
            using var document = System.Text.Json.JsonDocument.Parse(body);
            foreach (string key in new[] { "message", "error", "title", "detail" })
                if (document.RootElement.ValueKind == System.Text.Json.JsonValueKind.Object &&
                    document.RootElement.TryGetProperty(key, out var value) &&
                    value.ValueKind == System.Text.Json.JsonValueKind.String)
                    return $"HTTP {statusCode}: {value.GetString()}";
        }
        catch { }

        return $"HTTP {statusCode}: {body.Trim().Trim('"')}";
    }

    public static async Task<(bool Success, PhoneTransferResponse? Result, string Error)> MakeTransferByPhoneAsync(PhoneTransferRequest dto)
    {
        using var response = await client.PostAsJsonAsync("accounts/transfer-by-phone", dto);
        if (response.IsSuccessStatusCode)
        {
            var result = await response.Content.ReadFromJsonAsync<PhoneTransferResponse>();
            return (true, result, string.Empty);
        }

        string error = await response.Content.ReadAsStringAsync();
        return (false, null, FormatApiError((int)response.StatusCode, error));
    }

    public static async Task<bool> RequestBlockAccountAsync(int accountId, int userId)
    {
        var response = await client.PostAsJsonAsync($"accounts/request-block/{accountId}/{userId}", new { });
        return response.IsSuccessStatusCode;
    }

    public static async Task<bool> DeleteAccountAsync(int accountId)
    {
        var response = await client.DeleteAsync($"accounts/{accountId}");
        return response.IsSuccessStatusCode;
    }

    public static async Task<bool> OpenRegularAccountAsync(int userId)
    {
        try
        {
            using var response = await client.PostAsync(
                $"accounts/regular/open/{userId}",
                null
            );

            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                "Ошибка открытия обычного счёта: " + ex.Message
            );

            return false;
        }
    }

    public static async Task<bool> OpenSavingsAccountAsync(int userId)
    {
        var response = await client.PostAsJsonAsync($"accounts/savings/open/{userId}", new { });
        return response.IsSuccessStatusCode;
    }

    public static async Task<List<Transaction>> GetTransactionsAsync(int userId)
    {
        var response = await client.GetAsync($"transactions/{userId}");
        return response.IsSuccessStatusCode ? await response.Content.ReadFromJsonAsync<List<Transaction>>() ?? new() : new();
    }


    public static async Task<ManagerRequestsResponse?> GetPendingActionsAsync()
    {
        var response = await client.GetAsync("manager/pending-actions");
        return response.IsSuccessStatusCode ? await response.Content.ReadFromJsonAsync<ManagerRequestsResponse>() : null;
    }

    public static async Task<bool> ProcessTransferAsync(int requestId, bool approve, int managerId)
    {
        var response = await client.PostAsJsonAsync("manager/process-transfer", new { RequestId = requestId, Approve = approve, ManagerUserId = managerId });
        return response.IsSuccessStatusCode;
    }

    public static async Task<bool> ProcessFreezeAsync(int requestId, bool approve, int managerId)
    {
        var response = await client.PostAsJsonAsync("manager/process-freeze", new { RequestId = requestId, Approve = approve, ManagerUserId = managerId });
        return response.IsSuccessStatusCode;
    }
}

public class ManagerRequestItem
{
    public int Id { get; set; }
    public string Type { get; set; } = string.Empty;
    public string Info { get; set; } = string.Empty;
}

public class ManagerRequestsResponse
{
    public List<ManagerRequestItem> Transfers { get; set; } = new();
    public List<ManagerRequestItem> Freezes { get; set; } = new();
}
