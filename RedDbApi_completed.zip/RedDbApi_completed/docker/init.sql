CREATE DATABASE IF NOT EXISTS reddb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE reddb;

CREATE TABLE IF NOT EXISTS institutions (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS groups_tbl (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  course INT NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'активна'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS students (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  fio VARCHAR(255) NOT NULL,
  group_id INT NULL,
  institution_id INT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'активен',
  CONSTRAINT fk_students_group FOREIGN KEY (group_id) REFERENCES groups_tbl(id) ON DELETE SET NULL,
  CONSTRAINT fk_students_institution FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE SET NULL,
  INDEX ix_students_group (group_id),
  INDEX ix_students_institution (institution_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS exams (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  subject VARCHAR(255) NOT NULL,
  exam_date DATETIME NULL,
  grade INT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'запланирован',
  CONSTRAINT fk_exams_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  INDEX ix_exams_student (student_id)
) ENGINE=InnoDB;
