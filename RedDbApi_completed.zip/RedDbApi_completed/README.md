# Учебная система — MySQL + ASP.NET Core API + Avalonia Desktop

Проект дополнен по заданию: REST API, Docker Compose для MySQL и API, настольный клиент Avalonia.

## Структура

- `RedDbApi/` — ASP.NET Core 8 Web API, EF Core и Pomelo MySQL provider.
- `RedDbDesktop/` — Avalonia Desktop-клиент.
- `docker-compose.yml` — запуск MySQL и API.
- `docker/init.sql` — структура пустой БД, создаваемая при первом старте MySQL.
- `docker/Dockerfile.api` — сборка и запуск API в контейнере.

## Запуск через Docker

Требуется установленный Docker Desktop (Windows/macOS) или Docker Engine + Compose (Linux).

В корне проекта выполните:

```bash
docker compose up --build -d
```

Проверка:
- Swagger API: http://localhost:5000/swagger
- API: http://localhost:5000/api/students
- MySQL с хоста: `localhost:3306`, база `reddb`, пользователь `reddb`, пароль `reddb123`.

Остановка:

```bash
docker compose down
```

Данные MySQL хранятся в Docker volume `mysql_data` и сохраняются после обычной остановки контейнеров. Чтобы удалить контейнеры **вместе со всеми данными БД**, используйте `docker compose down -v`.

> `docker/init.sql` запускается MySQL только при первичной инициализации пустого volume. Если volume уже существует, изменение SQL-файла само по себе не изменит существующую БД.

## Подключение к уже имеющейся базе данных

В архиве исходного проекта не было SQL-дампа или описания фактической схемы БД. Поэтому имена таблиц и колонок сохранены по имеющимся C# моделям:
- `institutions` (`id`, `name`)
- `groups_tbl` (`id`, `name`, `course`, `status`)
- `students` (`id`, `fio`, `group_id`, `institution_id`, `status`)
- `exams` (`id`, `student_id`, `subject`, `exam_date`, `grade`, `status`)

Для подключения API к существующей БД измените `ConnectionStrings:DefaultConnection` в `RedDbApi/appsettings.json` при локальном запуске. При запуске через Docker задайте переменную окружения `ConnectionStrings__DefaultConnection` в `docker-compose.yml`. Для контейнерного API адрес MySQL должен быть именем сервиса Docker (по умолчанию `db`), а не `localhost`.

Перед запуском сверьте имена и типы колонок вашей существующей БД с таблицей выше. Скрипт `docker/init.sql` предназначен для новой пустой БД и не должен запускаться поверх существующей базы с данными.

## Запуск Desktop

Desktop-клиент подключается к API по адресу `http://localhost:5000/`.

1. Сначала запустите Docker Compose и дождитесь готовности API.
2. Установите .NET 8 SDK.
3. Из корня проекта выполните:

```bash
dotnet run --project RedDbDesktop/RedDbDesktop.csproj
```

В приложении есть вкладки для студентов, групп, учебных заведений и экзаменов. На каждой вкладке доступны просмотр, добавление, изменение и удаление записей. Для связей указываются ID группы, учебного заведения и студента из соответствующих вкладок.

Если API размещён не на `localhost:5000`, измените `BaseAddress` в `RedDbDesktop/MainWindow.cs`.

## REST API

Для каждого ресурса доступны операции:
- `GET /api/students` и `GET /api/students/{id}`
- `POST /api/students`
- `PUT /api/students/{id}`
- `DELETE /api/students/{id}`

Аналогичные маршруты доступны для `groups`, `institutions`, `exams`.

Пример JSON для добавления студента:

```json
{
  "fio": "Иванов Иван Иванович",
  "groupId": 1,
  "institutionId": 1,
  "status": "активен"
}
```

Пример JSON для экзамена:

```json
{
  "studentId": 1,
  "subject": "Математика",
  "examDate": "2026-12-10T09:00:00",
  "grade": 5,
  "status": "сдан"
}
```

## Проверка

В среде подготовки архива не установлены .NET SDK и Docker, поэтому выполнить фактическую `dotnet build`, запуск контейнеров и интеграционные запросы здесь невозможно. Файлы проекта и конфигурации подготовлены, но окончательную проверку компиляции и подключения к вашей конкретной существующей БД нужно выполнить на машине с .NET 8 и Docker. Команды проверки:

```bash
dotnet build RedDbApi/RedDbApi.csproj
dotnet build RedDbDesktop/RedDbDesktop.csproj
docker compose config
docker compose up --build
```
