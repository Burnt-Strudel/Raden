import { PAGE_META } from './config.js';
import { clearSession, resetData, restoreSession, saveSession, state } from './state.js';
import { BankApi } from './api.js';
import { $, closeModal, copyText, toast, updateUserBlock } from './ui.js';
import {
    navigate,
    registerPages,
    renderPage,
    routeFromHash
} from './core/router.js';
import {
    setCoreDataChangedHandler,
    startCorePolling,
    stopCorePolling,
    stopQuotesPolling
} from './core/polling.js';
import { renderOverview } from './pages/overview.js';
import { confirmCloseAccount, openAccount, renderAccounts } from './pages/accounts.js';
import {
    changeOperationsPage,
    exportOperationsCsv,
    renderOperations,
    renderOperationsTable,
    resetOperationFilters,
    toggleOperationSort
} from './pages/operations.js';
import { renderTransfer, renderTransferArea } from './pages/transfer.js';
import {
    openFundModal,
    openInvestmentAccount,
    renderInvestments,
    renderQuoteTable,
    selectQuote,
    submitTrade,
    updateTradeTotal
} from './pages/investments.js';
import { renderAnalytics, renderAnalyticsContent } from './pages/analytics.js';
import { renderProfile } from './pages/profile.js';

document.addEventListener('DOMContentLoaded', init);

function init() {
    registerPages({
        overview: renderOverview,
        accounts: renderAccounts,
        operations: renderOperations,
        transfer: renderTransfer,
        investments: renderInvestments,
        analytics: renderAnalytics,
        profile: renderProfile
    });

    // Фоновое обновление данных перерисовывает только страницы, где это нужно.
    setCoreDataChangedHandler(() => renderPage(true));

    bindLoginScreen();
    bindShell();
    restoreSession();

    if (state.user) {
        showApp();
    }
}

function bindLoginScreen() {
    $('tab-login').addEventListener('click', () => switchAuthTab('login'));
    $('tab-register').addEventListener('click', () => switchAuthTab('register'));
    $('login-form').addEventListener('submit', handleLogin);
    $('register-form').addEventListener('submit', handleRegister);
}

function switchAuthTab(tab) {
    const isLogin = tab === 'login';
    $('tab-login').classList.toggle('active', isLogin);
    $('tab-register').classList.toggle('active', !isLogin);
    $('login-form').hidden = !isLogin;
    $('register-form').hidden = isLogin;
}

async function handleLogin(event) {
    event.preventDefault();
    const button = event.target.querySelector('button[type="submit"]');
    const errorBox = $('login-error');
    errorBox.hidden = true;
    button.disabled = true;
    button.textContent = 'Входим…';

    try {
        const user = await BankApi.login(
            $('login-username').value.trim(),
            $('login-password').value
        );
        state.user = user;
        saveSession();
        $('login-password').value = '';
        showApp();
    } catch (error) {
        errorBox.textContent = error.message;
        errorBox.hidden = false;
    } finally {
        button.disabled = false;
        button.textContent = 'Войти';
    }
}

async function handleRegister(event) {
    event.preventDefault();
    const button = event.target.querySelector('button[type="submit"]');
    const errorBox = $('register-error');
    errorBox.hidden = true;
    button.disabled = true;
    button.textContent = 'Создаём…';

    const username = $('reg-username').value.trim();

    try {
        await BankApi.register({
            username,
            password: $('reg-password').value,
            email: $('reg-email').value.trim(),
            firstName: $('reg-first-name').value.trim(),
            lastName: $('reg-last-name').value.trim(),
            phone: $('reg-phone').value.trim()
        });
        toast('Аккаунт создан. Войдите с новым логином.', 'success');
        switchAuthTab('login');
        $('login-username').value = username;
        $('login-password').focus();
        event.target.reset();
    } catch (error) {
        errorBox.textContent = error.message;
        errorBox.hidden = false;
    } finally {
        button.disabled = false;
        button.textContent = 'Зарегистрироваться';
    }
}

function showApp() {
    $('login-screen').hidden = true;
    $('app-shell').hidden = false;
    updateUserBlock();
    startCorePolling();

    const route = routeFromHash();
    if (!PAGE_META[route]) {
        location.hash = '#/overview';
    } else {
        navigate();
    }
}

function logout() {
    stopQuotesPolling();
    stopCorePolling();
    clearSession();
    resetData();
    $('app-shell').hidden = true;
    $('login-screen').hidden = false;
    history.replaceState(null, '', location.pathname + location.search);
    switchAuthTab('login');
    $('login-password').value = '';
}

function bindShell() {
    $('refresh-button').addEventListener('click', () => {
        if (state.user) renderPage();
    });

    $('logout-button').addEventListener('click', logout);

    $('page').addEventListener('click', handlePageClick);
    $('page').addEventListener('input', handlePageInput);
    $('page').addEventListener('change', handlePageChange);
    $('page').addEventListener('keydown', (event) => {
        if (event.key !== 'Enter' && event.key !== ' ') return;

        const target = event.target.closest('[data-action][tabindex="0"]');
        if (!target || target.tagName === 'A' || target.tagName === 'BUTTON') return;

        event.preventDefault();
        target.click();
    });

    $('modal-backdrop').addEventListener('click', (event) => {
        if (event.target === $('modal-backdrop')) closeModal();
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !$('modal-backdrop').hidden) {
            closeModal();
        }
    });

    window.addEventListener('hashchange', () => {
        if (state.user) navigate();
    });
}

function handlePageClick(event) {
    const actionElement = event.target.closest('[data-action]');
    if (!actionElement) return;

    const action = actionElement.dataset.action;

    switch (action) {
        case 'copy':
            copyText(actionElement.dataset.copy);
            break;
        case 'open-account':
            openAccount(actionElement.dataset.kind);
            break;
        case 'close-account':
            confirmCloseAccount(Number(actionElement.dataset.id));
            break;
        case 'sort-operations':
            toggleOperationSort(actionElement.dataset.key);
            break;
        case 'page-prev':
            changeOperationsPage(-1);
            break;
        case 'page-next':
            changeOperationsPage(1);
            break;
        case 'reset-filters':
            resetOperationFilters();
            break;
        case 'export-csv':
            exportOperationsCsv();
            break;
        case 'transfer-mode':
            state.transferMode = actionElement.dataset.mode;
            document.querySelectorAll('[data-action="transfer-mode"]').forEach((tab) => {
                tab.classList.toggle('active', tab.dataset.mode === state.transferMode);
            });
            renderTransferArea();
            break;
        case 'open-investment':
            openInvestmentAccount();
            break;
        case 'select-quote':
            selectQuote(Number(actionElement.dataset.id));
            break;
        case 'investment-kind':
            state.investmentKind = actionElement.dataset.kind;
            document.querySelectorAll('[data-action="investment-kind"]').forEach((tab) => {
                tab.classList.toggle('active', tab.dataset.kind === state.investmentKind);
            });
            renderQuoteTable();
            break;
        case 'buy':
            submitTrade(true);
            break;
        case 'sell':
            submitTrade(false);
            break;
        case 'fund':
            openFundModal();
            break;
        case 'logout':
            logout();
            break;
    }
}

function handlePageInput(event) {
    const target = event.target;

    if (target.id === 'trade-quantity') {
        updateTradeTotal();
        return;
    }

    if (target.id === 'filter-search') {
        state.operations.search = target.value;
        state.operations.page = 1;
        renderOperationsTable();
        return;
    }

    if (target.id === 'investment-search') {
        state.investmentSearch = target.value;
        renderQuoteTable();
    }
}

function handlePageChange(event) {
    const target = event.target;

    const filterMap = {
        'filter-account': 'accountId',
        'filter-type': 'type',
        'filter-sign': 'sign',
        'filter-from': 'from',
        'filter-to': 'to'
    };

    const key = filterMap[target.id];
    if (key) {
        state.operations[key] = target.value;
        state.operations.page = 1;
        renderOperationsTable();
        return;
    }

    if (target.id === 'analytics-month') {
        state.analyticsMonth = target.value;
        renderAnalyticsContent();
    }
}
