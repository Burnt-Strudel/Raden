import { state } from './state.js';
import { formatTime } from './format.js';

export const $ = (id) => document.getElementById(id);

let toastTimer = null;
let modalConfirming = false;
let lastFocusedElement = null;

export function updateUserBlock() {
    if (!state.user) return;
    const name = [state.user.firstName, state.user.lastName].filter(Boolean).join(' ') || state.user.username;
    $('user-name').textContent = name;
    $('user-login').textContent = state.user.username;
    $('user-avatar').textContent = name.trim().charAt(0).toUpperCase();
}

export function updateLastUpdated() {
    $('last-updated').textContent = 'Обновлено ' + formatTime();
}

export function toast(message, type = 'success') {
    const element = $('toast');
    element.textContent = message;
    element.className = 'toast ' + type;
    element.hidden = false;

    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
        element.hidden = true;
    }, 4200);
}

// Модалка с одной кнопкой подтверждения. Если onConfirm бросает ошибку,
// она показывается внутри модалки, а сама модалка остаётся открытой.
export function openModal({ title, bodyHtml, confirmText, cancelText = 'Отмена', danger = false, onConfirm }) {
    lastFocusedElement = document.activeElement;
    modalConfirming = false;
    $('modal-title').textContent = title;
    $('modal-body').innerHTML = bodyHtml;
    $('modal-actions').innerHTML =
        `<button type="button" class="button button-secondary" id="modal-cancel">${cancelText}</button>` +
        `<button type="button" class="button ${danger ? 'button-danger' : 'button-primary'}" id="modal-confirm">` +
            confirmText + '</button>';

    $('modal-cancel').addEventListener('click', () => {
        if (!modalConfirming) closeModal();
    });
    $('modal-confirm').addEventListener('click', async () => {
        if (modalConfirming) return;

        const button = $('modal-confirm');
        let errorBox = $('modal-body').querySelector('.form-error');
        if (!errorBox) {
            errorBox = document.createElement('div');
            errorBox.className = 'form-error';
            errorBox.setAttribute('role', 'alert');
            $('modal-body').appendChild(errorBox);
        }
        errorBox.hidden = true;

        modalConfirming = true;
        button.disabled = true;
        try {
            await onConfirm();
            modalConfirming = false;
            closeModal();
        } catch (error) {
            errorBox.textContent = error.message;
            errorBox.hidden = false;
            button.disabled = false;
            modalConfirming = false;
        }
    });

    $('modal-backdrop').hidden = false;
    $('modal').focus();
}

export function closeModal() {
    if (modalConfirming) return;

    $('modal-backdrop').hidden = true;
    $('modal-title').textContent = '';
    $('modal-body').innerHTML = '';
    $('modal-actions').innerHTML = '';
    modalConfirming = false;

    if (lastFocusedElement && document.contains(lastFocusedElement)) {
        lastFocusedElement.focus();
    }
    lastFocusedElement = null;
}

export async function copyText(text) {
    if (!text) return;

    try {
        await navigator.clipboard.writeText(String(text));
    } catch {
        const area = document.createElement('textarea');
        area.value = String(text);
        document.body.appendChild(area);
        area.select();
        document.execCommand('copy');
        document.body.removeChild(area);
    }

    toast('Скопировано: ' + text, 'success');
}

export function parseAmount(value) {
    return Number(String(value).trim().replace(',', '.'));
}
