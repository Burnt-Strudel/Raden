
const moneyFormatter = new Intl.NumberFormat('ru-RU', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
});

const quantityFormatter = new Intl.NumberFormat('ru-RU', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 4
});

const percentFormatter = new Intl.NumberFormat('ru-RU', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
});

function formatMoney(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return '0,00 ₽';
    return moneyFormatter.format(Math.abs(number) < 0.005 ? 0 : number) + ' ₽';
}

function plural(count, one, few, many) {
    const tail = Math.abs(Number(count)) % 100;
    const last = tail % 10;
    if (tail > 10 && tail < 20) return many;
    if (last === 1) return one;
    if (last >= 2 && last <= 4) return few;
    return many;
}

function formatQuantity(value) {
    const number = Number(value);
    return quantityFormatter.format(Number.isFinite(number) ? number : 0);
}

function formatPercent(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return '0,00%';
    const sign = number > 0 ? '+' : '';
    return sign + percentFormatter.format(number) + '%';
}

function formatDate(value) {
    if (!value) return '—';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '—';
    return date.toLocaleString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatTime(value) {
    const date = value ? new Date(value) : new Date();
    return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function monthKey(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '';
    const month = String(date.getMonth() + 1).padStart(2, '0');
    return date.getFullYear() + '-' + month;
}

function monthLabel(key) {
    const parts = String(key).split('-');
    const date = new Date(Number(parts[0]), Number(parts[1]) - 1, 1);
    return date.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' });
}

const ACCOUNT_TYPE_LABELS = {
    regular: 'Основной счёт',
    savings: 'Накопительный',
    investment: 'Инвестиционный счёт'
};

function accountTypeLabel(type) {
    return ACCOUNT_TYPE_LABELS[type] || type || 'Счёт';
}

function accountShortNumber(account) {
    const number = account && account.accountNumber ? String(account.accountNumber) : '';
    return number.length >= 4 ? '••' + number.slice(-4) : '••••';
}

function accountTitle(account) {
    if (!account) return 'Счёт';
    return accountTypeLabel(account.accountType) + ' ' + accountShortNumber(account);
}

function maskCardNumber(cardNumber) {
    const number = String(cardNumber || '');
    if (number.length < 8) return number || '—';
    return number.slice(0, 4) + ' •••• ' + number.slice(-4);
}

const TRANSACTION_TYPE_LABELS = {
    transfer: 'Перевод',
    investment: 'Инвестиции',
    deposit: 'Пополнение',
    withdrawal: 'Снятие',
    interest: 'Проценты',
    fee: 'Комиссия',
    income: 'Доход',
    expense: 'Расход'
};

function transactionTypeLabel(type) {
    return TRANSACTION_TYPE_LABELS[type] || type || 'Операция';
}

const STATUS_LABELS = {
    completed: 'Исполнена',
    pending: 'В обработке',
    draft: 'Черновик',
    active: 'Активен',
    closed: 'Закрыт',
    blocked: 'Заблокирован'
};

function statusLabel(status) {
    return STATUS_LABELS[status] || status || '—';
}

function statusBadgeClass(status) {
    if (status === 'completed' || status === 'active') return 'badge badge-green';
    if (status === 'pending' || status === 'draft') return 'badge badge-blue';
    if (status === 'closed' || status === 'blocked') return 'badge badge-red';
    return 'badge';
}

function escapeHtml(value) {
    return String(value === null || value === undefined ? '' : value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
}
