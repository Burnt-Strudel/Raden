import { PAGE_META } from '../config.js';
import { state } from '../state.js';
import { $ } from '../ui.js';
import { escapeHtml } from '../format.js';
import { stopQuotesPolling } from './polling.js';

const pages = {};

let renderToken = 0;

export function registerPages(pageMap) {
    Object.assign(pages, pageMap);
}

export function isStale(token) {
    return token !== renderToken;
}

export function routeFromHash() {
    return (location.hash || '').replace(/^#\/?/, '').split('?')[0] || 'overview';
}

export function navigate() {
    const route = routeFromHash();
    state.route = PAGE_META[route] ? route : 'overview';
    const meta = PAGE_META[state.route];

    $('page-title').textContent = meta.title;
    $('page-subtitle').textContent = meta.subtitle;

    document.querySelectorAll('.nav-item').forEach((item) => {
        item.classList.toggle('active', item.dataset.route === state.route);
    });

    stopQuotesPolling();
    renderPage();
}

export async function renderPage(silent = false) {
    const token = ++renderToken;
    const page = $('page');
    if (!silent) {
        page.innerHTML = '<div class="card page-loading">Загружаем данные…</div>';
    }

    const render = pages[state.route];
    if (!render) return;

    try {
        await render(page, token);
    } catch (error) {
        if (!silent && token === renderToken) {
            page.innerHTML = '<div class="page-error">' + escapeHtml(error.message) + '</div>';
        }
    }
}
