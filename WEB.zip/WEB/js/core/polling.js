import { CORE_REFRESH_MS, QUOTES_REFRESH_MS } from '../config.js';
import { state } from '../state.js';
import { BankApi } from '../api.js';
import { updateLastUpdated } from '../ui.js';

let corePending = false;
let quotesPending = false;

let transferPending = false;

let onCoreDataChanged = null;

export function setCoreDataChangedHandler(handler) {
    onCoreDataChanged = handler;
}

export function isTransferPending() {
    return transferPending;
}

export function setTransferPending(value) {
    transferPending = value;
}

async function fetchCoreData() {
    const [accounts, transactions] = await Promise.all([
        BankApi.getAccounts(state.user.id),
        BankApi.getTransactions(state.user.id)
    ]);

    return {
        accounts: Array.isArray(accounts) ? accounts : state.accounts,
        transactions: Array.isArray(transactions) ? transactions : state.transactions
    };
}

export async function loadCoreData() {
    const data = await fetchCoreData();
    state.accounts = data.accounts;
    state.transactions = data.transactions;
    updateLastUpdated();
}

export function startCorePolling() {
    stopCorePolling();
    state.coreTimer = setInterval(refreshCoreData, CORE_REFRESH_MS);
}

export function stopCorePolling() {
    corePending = false;
    if (state.coreTimer) {
        clearInterval(state.coreTimer);
        state.coreTimer = null;
    }
}

export async function refreshCoreData() {
    if (!state.user || corePending || transferPending) return;

    corePending = true;
    try {
        const data = await fetchCoreData();
        const changed =
            JSON.stringify(data.accounts) !== JSON.stringify(state.accounts) ||
            JSON.stringify(data.transactions) !== JSON.stringify(state.transactions);

        state.accounts = data.accounts;
        state.transactions = data.transactions;
        updateLastUpdated();

        if (changed && ['overview', 'accounts', 'operations', 'analytics'].includes(state.route) && onCoreDataChanged) {
            await onCoreDataChanged();
        }
    } catch {
    } finally {
        corePending = false;
    }
}

export function startQuotesPolling(accountId, onUpdate) {
    stopQuotesPolling();
    quotesPending = false;

    state.quotesTimer = setInterval(async () => {
        if (state.route !== 'investments') return;
        if (quotesPending) return;

        quotesPending = true;
        try {
            const [quotes, portfolio] = await Promise.all([
                BankApi.getQuotes(),
                BankApi.getPortfolio(accountId)
            ]);
            state.quotes = Array.isArray(quotes) ? quotes : state.quotes;
            state.portfolio = portfolio;
            onUpdate();
            updateLastUpdated();
        } catch {
            // Следующая попытка через 3 секунды.
        } finally {
            quotesPending = false;
        }
    }, QUOTES_REFRESH_MS);
}

export function stopQuotesPolling() {
    quotesPending = false;
    if (state.quotesTimer) {
        clearInterval(state.quotesTimer);
        state.quotesTimer = null;
    }
}
