const SESSION_KEY = 'project_bank_web_user';
const OPERATIONS_PAGE_SIZE = 20;
const CORE_REFRESH_MS = 10000;
const QUOTES_REFRESH_MS = 3000;

const PAGE_META = {
    overview: { title: 'Обзор', subtitle: 'Ваши финансы в одном месте' },
    accounts: { title: 'Счета', subtitle: 'Все счета, карты и реквизиты' },
    operations: { title: 'Операции', subtitle: 'История с фильтрами, поиском и экспортом' },
    transfer: { title: 'Переводы', subtitle: 'Между своими счетами, по телефону и карте' },
    investments: { title: 'Инвестиции', subtitle: 'Акции, драгоценные металлы и валюта' },
    analytics: { title: 'Аналитика', subtitle: 'Доходы, расходы и динамика по месяцам' },
    profile: { title: 'Профиль', subtitle: 'Данные клиента и настройки сессии' }
};

const state = {
    user: null,
    accounts: [],
    transactions: [],
    quotes: [],
    portfolio: null,
    route: 'overview',
    selectedSecurityId: null,
    investmentKind: 'all',
    investmentSearch: '',
    transferMode: 'own',
    operations: {
        accountId: '',
        type: '',
        sign: 'all',
        search: '',
        from: '',
        to: '',
        sortKey: 'createdAt',
        sortDir: 'desc',
        page: 1
    },
    analyticsMonth: '',
    quotesTimer: null,
    coreTimer: null
};

let renderToken = 0;
let toastTimer = null;
let transferPending = false;
let modalConfirming = false;
let lastFocusedElement = null;
let quotesPending = false;
let corePending = false;

document.addEventListener('DOMContentLoaded', init);

function init() {
    bindLoginScreen();
    bindShell();
    restoreSession();

    if (state.user) {
        showApp();
    }
}

const $ = (id) => document.getElementById(id);

function restoreSession() {
    try {
        const raw = localStorage.getItem(SESSION_KEY);
        if (raw) state.user = JSON.parse(raw);
    } catch {
        state.user = null;
    }
}

function saveSession() {
    localStorage.setItem(SESSION_KEY, JSON.stringify(state.user));
}

function bindLoginScreen() {
    $('tab-login').addEventListener('click', () => switchAuthTab('login'));
    $('tab-register').addEventListener('click', () => switchAuthTab('register'));
    $('login-form').addEventListener('submit', handleLogin);
    $('register-form').addEventListener('submit', handleRegister);
}

function switchAuthTab(tab) {
    const isLogin = tab === 'login';
    $('tab-login').classList.toggle('active', isLogin);
    $('tab-register').classList.toggle('active', !isLogin);
    $('login-form').hidden = !isLogin;
    $('register-form').hidden = isLogin;
}

async function handleLogin(event) {
    event.preventDefault();
    const button = event.target.querySelector('button[type="submit"]');
    const errorBox = $('login-error');
    errorBox.hidden = true;
    button.disabled = true;
    button.textContent = 'Входим…';

    try {
        const user = await BankApi.login(
            $('login-username').value.trim(),
            $('login-password').value
        );
        state.user = user;
        saveSession();
        $('login-password').value = '';
        showApp();
    } catch (error) {
        errorBox.textContent = error.message;
        errorBox.hidden = false;
    } finally {
        button.disabled = false;
        button.textContent = 'Войти';
    }
}

async function handleRegister(event) {
    event.preventDefault();
    const button = event.target.querySelector('button[type="submit"]');
    const errorBox = $('register-error');
    errorBox.hidden = true;
    button.disabled = true;
    button.textContent = 'Создаём…';

    const username = $('reg-username').value.trim();

    try {
        await BankApi.register({
            username,
            password: $('reg-password').value,
            email: $('reg-email').value.trim(),
            firstName: $('reg-first-name').value.trim(),
            lastName: $('reg-last-name').value.trim(),
            phone: $('reg-phone').value.trim()
        });
        toast('Аккаунт создан. Войдите с новым логином.', 'success');
        switchAuthTab('login');
        $('login-username').value = username;
        $('login-password').focus();
        event.target.reset();
    } catch (error) {
        errorBox.textContent = error.message;
        errorBox.hidden = false;
    } finally {
        button.disabled = false;
        button.textContent = 'Зарегистрироваться';
    }
}

function showApp() {
    $('login-screen').hidden = true;
    $('app-shell').hidden = false;
    updateUserBlock();
    startCorePolling();

    const route = routeFromHash();
    if (!PAGE_META[route]) {
        location.hash = '#/overview';
    } else {
        navigate();
    }
}

function logout() {
    stopQuotesPolling();
    stopCorePolling();
    localStorage.removeItem(SESSION_KEY);
    state.user = null;
    state.accounts = [];
    state.transactions = [];
    state.quotes = [];
    state.portfolio = null;
    state.selectedSecurityId = null;
    $('app-shell').hidden = true;
    $('login-screen').hidden = false;
    history.replaceState(null, '', location.pathname + location.search);
    switchAuthTab('login');
    $('login-password').value = '';
}


function bindShell() {
    $('refresh-button').addEventListener('click', () => {
        if (state.user) renderPage();
    });

    $('logout-button').addEventListener('click', logout);

    $('page').addEventListener('click', handlePageClick);
    $('page').addEventListener('input', handlePageInput);
    $('page').addEventListener('change', handlePageChange);
    $('page').addEventListener('keydown', (event) => {
        if (event.key !== 'Enter' && event.key !== ' ') return;

        const target = event.target.closest('[data-action][tabindex="0"]');
        if (!target || target.tagName === 'A' || target.tagName === 'BUTTON') return;

        event.preventDefault();
        target.click();
    });

    $('modal-backdrop').addEventListener('click', (event) => {
        if (event.target === $('modal-backdrop')) closeModal();
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !$('modal-backdrop').hidden) {
            closeModal();
        }
    });

    window.addEventListener('hashchange', () => {
        if (state.user) navigate();
    });
}

function routeFromHash() {
    return (location.hash || '').replace(/^#\/?/, '').split('?')[0] || 'overview';
}

function navigate() {
    const route = routeFromHash();
    state.route = PAGE_META[route] ? route : 'overview';
    const meta = PAGE_META[state.route];

    $('page-title').textContent = meta.title;
    $('page-subtitle').textContent = meta.subtitle;

    document.querySelectorAll('.nav-item').forEach((item) => {
        item.classList.toggle('active', item.dataset.route === state.route);
    });

    stopQuotesPolling();
    renderPage();
}

function updateUserBlock() {
    if (!state.user) return;
    const name = [state.user.firstName, state.user.lastName].filter(Boolean).join(' ') || state.user.username;
    $('user-name').textContent = name;
    $('user-login').textContent = state.user.username;
    $('user-avatar').textContent = name.trim().charAt(0).toUpperCase();
}

function updateLastUpdated() {
    $('last-updated').textContent = 'Обновлено ' + formatTime();
}


async function loadCoreData() {
    const [accounts, transactions] = await Promise.all([
        BankApi.getAccounts(state.user.id),
        BankApi.getTransactions(state.user.id)
    ]);

    state.accounts = Array.isArray(accounts) ? accounts : [];
    state.transactions = Array.isArray(transactions) ? transactions : [];
    updateLastUpdated();
}

function startCorePolling() {
    stopCorePolling();
    state.coreTimer = setInterval(refreshCoreData, CORE_REFRESH_MS);
}

function stopCorePolling() {
    corePending = false;
    if (state.coreTimer) {
        clearInterval(state.coreTimer);
        state.coreTimer = null;
    }
}

async function refreshCoreData() {
    if (!state.user || corePending || transferPending) return;

    corePending = true;
    try {
        const [accounts, transactions] = await Promise.all([
            BankApi.getAccounts(state.user.id),
            BankApi.getTransactions(state.user.id)
        ]);
        const nextAccounts = Array.isArray(accounts) ? accounts : state.accounts;
        const nextTransactions = Array.isArray(transactions) ? transactions : state.transactions;
        const changed =
            JSON.stringify(nextAccounts) !== JSON.stringify(state.accounts) ||
            JSON.stringify(nextTransactions) !== JSON.stringify(state.transactions);

        state.accounts = nextAccounts;
        state.transactions = nextTransactions;
        updateLastUpdated();

        if (changed && ['overview', 'accounts', 'operations', 'analytics'].includes(state.route)) {
            await renderPage(true);
        }
    } catch {
        // API временно недоступно — попробуем через 10 секунд.
    } finally {
        corePending = false;
    }
}

function investmentAccount() {
    return state.accounts.find((account) => account.accountType === 'investment') || null;
}

async function loadPortfolio() {
    const account = investmentAccount();
    if (!account) {
        state.portfolio = null;
        return null;
    }
    try {
        state.portfolio = await BankApi.getPortfolio(account.id);
    } catch {
        state.portfolio = null;
    }
    return state.portfolio;
}

async function renderPage(silent = false) {
    const token = ++renderToken;
    const page = $('page');
    if (!silent) {
        page.innerHTML = '<div class="card page-loading">Загружаем данные…</div>';
    }

    try {
        switch (state.route) {
            case 'overview':
                await renderOverview(page, token);
                break;
            case 'accounts':
                await renderAccounts(page, token);
                break;
            case 'operations':
                await renderOperations(page, token);
                break;
            case 'transfer':
                await renderTransfer(page, token);
                break;
            case 'investments':
                await renderInvestments(page, token);
                break;
            case 'analytics':
                await renderAnalytics(page, token);
                break;
            case 'profile':
                renderProfile(page);
                break;
        }
    } catch (error) {
        if (token === renderToken) {
            page.innerHTML = '<div class="page-error">' + escapeHtml(error.message) + '</div>';
        }
    }
}


function sumBy(items, selector) {
    return items.reduce((total, item) => total + Number(selector(item) || 0), 0);
}

function accountById(id) {
    return state.accounts.find((account) => account.id === id) || null;
}

function accountBelongs(id) {
    return Boolean(accountById(id));
}

function transactionDirection(transaction, accountId) {
    const fromId = transaction.fromAccountId;
    const toId = transaction.toAccountId;

    if (accountId) {
        if (fromId === accountId && toId === accountId) return 'internal';
        if (toId === accountId) return 'in';
        if (fromId === accountId) return 'out';
    }

    switch (transaction.transactionType) {
        case 'investment':
            return toId ? 'in' : 'out';
        case 'deposit':
        case 'interest':
        case 'income':
            return 'in';
        case 'withdrawal':
        case 'fee':
        case 'expense':
            return 'out';
        case 'transfer': {
            const fromOwn = accountBelongs(fromId);
            const toOwn = accountBelongs(toId);
            if (fromOwn && toOwn) return 'internal';
            if (toOwn) return 'in';
            if (fromOwn) return 'out';
            return 'internal';
        }
        default:
            return 'neutral';
    }
}

function amountClass(direction) {
    if (direction === 'in') return 'amount-in';
    if (direction === 'out') return 'amount-out';
    return 'amount-internal';
}

function amountPrefix(direction) {
    if (direction === 'in') return '+';
    if (direction === 'out') return '−';
    return '⇄ ';
}

function transactionAccounts(transaction) {
    const from = accountById(transaction.fromAccountId);
    const to = accountById(transaction.toAccountId);
    const parts = [];

    if (from) parts.push(accountTitle(from));
    else if (transaction.fromAccountId) parts.push('Внешний счёт');

    if (to) parts.push(accountTitle(to));
    else if (transaction.toAccountId) parts.push('Внешний счёт');

    return parts.join(' → ') || '—';
}

function operationRowHtml(transaction, accountId, compact = false) {
    const direction = transactionDirection(transaction, accountId);
    const amount = '<span class="' + amountClass(direction) + '">' +
        amountPrefix(direction) + formatMoney(transaction.amount) + '</span>';
    const description = escapeHtml(transaction.description || transactionTypeLabel(transaction.transactionType));

    if (compact) {
        return '<tr>' +
            '<td class="small muted">' + formatDate(transaction.createdAt) + '</td>' +
            '<td>' + description + '<div class="muted small">' + transactionTypeLabel(transaction.transactionType) + '</div></td>' +
            '<td class="num">' + amount + '</td>' +
            '</tr>';
    }

    return '<tr>' +
        '<td class="small muted">' + formatDate(transaction.createdAt) + '</td>' +
        '<td>' + description + '</td>' +
        '<td class="small muted">' + transactionAccounts(transaction) + '</td>' +
        '<td><span class="badge">' + transactionTypeLabel(transaction.transactionType) + '</span></td>' +
        '<td><span class="' + statusBadgeClass(transaction.status) + '">' + statusLabel(transaction.status) + '</span></td>' +
        '<td class="num">' + amount + '</td>' +
        '</tr>';
}

function emptyTableRow(columns, text) {
    return '<tr><td colspan="' + columns + '" class="empty-state">' + escapeHtml(text) + '</td></tr>';
}


async function renderOverview(page, token) {
    await loadCoreData();
    await loadPortfolio();
    if (token !== renderToken) return;

    const totalBalance = sumBy(state.accounts, (account) => account.balance);
    const holdingsValue = state.portfolio ? Number(state.portfolio.holdingsValue) : 0;
    const portfolioValue = state.portfolio ? Number(state.portfolio.totalValue) : 0;
    const profit = state.portfolio ? sumBy(state.portfolio.holdings, (holding) => holding.profit) : 0;
    const currentMonth = monthKey(new Date().toISOString());
    const monthTransactions = state.transactions.filter((item) => monthKey(item.createdAt) === currentMonth);

    let income = 0;
    let expense = 0;
    monthTransactions.forEach((item) => {
        const direction = transactionDirection(item, null);
        if (direction === 'in') income += Number(item.amount);
        if (direction === 'out') expense += Number(item.amount);
    });

    const recent = state.transactions.slice(0, 6);

    const accountsHtml = state.accounts.length
        ? state.accounts.map((account) =>
            '<a class="account-mini" href="#/accounts">' +
                '<span class="name">' + accountTitle(account) + '</span>' +
                '<span class="number">' + maskCardNumber(account.cardNumber) + '</span>' +
                '<span class="balance">' + formatMoney(account.balance) + '</span>' +
            '</a>').join('')
        : '<div class="empty-state">Активных счетов пока нет</div>';

    const recentHtml = recent.length
        ? recent.map((item) => operationRowHtml(item, null, true)).join('')
        : emptyTableRow(3, 'Операций пока нет');

    page.innerHTML =
        '<div class="kpi-grid kpi-grid-5">' +
            '<div class="kpi kpi-accent">' +
                '<span class="kpi-label">Общий баланс</span>' +
                '<span class="kpi-value">' + formatMoney(totalBalance) + '</span>' +
                '<span class="kpi-note">' + state.accounts.length + ' ' +
                    plural(state.accounts.length, 'активный счёт', 'активных счёта', 'активных счетов') + '</span>' +
            '</div>' +
            '<div class="kpi">' +
                '<span class="kpi-label">С учётом активов</span>' +
                '<span class="kpi-value">' + formatMoney(totalBalance + holdingsValue) + '</span>' +
                '<span class="kpi-note">Счета и ценные бумаги</span>' +
            '</div>' +
            '<div class="kpi">' +
                '<span class="kpi-label">Инвестиции</span>' +
                '<span class="kpi-value">' + formatMoney(portfolioValue) + '</span>' +
                '<span class="kpi-note ' + (profit >= 0 ? 'positive' : 'negative') + '">Прибыль ' +
                    (profit >= 0 ? '+' : '−') + formatMoney(Math.abs(profit)) + '</span>' +
            '</div>' +
            '<div class="kpi">' +
                '<span class="kpi-label">Доходы за месяц</span>' +
                '<span class="kpi-value positive">' + (income > 0 ? '+' : '') + formatMoney(income) + '</span>' +
                '<span class="kpi-note">' + monthLabel(currentMonth) + '</span>' +
            '</div>' +
            '<div class="kpi">' +
                '<span class="kpi-label">Расходы за месяц</span>' +
                '<span class="kpi-value negative">' + (expense > 0 ? '−' : '') + formatMoney(expense) + '</span>' +
                '<span class="kpi-note">' + monthLabel(currentMonth) + '</span>' +
            '</div>' +
        '</div>' +
        '<div class="inline">' +
            '<a class="button button-primary" href="#/transfer">Новый перевод</a>' +
            '<a class="button button-secondary" href="#/accounts">Открыть счёт</a>' +
            '<a class="button button-secondary" href="#/investments">Инвестиции</a>' +
            '<a class="button button-secondary" href="#/operations">Все операции</a>' +
        '</div>' +
        '<div class="grid-2">' +
            '<div class="card">' +
                '<div class="card-head"><div><h2>Счета</h2><div class="subtitle">Баланс и карты</div></div>' +
                    '<a class="button button-secondary button-small" href="#/accounts">Подробнее</a></div>' +
                '<div class="account-mini-grid">' + accountsHtml + '</div>' +
            '</div>' +
            '<div class="card">' +
                '<div class="card-head"><div><h2>Последние операции</h2><div class="subtitle">Последние записи по всем счетам</div></div>' +
                    '<a class="button button-secondary button-small" href="#/operations">Все</a></div>' +
                '<div class="table-wrap"><table><tbody>' + recentHtml + '</tbody></table></div>' +
            '</div>' +
        '</div>';
}


async function renderAccounts(page, token) {
    await loadCoreData();
    if (token !== renderToken) return;

    const hasRegular = state.accounts.some((account) => account.accountType === 'regular');
    const hasInvestment = state.accounts.some((account) => account.accountType === 'investment');

    const rows = state.accounts.length
        ? state.accounts.map((account) => {
            const closeButton = Number(account.balance) === 0
                ? '<button type="button" class="button button-small button-danger" data-action="close-account" data-id="' + account.id + '">Закрыть</button>'
                : '';

            return '<tr>' +
                '<td><strong>' + accountTitle(account) + '</strong><div class="muted small">' + account.currency + '</div></td>' +
                '<td><span class="mono copyable" data-action="copy" data-copy="' + account.accountNumber + '" role="button" tabindex="0" title="Скопировать номер">' + account.accountNumber + '</span></td>' +
                '<td><span class="mono copyable" data-action="copy" data-copy="' + account.cardNumber + '" role="button" tabindex="0" title="Скопировать номер карты">' + maskCardNumber(account.cardNumber) + '</span></td>' +
                '<td class="num"><strong>' + formatMoney(account.balance) + '</strong></td>' +
                '<td><span class="' + statusBadgeClass(account.status) + '">' + statusLabel(account.status) + '</span></td>' +
                '<td><div class="inline">' +
                    '<a class="button button-small button-secondary" href="#/transfer">Перевести</a>' +
                    closeButton +
                '</div></td>' +
                '</tr>';
        }).join('')
        : emptyTableRow(6, 'Активных счетов нет');

    page.innerHTML =
        '<div class="kpi-grid">' +
            '<div class="kpi kpi-accent"><span class="kpi-label">Всего на счетах</span>' +
                '<span class="kpi-value">' + formatMoney(sumBy(state.accounts, (account) => account.balance)) + '</span>' +
                '<span class="kpi-note">' + state.accounts.length + ' ' +
                    plural(state.accounts.length, 'активный счёт', 'активных счёта', 'активных счетов') + '</span></div>' +
            '<div class="kpi"><span class="kpi-label">Карт</span>' +
                '<span class="kpi-value">' + state.accounts.length + '</span>' +
                '<span class="kpi-note">У каждого счёта своя карта</span></div>' +
            '<div class="kpi"><span class="kpi-label">Инвестиционный счёт</span>' +
                '<span class="kpi-value">' + (hasInvestment ? 'Открыт' : 'Нет') + '</span>' +
                '<span class="kpi-note">Акции, металлы и валюта</span></div>' +
        '</div>' +
        '<div class="card">' +
            '<div class="card-head"><div><h2>Все счета</h2><div class="subtitle">Нажмите на номер, чтобы скопировать</div></div></div>' +
            '<div class="table-wrap"><table>' +
                '<thead><tr><th>Счёт</th><th>Номер счёта</th><th>Карта</th><th class="num">Баланс</th><th>Статус</th><th>Действия</th></tr></thead>' +
                '<tbody>' + rows + '</tbody>' +
            '</table></div>' +
        '</div>' +
        '<div class="card">' +
            '<div class="card-head"><div><h2>Открыть новый счёт</h2><div class="subtitle">Основной и инвестиционный — по одному на клиента</div></div></div>' +
            '<div class="grid-3">' +
                openAccountCard('regular', 'Основной счёт', 'Для ежедневных платежей и переводов', hasRegular) +
                openAccountCard('savings', 'Накопительный', 'Можно открыть несколько, ставка 5% годовых', false) +
                openAccountCard('investment', 'Инвестиционный', 'Акции, драгоценные металлы и валюта', hasInvestment) +
            '</div>' +
        '</div>';
}

function openAccountCard(kind, title, description, alreadyOpen) {
    return '<div class="account-mini">' +
        '<span class="name">' + title + '</span>' +
        '<span class="muted small">' + description + '</span>' +
        '<div style="margin-top:10px">' +
            (alreadyOpen
                ? '<span class="badge badge-green">Уже открыт</span>'
                : '<button type="button" class="button button-primary button-small" data-action="open-account" data-kind="' + kind + '">Открыть</button>') +
        '</div>' +
    '</div>';
}

async function openAccount(kind) {
    const actions = {
        regular: BankApi.openRegular,
        savings: BankApi.openSavings,
        investment: BankApi.openInvestment
    };

    const action = actions[kind];
    if (!action) return;

    try {
        await action(state.user.id);
        toast('Счёт открыт.', 'success');
        await loadCoreData();
        renderPage();
    } catch (error) {
        toast(error.message, 'error');
    }
}

function confirmCloseAccount(accountId) {
    const account = accountById(accountId);
    if (!account) return;

    openModal({
        title: 'Закрыть счёт?',
        bodyHtml: '<p>' + accountTitle(account) + '</p>' +
            '<p class="muted small">Счёт можно закрыть только с нулевым балансом. Действие необратимо.</p>',
        confirmText: 'Закрыть',
        danger: true,
        onConfirm: async () => {
            await BankApi.closeAccount(account.id);
            toast('Счёт закрыт.', 'success');
            await loadCoreData();
            renderPage();
        }
    });
}


async function renderOperations(page, token) {
    await loadCoreData();
    if (token !== renderToken) return;

    const filters = state.operations;
    const accountOptions = '<option value="">Все счета</option>' + state.accounts.map((account) =>
        '<option value="' + account.id + '"' + (String(account.id) === filters.accountId ? ' selected' : '') + '>' +
        accountTitle(account) + '</option>').join('');

    const typeOptions = ['transfer', 'investment', 'deposit', 'withdrawal', 'interest', 'fee']
        .map((type) => '<option value="' + type + '"' + (type === filters.type ? ' selected' : '') + '>' +
            transactionTypeLabel(type) + '</option>').join('');

    page.innerHTML =
        '<div class="card">' +
            '<div class="card-head"><div><h2>История операций</h2><div class="subtitle">Фильтры работают по всем загруженным операциям</div></div>' +
                '<button type="button" class="button button-secondary button-small" data-action="export-csv">Экспорт CSV</button></div>' +
            '<div class="filters">' +
                '<label class="field"><span>Счёт</span><select id="filter-account">' + accountOptions + '</select></label>' +
                '<label class="field"><span>Тип</span><select id="filter-type"><option value="">Все типы</option>' + typeOptions + '</select></label>' +
                '<label class="field"><span>Направление</span><select id="filter-sign">' +
                    '<option value="all">Все</option>' +
                    '<option value="in"' + (filters.sign === 'in' ? ' selected' : '') + '>Доходы</option>' +
                    '<option value="out"' + (filters.sign === 'out' ? ' selected' : '') + '>Расходы</option>' +
                '</select></label>' +
                '<label class="field"><span>С даты</span><input type="date" id="filter-from" value="' + filters.from + '"></label>' +
                '<label class="field"><span>По дату</span><input type="date" id="filter-to" value="' + filters.to + '"></label>' +
                '<label class="field"><span>Поиск</span><input type="search" id="filter-search" placeholder="Описание или тип" value="' + escapeHtml(filters.search) + '"></label>' +
                '<div class="filter-actions"><button type="button" class="button button-secondary" data-action="reset-filters">Сбросить</button></div>' +
            '</div>' +
            '<div class="summary-line" id="operations-summary"></div>' +
            '<div id="operations-table"></div>' +
        '</div>';

    renderOperationsTable();
}

function filteredTransactions() {
    const filters = state.operations;
    const accountId = filters.accountId ? Number(filters.accountId) : null;

    const list = state.transactions.filter((transaction) => {
        if (accountId && transaction.fromAccountId !== accountId && transaction.toAccountId !== accountId) {
            return false;
        }
        if (filters.type && transaction.transactionType !== filters.type) return false;

        if (filters.from) {
            const from = new Date(filters.from + 'T00:00:00');
            if (new Date(transaction.createdAt) < from) return false;
        }
        if (filters.to) {
            const to = new Date(filters.to + 'T23:59:59');
            if (new Date(transaction.createdAt) > to) return false;
        }
        if (filters.search) {
            const haystack = ((transaction.description || '') + ' ' +
                transactionTypeLabel(transaction.transactionType)).toLowerCase();
            if (!haystack.includes(filters.search.toLowerCase())) return false;
        }
        if (filters.sign !== 'all') {
            const direction = transactionDirection(transaction, accountId);
            if (direction !== filters.sign) return false;
        }
        return true;
    });

    const multiplier = filters.sortDir === 'asc' ? 1 : -1;
    return list.sort((a, b) => {
        if (filters.sortKey === 'amount') {
            return (Number(a.amount) - Number(b.amount)) * multiplier;
        }
        return (new Date(a.createdAt) - new Date(b.createdAt)) * multiplier;
    });
}

function renderOperationsTable() {
    const summary = $('operations-summary');
    const container = $('operations-table');
    if (!summary || !container) return;

    const filters = state.operations;
    const accountId = filters.accountId ? Number(filters.accountId) : null;
    const all = filteredTransactions();

    let income = 0;
    let expense = 0;
    all.forEach((transaction) => {
        const direction = transactionDirection(transaction, accountId);
        if (direction === 'in') income += Number(transaction.amount);
        if (direction === 'out') expense += Number(transaction.amount);
    });

    const pages = Math.max(1, Math.ceil(all.length / OPERATIONS_PAGE_SIZE));
    if (filters.page > pages) filters.page = pages;

    const start = (filters.page - 1) * OPERATIONS_PAGE_SIZE;
    const pageItems = all.slice(start, start + OPERATIONS_PAGE_SIZE);
    const arrow = (key) => filters.sortKey === key
        ? '<span class="sort-arrow">' + (filters.sortDir === 'asc' ? '▲' : '▼') + '</span>'
        : '';

    const rows = pageItems.length
        ? pageItems.map((transaction) => operationRowHtml(transaction, accountId)).join('')
        : emptyTableRow(6, 'По выбранным фильтрам операций нет');

    summary.innerHTML =
        '<span>Найдено: <strong>' + all.length + '</strong></span>' +
        '<span>Доходы: <strong class="positive">' + (income > 0 ? '+' : '') + formatMoney(income) + '</strong></span>' +
        '<span>Расходы: <strong class="negative">' + (expense > 0 ? '−' : '') + formatMoney(expense) + '</strong></span>';

    container.innerHTML =
        '<div class="table-wrap"><table>' +
            '<thead><tr>' +
                '<th class="sortable" data-action="sort-operations" data-key="createdAt">Дата' + arrow('createdAt') + '</th>' +
                '<th>Описание</th>' +
                '<th>Счёт</th>' +
                '<th>Тип</th>' +
                '<th>Статус</th>' +
                '<th class="num sortable" data-action="sort-operations" data-key="amount">Сумма' + arrow('amount') + '</th>' +
            '</tr></thead>' +
            '<tbody>' + rows + '</tbody>' +
        '</table></div>' +
        '<div class="pager">' +
            '<span>Страница ' + filters.page + ' из ' + pages + '</span>' +
            '<button type="button" class="button button-small button-secondary" data-action="page-prev"' + (filters.page <= 1 ? ' disabled' : '') + '>Назад</button>' +
            '<button type="button" class="button button-small button-secondary" data-action="page-next"' + (filters.page >= pages ? ' disabled' : '') + '>Вперёд</button>' +
        '</div>';
}

function resetOperationFilters() {
    state.operations = {
        accountId: '',
        type: '',
        sign: 'all',
        search: '',
        from: '',
        to: '',
        sortKey: 'createdAt',
        sortDir: 'desc',
        page: 1
    };
    renderPage();
}

function exportOperationsCsv() {
    const accountId = state.operations.accountId ? Number(state.operations.accountId) : null;
    const items = filteredTransactions();

    if (!items.length) {
        toast('Нет операций для экспорта.', 'error');
        return;
    }

    const header = ['Дата', 'Описание', 'Тип', 'Статус', 'Сумма', 'Направление', 'Счёт списания', 'Счёт зачисления'];
    const lines = [header.join(';')];

    items.forEach((transaction) => {
        const direction = transactionDirection(transaction, accountId);
        const directionLabel = direction === 'in' ? 'Доход' : direction === 'out' ? 'Расход' : 'Между счетами';
        const from = accountById(transaction.fromAccountId);
        const to = accountById(transaction.toAccountId);

        const cells = [
            formatDate(transaction.createdAt),
            transaction.description || '',
            transactionTypeLabel(transaction.transactionType),
            statusLabel(transaction.status),
            Number(transaction.amount).toFixed(2).replace('.', ','),
            directionLabel,
            from ? from.accountNumber : '',
            to ? to.accountNumber : ''
        ];

        lines.push(cells.map(csvCell).join(';'));
    });

    const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'operacii_' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(link.href), 0);
    toast('Экспортировано операций: ' + items.length, 'success');
}

function csvCell(value) {
    const text = String(value ?? '');
    const safe = /^[=+\-@\t\r]/.test(text) ? "'" + text : text;
    return /[;"\r\n]/.test(safe) ? '"' + safe.replaceAll('"', '""') + '"' : safe;
}


async function renderTransfer(page, token) {
    await loadCoreData();
    if (token !== renderToken) return;

    const accountsHtml = state.accounts.map((account) =>
        '<div class="transfer-account">' +
            '<a href="#/accounts">' + accountTitle(account) + '</a>' +
            '<strong>' + formatMoney(account.balance) + '</strong>' +
        '</div>').join('');

    page.innerHTML =
        '<div class="transfer-layout">' +
            '<div class="card">' +
                '<div class="card-head"><div><h2>Переводы</h2><div class="subtitle">Внутри банка — по номеру счёта, телефона или карты</div></div></div>' +
                '<div class="tabs">' +
                    transferTab('own', 'Между своими') +
                    transferTab('phone', 'По телефону') +
                    transferTab('card', 'По карте') +
                '</div>' +
                '<div id="transfer-area" style="margin-top:20px"></div>' +
            '</div>' +
            '<div class="card">' +
                '<div class="card-head"><div><h2>Ваши счета</h2><div class="subtitle">Доступные средства</div></div></div>' +
                accountsHtml +
                '<p class="muted small" style="margin-top:16px">Переводы между своими счетами и внутри банка выполняются сразу, без комиссии.</p>' +
            '</div>' +
        '</div>';

    renderTransferArea();
}

function transferTab(mode, label) {
    return '<button type="button" class="tab' + (state.transferMode === mode ? ' active' : '') +
        '" data-action="transfer-mode" data-mode="' + mode + '">' + label + '</button>';
}

function sourceAccountOptions(selectedId, disabledId = null) {
    return state.accounts.map((account) => {
        const selected = account.id === selectedId ? ' selected' : '';
        const disabled = account.id === disabledId ? ' disabled' : '';
        return '<option value="' + account.id + '"' + selected + disabled + '>' +
            accountTitle(account) + ' — ' + formatMoney(account.balance) + '</option>';
    }).join('');
}

function renderTransferArea() {
    const area = $('transfer-area');
    if (!area) return;

    if (!state.accounts.length) {
        area.innerHTML = '<div class="empty-state">Нет активных счетов для перевода.</div>';
        return;
    }

    if (state.transferMode === 'phone') {
        renderPhoneTransfer(area);
        return;
    }
    if (state.transferMode === 'card') {
        renderCardTransfer(area);
        return;
    }
    renderOwnTransfer(area);
}

function renderOwnTransfer(area) {
    const sourceId = Number(area.dataset.sourceId || 0) || state.accounts[0].id;
    const source = accountById(sourceId) || state.accounts[0];
    const target = state.accounts.find((account) => account.id !== source.id) || null;

    area.innerHTML =
        '<form class="transfer-form" id="transfer-own-form">' +
            '<label class="field"><span>Счёт списания</span><select id="transfer-own-source">' +
                sourceAccountOptions(source.id) + '</select></label>' +
            '<label class="field"><span>Счёт зачисления</span><select id="transfer-own-target">' +
                (target ? sourceAccountOptions(target.id, source.id) : '') + '</select></label>' +
            '<label class="field"><span>Сумма, ₽</span><input type="number" id="transfer-own-amount" min="0.01" step="0.01" placeholder="1000" required></label>' +
            '<label class="field"><span>Назначение</span><input type="text" id="transfer-own-description" placeholder="Перевод между счетами"></label>' +
            '<button type="submit" class="button button-primary" style="align-self:flex-start">Перевести</button>' +
        '</form>';

    $('transfer-own-source').addEventListener('change', () => {
        const newSource = Number($('transfer-own-source').value);
        $('transfer-area').dataset.sourceId = String(newSource);
        const newTarget = state.accounts.find((account) => account.id !== newSource);
        const targetSelect = $('transfer-own-target');
        targetSelect.innerHTML = newTarget ? sourceAccountOptions(newTarget.id, newSource) : '';
    });

    $('transfer-own-form').addEventListener('submit', handleOwnTransfer);
}

function validateTransferAmount(source, amount) {
    if (!Number.isFinite(amount) || amount <= 0) {
        toast('Введите сумму больше нуля.', 'error');
        return false;
    }
    if (amount > Number(source.balance)) {
        toast('Недостаточно средств на счёте списания.', 'error');
        return false;
    }
    return true;
}

async function completeTransfer(result, amount) {
    showTransferResult(result, amount);
    await loadCoreData();
    renderTransferArea();
    updateLastUpdated();
}

async function handleOwnTransfer(event) {
    event.preventDefault();

    const source = accountById(Number($('transfer-own-source').value));
    const target = accountById(Number($('transfer-own-target').value));
    const amount = parseAmount($('transfer-own-amount').value);

    if (!source || !target) {
        toast('Выберите счёт списания и зачисления.', 'error');
        return;
    }
    if (source.id === target.id) {
        toast('Выберите разные счета.', 'error');
        return;
    }
    if (!validateTransferAmount(source, amount)) return;

    const description = $('transfer-own-description').value.trim() || 'Перевод между счетами';

    if (!beginTransfer(event.target)) return;
    try {
        const result = await BankApi.transfer({
            fromAccountId: source.id,
            targetAccountNumber: target.accountNumber,
            amount,
            description
        });
        await completeTransfer(result, amount);
    } catch (error) {
        toast(error.message, 'error');
    } finally {
        endTransfer(event.target);
    }
}

function renderPhoneTransfer(area) {
    area.innerHTML =
        '<form class="transfer-form" id="transfer-phone-form">' +
            '<label class="field"><span>Счёт списания</span><select id="transfer-phone-source">' +
                sourceAccountOptions(state.accounts[0].id) + '</select></label>' +
            '<label class="field"><span>Телефон получателя</span><input type="tel" id="transfer-phone-number" placeholder="+79991234567" required></label>' +
            '<div class="recipient-box" id="phone-recipient">Введите номер и нажмите «Проверить получателя».</div>' +
            '<label class="field"><span>Сумма, ₽</span><input type="number" id="transfer-phone-amount" min="0.01" step="0.01" placeholder="1000" required></label>' +
            '<label class="field"><span>Назначение</span><input type="text" id="transfer-phone-description" placeholder="Перевод по телефону"></label>' +
            '<div class="inline">' +
                '<button type="button" class="button button-secondary" id="lookup-phone">Проверить получателя</button>' +
                '<button type="submit" class="button button-primary">Перевести</button>' +
            '</div>' +
        '</form>';

    $('lookup-phone').addEventListener('click', lookupPhoneRecipient);
    $('transfer-phone-number').addEventListener('input', () => {
        $('phone-recipient').textContent = 'Введите номер и нажмите «Проверить получателя».';
    });
    $('transfer-phone-form').addEventListener('submit', handlePhoneTransfer);
}

async function lookupPhoneRecipient() {
    const box = $('phone-recipient');
    const phone = $('transfer-phone-number').value.trim();

    box.textContent = 'Ищем получателя…';
    try {
        const recipient = await BankApi.findRecipientByPhone(phone);
        box.innerHTML = '<strong>' + escapeHtml([recipient.firstName, recipient.lastName].filter(Boolean).join(' ')) + '</strong><br>' +
            accountTypeLabel(recipient.accountType) + ' · <span class="mono">' + recipient.accountNumber + '</span>';
    } catch (error) {
        box.textContent = error.message;
    }
}

async function handlePhoneTransfer(event) {
    event.preventDefault();

    const source = accountById(Number($('transfer-phone-source').value));
    const phone = $('transfer-phone-number').value.trim();
    const amount = parseAmount($('transfer-phone-amount').value);

    if (!source) return;
    if (!validateTransferAmount(source, amount)) return;

    if (!beginTransfer(event.target)) return;
    try {
        const result = await BankApi.transferByPhone({
            fromAccountId: source.id,
            phone,
            amount,
            description: $('transfer-phone-description').value.trim() || null
        });
        await completeTransfer(result, amount);
    } catch (error) {
        toast(error.message, 'error');
    } finally {
        endTransfer(event.target);
    }
}

function renderCardTransfer(area) {
    area.innerHTML =
        '<form class="transfer-form" id="transfer-card-form">' +
            '<label class="field"><span>Счёт списания</span><select id="transfer-card-source">' +
                sourceAccountOptions(state.accounts[0].id) + '</select></label>' +
            '<label class="field"><span>Номер карты получателя</span><input type="text" id="transfer-card-number" inputmode="numeric" maxlength="19" placeholder="2200 0000 0000 0000" required></label>' +
            '<div class="recipient-box" id="card-recipient">Введите 16 цифр и нажмите «Проверить карту».</div>' +
            '<label class="field"><span>Сумма, ₽</span><input type="number" id="transfer-card-amount" min="0.01" step="0.01" placeholder="1000" required></label>' +
            '<label class="field"><span>Назначение</span><input type="text" id="transfer-card-description" placeholder="Перевод на карту"></label>' +
            '<div class="inline">' +
                '<button type="button" class="button button-secondary" id="lookup-card">Проверить карту</button>' +
                '<button type="submit" class="button button-primary">Перевести</button>' +
            '</div>' +
        '</form>';

    $('lookup-card').addEventListener('click', lookupCardRecipient);
    $('transfer-card-number').addEventListener('input', () => {
        $('card-recipient').textContent = 'Введите 16 цифр и нажмите «Проверить карту».';
    });
    $('transfer-card-form').addEventListener('submit', handleCardTransfer);
}

async function lookupCardRecipient() {
    const box = $('card-recipient');
    const cardNumber = $('transfer-card-number').value.trim();

    box.textContent = 'Ищем карту…';
    try {
        const recipient = await BankApi.findRecipientByCard(cardNumber);
        box.innerHTML = '<strong>' + escapeHtml([recipient.firstName, recipient.lastName].filter(Boolean).join(' ')) + '</strong><br>' +
            recipient.maskedCardNumber + ' · ' + accountTypeLabel(recipient.accountType);
    } catch (error) {
        box.textContent = error.message;
    }
}

async function handleCardTransfer(event) {
    event.preventDefault();

    const source = accountById(Number($('transfer-card-source').value));
    const cardNumber = $('transfer-card-number').value.trim();
    const amount = parseAmount($('transfer-card-amount').value);

    if (!source) return;
    if (!validateTransferAmount(source, amount)) return;

    if (!beginTransfer(event.target)) return;
    try {
        const result = await BankApi.transferByCard({
            fromAccountId: source.id,
            cardNumber,
            amount,
            description: $('transfer-card-description').value.trim() || null
        });
        await completeTransfer(result, amount);
    } catch (error) {
        toast(error.message, 'error');
    } finally {
        endTransfer(event.target);
    }
}

function beginTransfer(form) {
    if (transferPending) return false;
    transferPending = true;

    const button = form.querySelector('button[type="submit"]');
    if (button) {
        button.disabled = true;
        button.textContent = 'Отправляем…';
    }
    return true;
}

function endTransfer(form) {
    transferPending = false;

    const button = form.querySelector('button[type="submit"]');
    if (button) {
        button.disabled = false;
        button.textContent = 'Перевести';
    }
}

function showTransferResult(result, amount) {
    if (result && result.requiresApproval) {
        toast(result.message, 'warning');
        return;
    }
    toast('Перевод выполнен: ' + formatMoney(amount), 'success');
}


async function renderInvestments(page, token) {
    await loadCoreData();
    if (token !== renderToken) return;

    const account = investmentAccount();

    if (!account) {
        page.innerHTML =
            '<div class="card" style="max-width:720px">' +
                '<h2>Инвестиционный счёт ещё не открыт</h2>' +
                '<p class="muted" style="margin:10px 0 18px">Откройте отдельный счёт, чтобы покупать акции, драгоценные металлы и валюту. ' +
                    'Цены акций обновляются каждые 3 секунды, металлы и валюта приходят из ЦБ РФ.</p>' +
                '<button type="button" class="button button-primary" data-action="open-investment">Открыть инвестиционный счёт</button>' +
            '</div>';
        return;
    }

    const [quotes, portfolio] = await Promise.all([
        BankApi.getQuotes(),
        BankApi.getPortfolio(account.id)
    ]);
    if (token !== renderToken) return;

    state.quotes = Array.isArray(quotes) ? quotes : [];
    state.portfolio = portfolio;

    if (!state.selectedSecurityId || !state.quotes.some((quote) => quote.id === state.selectedSecurityId)) {
        const firstStock = state.quotes.find((quote) => quote.kind === 'stock') || state.quotes[0];
        state.selectedSecurityId = firstStock ? firstStock.id : null;
    }

    page.innerHTML =
        '<div class="kpi-grid">' +
            '<div class="kpi kpi-accent"><span class="kpi-label">Портфель</span>' +
                '<span class="kpi-value" id="inv-total"></span>' +
                '<span class="kpi-note">Счёт ' + accountShortNumber(account) + '</span></div>' +
            '<div class="kpi"><span class="kpi-label">Свободно</span>' +
                '<span class="kpi-value" id="inv-free"></span>' +
                '<span class="kpi-note">Доступно для покупки</span></div>' +
            '<div class="kpi"><span class="kpi-label">В инструментах</span>' +
                '<span class="kpi-value" id="inv-holdings"></span>' +
                '<span class="kpi-note" id="inv-positions"></span></div>' +
            '<div class="kpi"><span class="kpi-label">Прибыль</span>' +
                '<span class="kpi-value" id="inv-profit"></span>' +
                '<span class="kpi-note">По текущим ценам</span></div>' +
        '</div>' +
        '<div class="investments-layout">' +
            '<div class="card">' +
                '<div class="card-head"><div><h2>Инструменты</h2><div class="subtitle">Акции меняются каждые 3 секунды</div></div></div>' +
                '<div class="toolbar" style="margin-bottom:12px">' +
                    '<div class="tabs" id="investment-kind-tabs">' +
                        investmentKindTab('all', 'Все') +
                        investmentKindTab('stock', 'Акции') +
                        investmentKindTab('metal', 'Металлы') +
                        investmentKindTab('currency', 'Валюта') +
                    '</div>' +
                    '<input type="search" id="investment-search" aria-label="Поиск по инструментам" placeholder="Поиск по тикеру или названию" ' +
                        'value="' + escapeHtml(state.investmentSearch) + '" style="margin-left:auto;max-width:280px">' +
                '</div>' +
                '<div class="table-wrap investments-table">' +
                    '<table><thead><tr><th>Инструмент</th><th class="num">Цена</th><th class="num">Изменение</th><th>Источник</th></tr></thead>' +
                    '<tbody id="quotes-body"></tbody></table>' +
                '</div>' +
            '</div>' +
            '<div class="card trade-panel" id="trade-panel"></div>' +
        '</div>' +
        '<div class="card">' +
            '<div class="card-head"><div><h2>Мои активы</h2><div class="subtitle">Нажмите на позицию, чтобы продать её</div></div>' +
                '<button type="button" class="button button-secondary button-small" data-action="fund">Пополнить счёт</button></div>' +
            '<div id="holdings"></div>' +
        '</div>';

    renderQuoteTable();
    renderHoldings();
    renderTradePanel();
    updateInvestmentsSummary();
    startQuotesPolling(account.id);
}

function investmentKindTab(kind, label) {
    return '<button type="button" class="tab' + (state.investmentKind === kind ? ' active' : '') +
        '" data-action="investment-kind" data-kind="' + kind + '">' + label + '</button>';
}

function selectedQuote() {
    return state.quotes.find((quote) => quote.id === state.selectedSecurityId) || null;
}

function filteredQuotes() {
    return state.quotes.filter((quote) => {
        if (state.investmentKind !== 'all' && quote.kind !== state.investmentKind) return false;
        if (state.investmentSearch) {
            const haystack = (quote.ticker + ' ' + quote.name).toLowerCase();
            if (!haystack.includes(state.investmentSearch.toLowerCase())) return false;
        }
        return true;
    });
}

function priceClass(change) {
    const value = Number(change);
    if (value > 0) return 'price-up';
    if (value < 0) return 'price-down';
    return 'price-flat';
}

function changeText(quote) {
    const value = Number(quote.changePercent);
    const arrow = value > 0 ? '▲' : value < 0 ? '▼' : '—';
    return arrow + ' ' + formatPercent(value);
}

function sourceLabel(source) {
    return source === 'cbr' ? 'ЦБ РФ' : 'Симуляция';
}

function unitShort(kind) {
    if (kind === 'stock') return 'шт';
    if (kind === 'metal') return 'г';
    return 'ед.';
}

function quoteRowHtml(quote) {
    const cssClass = priceClass(quote.changePercent);
    const selected = quote.id === state.selectedSecurityId ? ' selected' : '';

    return '<tr class="quote-row' + selected + '" data-action="select-quote" data-id="' + quote.id + '" role="button" tabindex="0">' +
        '<td><strong>' + escapeHtml(quote.name) + '</strong>' +
            '<div class="muted small">' + quote.ticker + ' · ' + quote.unit + ' · ' + sourceLabel(quote.source) + '</div></td>' +
        '<td class="num quote-price ' + cssClass + '">' + formatMoney(quote.price) + '</td>' +
        '<td class="num quote-change ' + cssClass + '">' + changeText(quote) + '</td>' +
        '<td><span class="badge ' + (quote.source === 'cbr' ? 'badge-purple' : 'badge-blue') + '">' +
            sourceLabel(quote.source) + '</span></td>' +
        '</tr>';
}

function renderQuoteTable() {
    const body = $('quotes-body');
    if (!body) return;

    const rows = filteredQuotes().map(quoteRowHtml).join('');
    body.innerHTML = rows || emptyTableRow(4, 'Ничего не найдено');
}

function holdingForQuote(quote) {
    if (!state.portfolio || !Array.isArray(state.portfolio.holdings)) return null;
    return state.portfolio.holdings.find((holding) => holding.securityId === quote.id) || null;
}

function renderTradePanel() {
    const panel = $('trade-panel');
    if (!panel) return;

    const quote = selectedQuote();
    if (!quote) {
        panel.innerHTML = '<div class="empty-state">Выберите инструмент слева.</div>';
        return;
    }

    panel.innerHTML =
        '<div class="quote-title">' + escapeHtml(quote.name) + '</div>' +
        '<div class="trade-meta">' + quote.ticker + ' · ' + quote.unit + ' · ' + sourceLabel(quote.source) + '</div>' +
        '<div class="trade-price ' + priceClass(quote.changePercent) + '" id="trade-price">' + formatMoney(quote.price) + '</div>' +
        '<div class="' + priceClass(quote.changePercent) + '" id="trade-change">' + changeText(quote) + '</div>' +
        '<div style="height:16px"></div>' +
        '<label class="field"><span>Количество, ' + unitShort(quote.kind) + '</span>' +
            '<input type="number" id="trade-quantity" min="0.0001" step="' + (quote.kind === 'stock' ? '1' : '0.01') + '" value="1"></label>' +
        '<div class="trade-total"><span>Примерная сумма</span><strong id="trade-total">' + formatMoney(quote.price) + '</strong></div>' +
        '<div class="trade-actions">' +
            '<button type="button" class="button button-primary" data-action="buy">Купить</button>' +
            '<button type="button" class="button button-ghost" data-action="sell">Продать</button>' +
        '</div>' +
        '<div class="trade-hint" id="trade-hint"></div>';

    updateTradeHint();
    updateTradeTotal();
}

function updateTradeHint() {
    const hint = $('trade-hint');
    const quote = selectedQuote();
    if (!hint || !quote) return;

    const holding = holdingForQuote(quote);
    const free = state.portfolio ? Number(state.portfolio.balance) : 0;
    const quantity = holding ? Number(holding.quantity) : 0;

    hint.innerHTML = 'Свободно: <strong>' + formatMoney(free) + '</strong> · В портфеле: <strong>' +
        formatQuantity(quantity) + ' ' + unitShort(quote.kind) + '</strong>';
}

function updateTradeTotal() {
    const total = $('trade-total');
    const input = $('trade-quantity');
    const quote = selectedQuote();
    if (!total || !input || !quote) return;

    const quantity = parseAmount(input.value);
    total.textContent = formatMoney(Number.isFinite(quantity) ? quantity * Number(quote.price) : 0);
}

function updateInvestmentsSummary() {
    const portfolio = state.portfolio;
    const total = portfolio ? Number(portfolio.totalValue) : 0;
    const free = portfolio ? Number(portfolio.balance) : 0;
    const holdingsValue = portfolio ? Number(portfolio.holdingsValue) : 0;
    const holdingsCount = portfolio && Array.isArray(portfolio.holdings) ? portfolio.holdings.length : 0;
    const profit = portfolio && Array.isArray(portfolio.holdings)
        ? sumBy(portfolio.holdings, (holding) => holding.profit)
        : 0;

    if ($('inv-total')) $('inv-total').textContent = formatMoney(total);
    if ($('inv-free')) $('inv-free').textContent = formatMoney(free);
    if ($('inv-holdings')) $('inv-holdings').textContent = formatMoney(holdingsValue);
    if ($('inv-positions')) $('inv-positions').textContent =
        holdingsCount + ' ' + plural(holdingsCount, 'позиция', 'позиции', 'позиций');
    if ($('inv-profit')) {
        $('inv-profit').textContent = (profit >= 0 ? '+' : '−') + formatMoney(Math.abs(profit));
        $('inv-profit').className = 'kpi-value ' + (profit >= 0 ? 'positive' : 'negative');
    }
}

function renderHoldings() {
    const container = $('holdings');
    if (!container) return;

    const holdings = state.portfolio && Array.isArray(state.portfolio.holdings) ? state.portfolio.holdings : [];

    if (!holdings.length) {
        container.innerHTML = '<div class="empty-state"><strong>Покупок пока нет</strong>' +
            'Выберите инструмент слева и нажмите «Купить».</div>';
        return;
    }

    const rows = holdings.map((holding) => {
        const profitClass = Number(holding.profit) > 0 ? 'positive' : Number(holding.profit) < 0 ? 'negative' : 'muted';
        const profitPrefix = Number(holding.profit) > 0 ? '+' : Number(holding.profit) < 0 ? '−' : '';

        return '<tr class="quote-row" data-action="select-quote" data-id="' + holding.securityId + '" role="button" tabindex="0">' +
            '<td><strong>' + holding.ticker + '</strong><div class="muted small">' + escapeHtml(holding.name) + '</div></td>' +
            '<td class="num">' + formatQuantity(holding.quantity) + ' ' + unitShort(holding.kind) + '</td>' +
            '<td class="num">' + formatMoney(holding.avgPrice) + '</td>' +
            '<td class="num">' + formatMoney(holding.currentPrice) + '</td>' +
            '<td class="num"><strong>' + formatMoney(holding.value) + '</strong></td>' +
            '<td class="num"><span class="' + profitClass + '">' + profitPrefix + formatMoney(Math.abs(holding.profit)) + '</span></td>' +
            '</tr>';
    }).join('');

    container.innerHTML = '<div class="table-wrap"><table class="holdings-table">' +
        '<thead><tr><th>Инструмент</th><th class="num">Количество</th><th class="num">Средняя цена</th>' +
        '<th class="num">Текущая цена</th><th class="num">Стоимость</th><th class="num">Прибыль</th></tr></thead>' +
        '<tbody>' + rows + '</tbody></table></div>';
}

function selectQuote(securityId) {
    if (!state.quotes.some((quote) => quote.id === securityId)) return;

    state.selectedSecurityId = securityId;
    document.querySelectorAll('.quote-row').forEach((row) => {
        row.classList.toggle('selected', Number(row.dataset.id) === securityId);
    });
    renderTradePanel();
}

async function openInvestmentAccount() {
    try {
        await BankApi.openInvestment(state.user.id);
        toast('Инвестиционный счёт открыт.', 'success');
        await loadCoreData();
        renderPage();
    } catch (error) {
        toast(error.message, 'error');
    }
}

function submitTrade(isBuy) {
    const quote = selectedQuote();
    const account = investmentAccount();
    if (!quote || !account) return;

    const quantity = parseAmount($('trade-quantity').value);
    if (!Number.isFinite(quantity) || quantity <= 0) {
        toast('Введите количество больше нуля.', 'error');
        return;
    }

    if (!isBuy) {
        const holding = holdingForQuote(quote);
        if (!holding || quantity > Number(holding.quantity)) {
            toast('На счёте недостаточно этого инструмента для продажи.', 'error');
            return;
        }
    }

    const estimated = quantity * Number(quote.price);

    openModal({
        title: isBuy ? 'Покупка' : 'Продажа',
        bodyHtml:
            '<p><strong>' + escapeHtml(quote.name) + '</strong> (' + quote.ticker + ')</p>' +
            '<p>Количество: <strong>' + formatQuantity(quantity) + ' ' + unitShort(quote.kind) + '</strong></p>' +
            '<p>Примерная сумма: <strong>' + formatMoney(estimated) + '</strong></p>' +
            '<p class="muted small">Итоговая цена фиксируется сервером в момент сделки и может немного отличаться.</p>',
        confirmText: isBuy ? 'Купить' : 'Продать',
        onConfirm: async () => {
            const result = isBuy
                ? await BankApi.buy(account.id, quote.id, quantity)
                : await BankApi.sell(account.id, quote.id, quantity);

            toast(result.message, 'success');
            await loadCoreData();
            state.portfolio = await BankApi.getPortfolio(account.id);
            updateInvestmentsSummary();
            renderHoldings();
            renderTradePanel();
        }
    });
}

function openFundModal() {
    const account = investmentAccount();
    if (!account) return;

    const sources = state.accounts.filter((item) =>
        item.id !== account.id && item.status === 'active' && item.currency === account.currency);

    if (!sources.length) {
        toast('Нет счёта, с которого можно пополнить инвестиционный счёт.', 'error');
        return;
    }

    const sourceOptions = sources.map((source) =>
        '<option value="' + source.id + '">' + accountTitle(source) + ' — ' + formatMoney(source.balance) + '</option>').join('');

    openModal({
        title: 'Пополнение инвестиционного счёта',
        bodyHtml:
            '<label class="field"><span>Счёт списания</span><select id="fund-source">' + sourceOptions + '</select></label>' +
            '<label class="field"><span>Сумма, ₽</span><input type="number" id="fund-amount" min="0.01" step="0.01" value="1000"></label>',
        confirmText: 'Пополнить',
        onConfirm: async () => {
            const source = accountById(Number($('fund-source').value));
            const amount = parseAmount($('fund-amount').value);

            if (!source) throw new Error('Выберите счёт списания.');
            if (!Number.isFinite(amount) || amount <= 0) throw new Error('Введите сумму больше нуля.');
            if (amount > Number(source.balance)) throw new Error('Недостаточно средств на счёте списания.');

            const result = await BankApi.transfer({
                fromAccountId: source.id,
                targetAccountNumber: account.accountNumber,
                amount,
                description: 'Пополнение инвестиционного счёта'
            });

            if (result && result.requiresApproval) {
                throw new Error(result.message);
            }

            toast('Счёт пополнен: ' + formatMoney(amount), 'success');
            await loadCoreData();
            state.portfolio = await BankApi.getPortfolio(account.id);
            updateInvestmentsSummary();
            renderHoldings();
            updateTradeHint();
        }
    });
}

function startQuotesPolling(accountId) {
    stopQuotesPolling();
    quotesPending = false;

    state.quotesTimer = setInterval(async () => {
        if (state.route !== 'investments') return;
        if (quotesPending) return;

        quotesPending = true;
        try {
            const [quotes, portfolio] = await Promise.all([
                BankApi.getQuotes(),
                BankApi.getPortfolio(accountId)
            ]);
            state.quotes = Array.isArray(quotes) ? quotes : state.quotes;
            state.portfolio = portfolio;
            applyQuotesToUI();
            updateLastUpdated();
        } catch {
            // Следующая попытка через 3 секунды.
        } finally {
            quotesPending = false;
        }
    }, QUOTES_REFRESH_MS);
}

function stopQuotesPolling() {
    quotesPending = false;
    if (state.quotesTimer) {
        clearInterval(state.quotesTimer);
        state.quotesTimer = null;
    }
}

function applyQuotesToUI() {
    state.quotes.forEach((quote) => {
        const row = document.querySelector('#quotes-body tr[data-id="' + quote.id + '"]');
        if (!row) return;

        const priceCell = row.querySelector('.quote-price');
        const changeCell = row.querySelector('.quote-change');

        if (priceCell) {
            priceCell.textContent = formatMoney(quote.price);
            priceCell.className = 'num quote-price ' + priceClass(quote.changePercent);
        }
        if (changeCell) {
            changeCell.textContent = changeText(quote);
            changeCell.className = 'num quote-change ' + priceClass(quote.changePercent);
        }
    });

    const quote = selectedQuote();
    if (quote && $('trade-price')) {
        $('trade-price').textContent = formatMoney(quote.price);
        $('trade-price').className = 'trade-price ' + priceClass(quote.changePercent);
        $('trade-change').textContent = changeText(quote);
        $('trade-change').className = priceClass(quote.changePercent);
    }

    updateTradeHint();
    updateTradeTotal();
    updateInvestmentsSummary();
    renderHoldings();
}


async function renderAnalytics(page, token) {
    await loadCoreData();
    if (token !== renderToken) return;

    const months = [...new Set(state.transactions.map((item) => monthKey(item.createdAt)).filter(Boolean))]
        .sort()
        .reverse();
    const current = monthKey(new Date().toISOString());

    if (!months.includes(current)) months.unshift(current);
    if (!state.analyticsMonth || !months.includes(state.analyticsMonth)) {
        state.analyticsMonth = months[0];
    }

    const options = months.map((month) =>
        '<option value="' + month + '"' + (month === state.analyticsMonth ? ' selected' : '') + '>' +
        monthLabel(month) + '</option>').join('');

    page.innerHTML =
        '<div class="card">' +
            '<div class="card-head"><div><h2>Движение средств</h2><div class="subtitle">Переводы между своими счетами не считаются доходом или расходом</div></div>' +
                '<select id="analytics-month" aria-label="Месяц аналитики" style="max-width:220px">' + options + '</select></div>' +
            '<div id="analytics-content"></div>' +
        '</div>' +
        '<div class="card">' +
            '<div class="card-head"><div><h2>Распределение по счетам</h2><div class="subtitle">Доля каждого счёта в общем балансе</div></div></div>' +
            renderAccountsDistribution() +
        '</div>';

    renderAnalyticsContent();
}

function monthShortLabel(key) {
    const parts = String(key).split('-');
    const date = new Date(Number(parts[0]), Number(parts[1]) - 1, 1);
    return date.toLocaleDateString('ru-RU', { month: 'short', year: '2-digit' });
}

function lastMonthKeys(count) {
    const keys = [];
    const now = new Date();
    for (let index = count - 1; index >= 0; index--) {
        const date = new Date(now.getFullYear(), now.getMonth() - index, 1);
        keys.push(date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0'));
    }
    return keys;
}

function renderAnalyticsContent() {
    const container = $('analytics-content');
    if (!container) return;

    const month = state.analyticsMonth;
    const items = state.transactions.filter((item) => monthKey(item.createdAt) === month);

    let income = 0;
    let expense = 0;
    const byType = {};

    items.forEach((item) => {
        const direction = transactionDirection(item, null);
        const key = item.transactionType;
        if (!byType[key]) byType[key] = { count: 0, income: 0, expense: 0 };
        byType[key].count += 1;

        if (direction === 'in') {
            income += Number(item.amount);
            byType[key].income += Number(item.amount);
        }
        if (direction === 'out') {
            expense += Number(item.amount);
            byType[key].expense += Number(item.amount);
        }
    });

    const typeRows = Object.entries(byType)
        .sort((a, b) => b[1].count - a[1].count)
        .map(([type, data]) =>
            '<tr>' +
                '<td><span class="badge">' + transactionTypeLabel(type) + '</span></td>' +
                '<td class="num">' + data.count + '</td>' +
                '<td class="num positive">' + (data.income ? '+' + formatMoney(data.income) : '—') + '</td>' +
                '<td class="num negative">' + (data.expense ? '−' + formatMoney(data.expense) : '—') + '</td>' +
            '</tr>').join('');

    const series = lastMonthKeys(6).map((key) => {
        let monthIncome = 0;
        let monthExpense = 0;
        state.transactions.forEach((item) => {
            if (monthKey(item.createdAt) !== key) return;
            const direction = transactionDirection(item, null);
            if (direction === 'in') monthIncome += Number(item.amount);
            if (direction === 'out') monthExpense += Number(item.amount);
        });
        return { key, income: monthIncome, expense: monthExpense };
    });

    const maxValue = Math.max(1, ...series.map((item) => Math.max(item.income, item.expense)));

    const barsHtml = series.map((item) =>
        '<div class="bar-row">' +
            '<span class="bar-label">' + monthShortLabel(item.key) + '</span>' +
            '<div class="bar-track">' +
                '<div class="bar bar-income" style="width:' + (item.income / maxValue * 100) + '%" title="Доходы: ' + formatMoney(item.income) + '"></div>' +
                '<div class="bar bar-expense" style="width:' + (item.expense / maxValue * 100) + '%" title="Расходы: ' + formatMoney(item.expense) + '"></div>' +
                '<span class="bar-value">' + (item.income > 0 ? '+' : '') + formatMoney(item.income) +
                    ' · ' + (item.expense > 0 ? '−' : '') + formatMoney(item.expense) + '</span>' +
            '</div>' +
        '</div>').join('');

    container.innerHTML =
        '<div class="kpi-grid">' +
            '<div class="kpi"><span class="kpi-label">Доходы</span>' +
                '<span class="kpi-value positive">' + (income > 0 ? '+' : '') + formatMoney(income) + '</span>' +
                '<span class="kpi-note">' + monthLabel(month) + '</span></div>' +
            '<div class="kpi"><span class="kpi-label">Расходы</span>' +
                '<span class="kpi-value negative">' + (expense > 0 ? '−' : '') + formatMoney(expense) + '</span>' +
                '<span class="kpi-note">' + monthLabel(month) + '</span></div>' +
            '<div class="kpi"><span class="kpi-label">Чистый поток</span>' +
                '<span class="kpi-value ' + (income - expense >= 0 ? 'positive' : 'negative') + '">' +
                    (income - expense >= 0 ? '+' : '−') + formatMoney(Math.abs(income - expense)) + '</span>' +
                '<span class="kpi-note">' + items.length + ' ' +
                    plural(items.length, 'операция', 'операции', 'операций') + '</span></div>' +
        '</div>' +
        '<div style="height:22px"></div>' +
        '<h3 style="margin-bottom:12px">Последние 6 месяцев</h3>' +
        '<div class="bars">' + barsHtml + '</div>' +
        '<div style="height:22px"></div>' +
        '<h3 style="margin-bottom:12px">По типам операций</h3>' +
        '<div class="table-wrap"><table><thead><tr><th>Тип</th><th class="num">Операций</th>' +
        '<th class="num">Доходы</th><th class="num">Расходы</th></tr></thead><tbody>' +
        (typeRows || emptyTableRow(4, 'В этом месяце операций нет')) +
        '</tbody></table></div>';
}

function renderAccountsDistribution() {
    const total = sumBy(state.accounts, (account) => account.balance);

    if (!state.accounts.length) {
        return '<div class="empty-state">Нет счетов.</div>';
    }

    const rows = state.accounts.map((account) => {
        const share = total > 0 ? (Number(account.balance) / total * 100) : 0;
        return '<tr>' +
            '<td><strong>' + accountTitle(account) + '</strong></td>' +
            '<td class="num">' + formatMoney(account.balance) + '</td>' +
            '<td class="num">' + share.toFixed(1).replace('.', ',') + '%</td>' +
            '</tr>';
    }).join('');

    return '<div class="table-wrap"><table><thead><tr><th>Счёт</th><th class="num">Баланс</th><th class="num">Доля</th></tr></thead>' +
        '<tbody>' + rows + '</tbody>' +
        '<tfoot><tr><td><strong>Итого</strong></td><td class="num"><strong>' + formatMoney(total) +
        '</strong></td><td class="num">100%</td></tr></tfoot></table></div>';
}


function renderProfile(page) {
    const user = state.user;
    const name = [user.firstName, user.lastName].filter(Boolean).join(' ') || '—';
    updateLastUpdated();

    page.innerHTML =
        '<div class="grid-2">' +
            '<div class="card">' +
                '<div class="card-head"><div><h2>Данные клиента</h2><div class="subtitle">Из базы данных банка</div></div></div>' +
                '<div class="profile-list">' +
                    profileRow('Имя', escapeHtml(name)) +
                    profileRow('Логин', escapeHtml(user.username)) +
                    profileRow('Email', escapeHtml(user.email || '—')) +
                    profileRow('Телефон', escapeHtml(user.phone || '—')) +
                    profileRow('Роль', escapeHtml(user.role || 'client')) +
                    profileRow('Статус', '<span class="' + statusBadgeClass(user.status) + '">' + statusLabel(user.status) + '</span>') +
                '</div>' +
            '</div>' +
            '<div class="card">' +
                '<div class="card-head"><div><h2>Сессия</h2><div class="subtitle">Вход только по логину и паролю</div></div></div>' +
                '<p class="muted" style="margin-bottom:16px">Сессия хранится в этом браузере. На других устройствах нужно войти отдельно. ' +
                    'В отличие от телефона, здесь не используется PIN-код.</p>' +
                '<div class="profile-list">' +
                    profileRow('Адрес сайта и API', '<span class="mono">' + escapeHtml(location.origin) + '</span>') +
                    profileRow('Обновление цен', 'Каждые 3 секунды') +
                    profileRow('Котировки ЦБ РФ', 'При старте и раз в 6 часов') +
                '</div>' +
                '<div style="height:20px"></div>' +
                '<button type="button" class="button button-primary" data-action="logout">Выйти из аккаунта</button>' +
            '</div>' +
        '</div>';
}

function profileRow(label, valueHtml) {
    return '<div class="profile-row"><span>' + label + '</span><span>' + valueHtml + '</span></div>';
}


function handlePageClick(event) {
    const actionElement = event.target.closest('[data-action]');
    if (!actionElement) return;

    const action = actionElement.dataset.action;

    switch (action) {
        case 'copy':
            copyText(actionElement.dataset.copy);
            break;
        case 'open-account':
            openAccount(actionElement.dataset.kind);
            break;
        case 'close-account':
            confirmCloseAccount(Number(actionElement.dataset.id));
            break;
        case 'sort-operations':
            toggleOperationSort(actionElement.dataset.key);
            break;
        case 'page-prev':
            changeOperationsPage(-1);
            break;
        case 'page-next':
            changeOperationsPage(1);
            break;
        case 'reset-filters':
            resetOperationFilters();
            break;
        case 'export-csv':
            exportOperationsCsv();
            break;
        case 'transfer-mode':
            state.transferMode = actionElement.dataset.mode;
            document.querySelectorAll('[data-action="transfer-mode"]').forEach((tab) => {
                tab.classList.toggle('active', tab.dataset.mode === state.transferMode);
            });
            renderTransferArea();
            break;
        case 'open-investment':
            openInvestmentAccount();
            break;
        case 'select-quote':
            selectQuote(Number(actionElement.dataset.id));
            break;
        case 'investment-kind':
            state.investmentKind = actionElement.dataset.kind;
            document.querySelectorAll('[data-action="investment-kind"]').forEach((tab) => {
                tab.classList.toggle('active', tab.dataset.kind === state.investmentKind);
            });
            renderQuoteTable();
            break;
        case 'buy':
            submitTrade(true);
            break;
        case 'sell':
            submitTrade(false);
            break;
        case 'fund':
            openFundModal();
            break;
        case 'logout':
            logout();
            break;
    }
}

function handlePageInput(event) {
    const target = event.target;

    if (target.id === 'trade-quantity') {
        updateTradeTotal();
        return;
    }

    if (target.id === 'filter-search') {
        state.operations.search = target.value;
        state.operations.page = 1;
        renderOperationsTable();
        return;
    }

    if (target.id === 'investment-search') {
        state.investmentSearch = target.value;
        renderQuoteTable();
    }
}

function handlePageChange(event) {
    const target = event.target;

    const filterMap = {
        'filter-account': 'accountId',
        'filter-type': 'type',
        'filter-sign': 'sign',
        'filter-from': 'from',
        'filter-to': 'to'
    };

    const key = filterMap[target.id];
    if (key) {
        state.operations[key] = target.value;
        state.operations.page = 1;
        renderOperationsTable();
        return;
    }

    if (target.id === 'analytics-month') {
        state.analyticsMonth = target.value;
        renderAnalyticsContent();
    }
}

function toggleOperationSort(key) {
    const filters = state.operations;
    if (filters.sortKey === key) {
        filters.sortDir = filters.sortDir === 'asc' ? 'desc' : 'asc';
    } else {
        filters.sortKey = key;
        filters.sortDir = 'desc';
    }
    filters.page = 1;
    renderOperationsTable();
}

function changeOperationsPage(delta) {
    state.operations.page = Math.max(1, state.operations.page + delta);
    renderOperationsTable();
}


function openModal({ title, bodyHtml, confirmText, cancelText = 'Отмена', danger = false, onConfirm }) {
    lastFocusedElement = document.activeElement;
    modalConfirming = false;
    $('modal-title').textContent = title;
    $('modal-body').innerHTML = bodyHtml;
    $('modal-actions').innerHTML =
        '<button type="button" class="button button-secondary" id="modal-cancel">' + cancelText + '</button>' +
        '<button type="button" class="button ' + (danger ? 'button-danger' : 'button-primary') + '" id="modal-confirm">' +
            confirmText + '</button>';

    $('modal-cancel').addEventListener('click', () => {
        if (!modalConfirming) closeModal();
    });
    $('modal-confirm').addEventListener('click', async () => {
        if (modalConfirming) return;

        const button = $('modal-confirm');
        let errorBox = $('modal-body').querySelector('.form-error');
        if (!errorBox) {
            errorBox = document.createElement('div');
            errorBox.className = 'form-error';
            errorBox.setAttribute('role', 'alert');
            $('modal-body').appendChild(errorBox);
        }
        errorBox.hidden = true;

        modalConfirming = true;
        button.disabled = true;
        try {
            await onConfirm();
            modalConfirming = false;
            closeModal();
        } catch (error) {
            errorBox.textContent = error.message;
            errorBox.hidden = false;
            button.disabled = false;
            modalConfirming = false;
        }
    });

    $('modal-backdrop').hidden = false;
    $('modal').focus();
}

function closeModal() {
    if (modalConfirming) return;

    $('modal-backdrop').hidden = true;
    $('modal-title').textContent = '';
    $('modal-body').innerHTML = '';
    $('modal-actions').innerHTML = '';
    modalConfirming = false;

    if (lastFocusedElement && document.contains(lastFocusedElement)) {
        lastFocusedElement.focus();
    }
    lastFocusedElement = null;
}

function toast(message, type = 'success') {
    const element = $('toast');
    element.textContent = message;
    element.className = 'toast ' + type;
    element.hidden = false;

    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
        element.hidden = true;
    }, 4200);
}

async function copyText(text) {
    if (!text) return;

    try {
        await navigator.clipboard.writeText(String(text));
    } catch {
        const area = document.createElement('textarea');
        area.value = String(text);
        document.body.appendChild(area);
        area.select();
        document.execCommand('copy');
        document.body.removeChild(area);
    }

    toast('Скопировано: ' + text, 'success');
}

function parseAmount(value) {
    return Number(String(value).trim().replace(',', '.'));
}
