import { state } from './state.js';
import { BankApi } from './api.js';
import {
    accountTitle,
    escapeHtml,
    formatDate,
    formatMoney,
    statusBadgeClass,
    statusLabel,
    transactionTypeLabel
} from './format.js';

export function sumBy(items, selector) {
    return items.reduce((total, item) => total + Number(selector(item) || 0), 0);
}

export function accountById(id) {
    return state.accounts.find((account) => account.id === id) || null;
}

export function accountBelongs(id) {
    return Boolean(accountById(id));
}

export function transactionDirection(transaction, accountId) {
    const fromId = transaction.fromAccountId;
    const toId = transaction.toAccountId;

    if (accountId) {
        if (fromId === accountId && toId === accountId) return 'internal';
        if (toId === accountId) return 'in';
        if (fromId === accountId) return 'out';
    }

    switch (transaction.transactionType) {
        case 'investment':
            return toId ? 'in' : 'out';
        case 'deposit':
        case 'interest':
        case 'income':
            return 'in';
        case 'withdrawal':
        case 'fee':
        case 'expense':
            return 'out';
        case 'transfer': {
            const fromOwn = accountBelongs(fromId);
            const toOwn = accountBelongs(toId);
            if (fromOwn && toOwn) return 'internal';
            if (toOwn) return 'in';
            if (fromOwn) return 'out';
            return 'internal';
        }
        default:
            return 'neutral';
    }
}

export function amountClass(direction) {
    if (direction === 'in') return 'amount-in';
    if (direction === 'out') return 'amount-out';
    return 'amount-internal';
}

export function amountPrefix(direction) {
    if (direction === 'in') return '+';
    if (direction === 'out') return '−';
    return '⇄ ';
}

export function transactionAccounts(transaction) {
    const from = accountById(transaction.fromAccountId);
    const to = accountById(transaction.toAccountId);
    const parts = [];

    if (from) parts.push(accountTitle(from));
    else if (transaction.fromAccountId) parts.push('Внешний счёт');

    if (to) parts.push(accountTitle(to));
    else if (transaction.toAccountId) parts.push('Внешний счёт');

    return parts.join(' → ') || '—';
}

export function operationRowHtml(transaction, accountId, compact = false) {
    const direction = transactionDirection(transaction, accountId);
    const amount = `<span class="${amountClass(direction)}">${amountPrefix(direction)}${formatMoney(transaction.amount)}</span>`;
    const description = escapeHtml(transaction.description || transactionTypeLabel(transaction.transactionType));

    if (compact) {
        return `
            <tr>
                <td class="small muted">${formatDate(transaction.createdAt)}</td>
                <td>${description}<div class="muted small">${transactionTypeLabel(transaction.transactionType)}</div></td>
                <td class="num">${amount}</td>
            </tr>`;
    }

    return `
        <tr>
            <td class="small muted">${formatDate(transaction.createdAt)}</td>
            <td>${description}</td>
            <td class="small muted">${transactionAccounts(transaction)}</td>
            <td><span class="badge">${transactionTypeLabel(transaction.transactionType)}</span></td>
            <td><span class="${statusBadgeClass(transaction.status)}">${statusLabel(transaction.status)}</span></td>
            <td class="num">${amount}</td>
        </tr>`;
}

export function emptyTableRow(columns, text) {
    return `<tr><td colspan="${columns}" class="empty-state">${escapeHtml(text)}</td></tr>`;
}

export function investmentAccount() {
    return state.accounts.find((account) => account.accountType === 'investment') || null;
}

export async function loadPortfolio() {
    const account = investmentAccount();
    if (!account) {
        state.portfolio = null;
        return null;
    }
    try {
        state.portfolio = await BankApi.getPortfolio(account.id);
    } catch {
        state.portfolio = null;
    }
    return state.portfolio;
}
