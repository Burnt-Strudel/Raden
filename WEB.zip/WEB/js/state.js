import { SESSION_KEY } from './config.js';

// Фильтры операций создаются в одном месте, чтобы начальное состояние
// и сброс фильтров не расходились.
export function createOperationFilters() {
    return {
        accountId: '',
        type: '',
        sign: 'all',
        search: '',
        from: '',
        to: '',
        sortKey: 'createdAt',
        sortDir: 'desc',
        page: 1
    };
}

export const state = {
    user: null,
    accounts: [],
    transactions: [],
    quotes: [],
    portfolio: null,
    route: 'overview',
    selectedSecurityId: null,
    investmentKind: 'all',
    investmentSearch: '',
    transferMode: 'own',
    operations: createOperationFilters(),
    analyticsMonth: '',
    quotesTimer: null,
    coreTimer: null
};

export function restoreSession() {
    try {
        const raw = localStorage.getItem(SESSION_KEY);
        if (raw) state.user = JSON.parse(raw);
    } catch {
        state.user = null;
    }
}

export function saveSession() {
    localStorage.setItem(SESSION_KEY, JSON.stringify(state.user));
}

export function clearSession() {
    localStorage.removeItem(SESSION_KEY);
    state.user = null;
}

// Данные банка сбрасываются отдельно от сессии: после выхода они не должны
// показываться следующему пользователю этого браузера.
export function resetData() {
    state.accounts = [];
    state.transactions = [];
    state.quotes = [];
    state.portfolio = null;
    state.selectedSecurityId = null;
    state.investmentKind = 'all';
    state.investmentSearch = '';
    state.transferMode = 'own';
    state.operations = createOperationFilters();
    state.analyticsMonth = '';
}
