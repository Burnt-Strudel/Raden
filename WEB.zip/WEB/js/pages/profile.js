import { state } from '../state.js';
import { escapeHtml, statusBadgeClass, statusLabel } from '../format.js';
import { updateLastUpdated } from '../ui.js';

export function renderProfile(page) {
    const user = state.user;
    const name = [user.firstName, user.lastName].filter(Boolean).join(' ') || '—';
    updateLastUpdated();

    page.innerHTML = `
        <div class="grid-2">
            <div class="card">
                <div class="card-head"><div><h2>Данные клиента</h2><div class="subtitle">Из базы данных банка</div></div></div>
                <div class="profile-list">
                    ${profileRow('Имя', escapeHtml(name))}
                    ${profileRow('Логин', escapeHtml(user.username))}
                    ${profileRow('Email', escapeHtml(user.email || '—'))}
                    ${profileRow('Телефон', escapeHtml(user.phone || '—'))}
                    ${profileRow('Роль', escapeHtml(user.role || 'client'))}
                    ${profileRow('Статус', `<span class="${statusBadgeClass(user.status)}">${statusLabel(user.status)}</span>`)}
                </div>
            </div>
            <div class="card">
                <div class="card-head"><div><h2>Сессия</h2><div class="subtitle">Вход только по логину и паролю</div></div></div>
                <p class="muted" style="margin-bottom:16px">Сессия хранится в этом браузере. На других устройствах нужно войти отдельно. В отличие от телефона, здесь не используется PIN-код.</p>
                <div class="profile-list">
                    ${profileRow('Адрес сайта и API', `<span class="mono">${escapeHtml(location.origin)}</span>`)}
                    ${profileRow('Обновление цен', 'Каждые 3 секунды')}
                    ${profileRow('Котировки ЦБ РФ', 'При старте и раз в 6 часов')}
                </div>
                <div style="height:20px"></div>
                <button type="button" class="button button-primary" data-action="logout">Выйти из аккаунта</button>
            </div>
        </div>`;
}

function profileRow(label, valueHtml) {
    return '<div class="profile-row"><span>' + label + '</span><span>' + valueHtml + '</span></div>';
}
