import { state } from '../state.js';
import { BankApi } from '../api.js';
import {
    accountTitle,
    formatMoney,
    maskCardNumber,
    plural,
    statusBadgeClass,
    statusLabel
} from '../format.js';
import { accountById, emptyTableRow, sumBy } from '../data.js';
import { loadCoreData } from '../core/polling.js';
import { isStale, renderPage } from '../core/router.js';
import { openModal, toast } from '../ui.js';

export async function renderAccounts(page, token) {
    await loadCoreData();
    if (isStale(token)) return;

    const hasRegular = state.accounts.some((account) => account.accountType === 'regular');
    const hasInvestment = state.accounts.some((account) => account.accountType === 'investment');

    const rows = state.accounts.length
        ? state.accounts.map((account) => {
            const closeButton = Number(account.balance) === 0
                ? `<button type="button" class="button button-small button-danger" data-action="close-account" data-id="${account.id}">Закрыть</button>`
                : '';

            return `
                <tr>
                    <td><strong>${accountTitle(account)}</strong><div class="muted small">${account.currency}</div></td>
                    <td><span class="mono copyable" data-action="copy" data-copy="${account.accountNumber}" role="button" tabindex="0" title="Скопировать номер">${account.accountNumber}</span></td>
                    <td><span class="mono copyable" data-action="copy" data-copy="${account.cardNumber}" role="button" tabindex="0" title="Скопировать номер карты">${maskCardNumber(account.cardNumber)}</span></td>
                    <td class="num"><strong>${formatMoney(account.balance)}</strong></td>
                    <td><span class="${statusBadgeClass(account.status)}">${statusLabel(account.status)}</span></td>
                    <td><div class="inline">
                        <a class="button button-small button-secondary" href="#/transfer">Перевести</a>
                        ${closeButton}
                    </div></td>
                </tr>`;
        }).join('')
        : emptyTableRow(6, 'Активных счетов нет');

    page.innerHTML = `
        <div class="kpi-grid">
            <div class="kpi kpi-accent"><span class="kpi-label">Всего на счетах</span>
                <span class="kpi-value">${formatMoney(sumBy(state.accounts, (account) => account.balance))}</span>
                <span class="kpi-note">${state.accounts.length} ${plural(state.accounts.length, 'активный счёт', 'активных счёта', 'активных счетов')}</span></div>
            <div class="kpi"><span class="kpi-label">Карт</span>
                <span class="kpi-value">${state.accounts.length}</span>
                <span class="kpi-note">У каждого счёта своя карта</span></div>
            <div class="kpi"><span class="kpi-label">Инвестиционный счёт</span>
                <span class="kpi-value">${hasInvestment ? 'Открыт' : 'Нет'}</span>
                <span class="kpi-note">Акции, металлы и валюта</span></div>
        </div>
        <div class="card">
            <div class="card-head"><div><h2>Все счета</h2><div class="subtitle">Нажмите на номер, чтобы скопировать</div></div></div>
            <div class="table-wrap"><table>
                <thead><tr><th>Счёт</th><th>Номер счёта</th><th>Карта</th><th class="num">Баланс</th><th>Статус</th><th>Действия</th></tr></thead>
                <tbody>${rows}</tbody>
            </table></div>
        </div>
        <div class="card">
            <div class="card-head"><div><h2>Открыть новый счёт</h2><div class="subtitle">Основной и инвестиционный — по одному на клиента</div></div></div>
            <div class="grid-3">
                ${openAccountCard('regular', 'Основной счёт', 'Для ежедневных платежей и переводов', hasRegular)}
                ${openAccountCard('savings', 'Накопительный', 'Можно открыть несколько, ставка 5% годовых', false)}
                ${openAccountCard('investment', 'Инвестиционный', 'Акции, драгоценные металлы и валюта', hasInvestment)}
            </div>
        </div>`;
}

function openAccountCard(kind, title, description, alreadyOpen) {
    return `
        <div class="account-mini">
            <span class="name">${title}</span>
            <span class="muted small">${description}</span>
            <div style="margin-top:10px">
                ${alreadyOpen
                    ? '<span class="badge badge-green">Уже открыт</span>'
                    : `<button type="button" class="button button-primary button-small" data-action="open-account" data-kind="${kind}">Открыть</button>`}
            </div>
        </div>`;
}

export async function openAccount(kind) {
    const actions = {
        regular: BankApi.openRegular,
        savings: BankApi.openSavings,
        investment: BankApi.openInvestment
    };

    const action = actions[kind];
    if (!action) return;

    try {
        await action(state.user.id);
        toast('Счёт открыт.', 'success');
        await loadCoreData();
        renderPage();
    } catch (error) {
        toast(error.message, 'error');
    }
}

export function confirmCloseAccount(accountId) {
    const account = accountById(accountId);
    if (!account) return;

    openModal({
        title: 'Закрыть счёт?',
        bodyHtml: `<p>${accountTitle(account)}</p>
            <p class="muted small">Счёт можно закрыть только с нулевым балансом. Действие необратимо.</p>`,
        confirmText: 'Закрыть',
        danger: true,
        onConfirm: async () => {
            await BankApi.closeAccount(account.id);
            toast('Счёт закрыт.', 'success');
            await loadCoreData();
            renderPage();
        }
    });
}
