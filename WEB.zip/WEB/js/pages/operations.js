import { OPERATIONS_PAGE_SIZE } from '../config.js';
import { createOperationFilters, state } from '../state.js';
import {
    accountTitle,
    escapeHtml,
    formatDate,
    formatMoney,
    statusLabel,
    transactionTypeLabel
} from '../format.js';
import {
    accountById,
    emptyTableRow,
    operationRowHtml,
    transactionDirection
} from '../data.js';
import { loadCoreData } from '../core/polling.js';
import { isStale, renderPage } from '../core/router.js';
import { $, toast } from '../ui.js';

export async function renderOperations(page, token) {
    await loadCoreData();
    if (isStale(token)) return;

    const filters = state.operations;
    const accountOptions = '<option value="">Все счета</option>' + state.accounts.map((account) =>
        `<option value="${account.id}"${String(account.id) === filters.accountId ? ' selected' : ''}>` +
        accountTitle(account) + '</option>').join('');

    const typeOptions = ['transfer', 'investment', 'deposit', 'withdrawal', 'interest', 'fee']
        .map((type) => `<option value="${type}"${type === filters.type ? ' selected' : ''}>` +
            transactionTypeLabel(type) + '</option>').join('');

    page.innerHTML = `
        <div class="card">
            <div class="card-head"><div><h2>История операций</h2><div class="subtitle">Фильтры работают по всем загруженным операциям</div></div>
                <button type="button" class="button button-secondary button-small" data-action="export-csv">Экспорт CSV</button></div>
            <div class="filters">
                <label class="field"><span>Счёт</span><select id="filter-account">${accountOptions}</select></label>
                <label class="field"><span>Тип</span><select id="filter-type"><option value="">Все типы</option>${typeOptions}</select></label>
                <label class="field"><span>Направление</span><select id="filter-sign">
                    <option value="all">Все</option>
                    <option value="in"${filters.sign === 'in' ? ' selected' : ''}>Доходы</option>
                    <option value="out"${filters.sign === 'out' ? ' selected' : ''}>Расходы</option>
                </select></label>
                <label class="field"><span>С даты</span><input type="date" id="filter-from" value="${filters.from}"></label>
                <label class="field"><span>По дату</span><input type="date" id="filter-to" value="${filters.to}"></label>
                <label class="field"><span>Поиск</span><input type="search" id="filter-search" placeholder="Описание или тип" value="${escapeHtml(filters.search)}"></label>
                <div class="filter-actions"><button type="button" class="button button-secondary" data-action="reset-filters">Сбросить</button></div>
            </div>
            <div class="summary-line" id="operations-summary"></div>
            <div id="operations-table"></div>
        </div>`;

    renderOperationsTable();
}

function filteredTransactions() {
    const filters = state.operations;
    const accountId = filters.accountId ? Number(filters.accountId) : null;

    const list = state.transactions.filter((transaction) => {
        if (accountId && transaction.fromAccountId !== accountId && transaction.toAccountId !== accountId) {
            return false;
        }
        if (filters.type && transaction.transactionType !== filters.type) return false;

        if (filters.from) {
            const from = new Date(filters.from + 'T00:00:00');
            if (new Date(transaction.createdAt) < from) return false;
        }
        if (filters.to) {
            const to = new Date(filters.to + 'T23:59:59');
            if (new Date(transaction.createdAt) > to) return false;
        }
        if (filters.search) {
            const haystack = ((transaction.description || '') + ' ' +
                transactionTypeLabel(transaction.transactionType)).toLowerCase();
            if (!haystack.includes(filters.search.toLowerCase())) return false;
        }
        if (filters.sign !== 'all') {
            const direction = transactionDirection(transaction, accountId);
            if (direction !== filters.sign) return false;
        }
        return true;
    });

    const multiplier = filters.sortDir === 'asc' ? 1 : -1;
    return list.sort((a, b) => {
        if (filters.sortKey === 'amount') {
            return (Number(a.amount) - Number(b.amount)) * multiplier;
        }
        return (new Date(a.createdAt) - new Date(b.createdAt)) * multiplier;
    });
}

export function renderOperationsTable() {
    const summary = $('operations-summary');
    const container = $('operations-table');
    if (!summary || !container) return;

    const filters = state.operations;
    const accountId = filters.accountId ? Number(filters.accountId) : null;
    const all = filteredTransactions();

    let income = 0;
    let expense = 0;
    all.forEach((transaction) => {
        const direction = transactionDirection(transaction, accountId);
        if (direction === 'in') income += Number(transaction.amount);
        if (direction === 'out') expense += Number(transaction.amount);
    });

    const pages = Math.max(1, Math.ceil(all.length / OPERATIONS_PAGE_SIZE));
    if (filters.page > pages) filters.page = pages;

    const start = (filters.page - 1) * OPERATIONS_PAGE_SIZE;
    const pageItems = all.slice(start, start + OPERATIONS_PAGE_SIZE);
    const arrow = (key) => filters.sortKey === key
        ? `<span class="sort-arrow">${filters.sortDir === 'asc' ? '▲' : '▼'}</span>`
        : '';

    const rows = pageItems.length
        ? pageItems.map((transaction) => operationRowHtml(transaction, accountId)).join('')
        : emptyTableRow(6, 'По выбранным фильтрам операций нет');

    summary.innerHTML =
        `<span>Найдено: <strong>${all.length}</strong></span>` +
        `<span>Доходы: <strong class="positive">${income > 0 ? '+' : ''}${formatMoney(income)}</strong></span>` +
        `<span>Расходы: <strong class="negative">${expense > 0 ? '−' : ''}${formatMoney(expense)}</strong></span>`;

    container.innerHTML = `
        <div class="table-wrap"><table>
            <thead><tr>
                <th class="sortable" data-action="sort-operations" data-key="createdAt">Дата${arrow('createdAt')}</th>
                <th>Описание</th>
                <th>Счёт</th>
                <th>Тип</th>
                <th>Статус</th>
                <th class="num sortable" data-action="sort-operations" data-key="amount">Сумма${arrow('amount')}</th>
            </tr></thead>
            <tbody>${rows}</tbody>
        </table></div>
        <div class="pager">
            <span>Страница ${filters.page} из ${pages}</span>
            <button type="button" class="button button-small button-secondary" data-action="page-prev"${filters.page <= 1 ? ' disabled' : ''}>Назад</button>
            <button type="button" class="button button-small button-secondary" data-action="page-next"${filters.page >= pages ? ' disabled' : ''}>Вперёд</button>
        </div>`;
}

export function resetOperationFilters() {
    state.operations = createOperationFilters();
    renderPage();
}

export function exportOperationsCsv() {
    const accountId = state.operations.accountId ? Number(state.operations.accountId) : null;
    const items = filteredTransactions();

    if (!items.length) {
        toast('Нет операций для экспорта.', 'error');
        return;
    }

    const header = ['Дата', 'Описание', 'Тип', 'Статус', 'Сумма', 'Направление', 'Счёт списания', 'Счёт зачисления'];
    const lines = [header.join(';')];

    items.forEach((transaction) => {
        const direction = transactionDirection(transaction, accountId);
        const directionLabel = direction === 'in' ? 'Доход' : direction === 'out' ? 'Расход' : 'Между счетами';
        const from = accountById(transaction.fromAccountId);
        const to = accountById(transaction.toAccountId);

        const cells = [
            formatDate(transaction.createdAt),
            transaction.description || '',
            transactionTypeLabel(transaction.transactionType),
            statusLabel(transaction.status),
            Number(transaction.amount).toFixed(2).replace('.', ','),
            directionLabel,
            from ? from.accountNumber : '',
            to ? to.accountNumber : ''
        ];

        lines.push(cells.map(csvCell).join(';'));
    });

    const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'operacii_' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(link.href), 0);
    toast('Экспортировано операций: ' + items.length, 'success');
}

// Значения, начинающиеся с = + - @, Excel принимает за формулу.
function csvCell(value) {
    const text = String(value ?? '');
    const safe = /^[=+\-@\t\r]/.test(text) ? "'" + text : text;
    return /[;"\r\n]/.test(safe) ? '"' + safe.replaceAll('"', '""') + '"' : safe;
}

export function toggleOperationSort(key) {
    const filters = state.operations;
    if (filters.sortKey === key) {
        filters.sortDir = filters.sortDir === 'asc' ? 'desc' : 'asc';
    } else {
        filters.sortKey = key;
        filters.sortDir = 'desc';
    }
    filters.page = 1;
    renderOperationsTable();
}

export function changeOperationsPage(delta) {
    state.operations.page = Math.max(1, state.operations.page + delta);
    renderOperationsTable();
}
