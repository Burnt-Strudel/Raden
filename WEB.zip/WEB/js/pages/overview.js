import { state } from '../state.js';
import {
    accountTitle,
    formatMoney,
    maskCardNumber,
    monthKey,
    monthLabel,
    plural
} from '../format.js';
import {
    emptyTableRow,
    loadPortfolio,
    operationRowHtml,
    sumBy,
    transactionDirection
} from '../data.js';
import { loadCoreData } from '../core/polling.js';
import { isStale } from '../core/router.js';

export async function renderOverview(page, token) {
    await loadCoreData();
    await loadPortfolio();
    if (isStale(token)) return;

    const totalBalance = sumBy(state.accounts, (account) => account.balance);
    const holdingsValue = state.portfolio ? Number(state.portfolio.holdingsValue) : 0;
    const portfolioValue = state.portfolio ? Number(state.portfolio.totalValue) : 0;
    const profit = state.portfolio ? sumBy(state.portfolio.holdings, (holding) => holding.profit) : 0;
    const currentMonth = monthKey(new Date());
    const monthTransactions = state.transactions.filter((item) => monthKey(item.createdAt) === currentMonth);

    let income = 0;
    let expense = 0;
    monthTransactions.forEach((item) => {
        const direction = transactionDirection(item, null);
        if (direction === 'in') income += Number(item.amount);
        if (direction === 'out') expense += Number(item.amount);
    });

    const recent = state.transactions.slice(0, 6);

    const accountsHtml = state.accounts.length
        ? state.accounts.map((account) => `
            <a class="account-mini" href="#/accounts">
                <span class="name">${accountTitle(account)}</span>
                <span class="number">${maskCardNumber(account.cardNumber)}</span>
                <span class="balance">${formatMoney(account.balance)}</span>
            </a>`).join('')
        : '<div class="empty-state">Активных счетов пока нет</div>';

    const recentHtml = recent.length
        ? recent.map((item) => operationRowHtml(item, null, true)).join('')
        : emptyTableRow(3, 'Операций пока нет');

    page.innerHTML = `
        <div class="kpi-grid kpi-grid-5">
            <div class="kpi kpi-accent">
                <span class="kpi-label">Общий баланс</span>
                <span class="kpi-value">${formatMoney(totalBalance)}</span>
                <span class="kpi-note">${state.accounts.length} ${plural(state.accounts.length, 'активный счёт', 'активных счёта', 'активных счетов')}</span>
            </div>
            <div class="kpi">
                <span class="kpi-label">С учётом активов</span>
                <span class="kpi-value">${formatMoney(totalBalance + holdingsValue)}</span>
                <span class="kpi-note">Счета и ценные бумаги</span>
            </div>
            <div class="kpi">
                <span class="kpi-label">Инвестиции</span>
                <span class="kpi-value">${formatMoney(portfolioValue)}</span>
                <span class="kpi-note ${profit >= 0 ? 'positive' : 'negative'}">Прибыль ${profit >= 0 ? '+' : '−'}${formatMoney(Math.abs(profit))}</span>
            </div>
            <div class="kpi">
                <span class="kpi-label">Доходы за месяц</span>
                <span class="kpi-value positive">${income > 0 ? '+' : ''}${formatMoney(income)}</span>
                <span class="kpi-note">${monthLabel(currentMonth)}</span>
            </div>
            <div class="kpi">
                <span class="kpi-label">Расходы за месяц</span>
                <span class="kpi-value negative">${expense > 0 ? '−' : ''}${formatMoney(expense)}</span>
                <span class="kpi-note">${monthLabel(currentMonth)}</span>
            </div>
        </div>
        <div class="inline">
            <a class="button button-primary" href="#/transfer">Новый перевод</a>
            <a class="button button-secondary" href="#/accounts">Открыть счёт</a>
            <a class="button button-secondary" href="#/investments">Инвестиции</a>
            <a class="button button-secondary" href="#/operations">Все операции</a>
        </div>
        <div class="grid-2">
            <div class="card">
                <div class="card-head"><div><h2>Счета</h2><div class="subtitle">Баланс и карты</div></div>
                    <a class="button button-secondary button-small" href="#/accounts">Подробнее</a></div>
                <div class="account-mini-grid">${accountsHtml}</div>
            </div>
            <div class="card">
                <div class="card-head"><div><h2>Последние операции</h2><div class="subtitle">Последние записи по всем счетам</div></div>
                    <a class="button button-secondary button-small" href="#/operations">Все</a></div>
                <div class="table-wrap"><table><tbody>${recentHtml}</tbody></table></div>
            </div>
        </div>`;
}
