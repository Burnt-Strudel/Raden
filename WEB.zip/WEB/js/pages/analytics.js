import { state } from '../state.js';
import { accountTitle, formatMoney, monthKey, monthLabel, plural, transactionTypeLabel } from '../format.js';
import { emptyTableRow, sumBy, transactionDirection } from '../data.js';
import { loadCoreData } from '../core/polling.js';
import { isStale } from '../core/router.js';
import { $ } from '../ui.js';

export async function renderAnalytics(page, token) {
    await loadCoreData();
    if (isStale(token)) return;

    const months = [...new Set(state.transactions.map((item) => monthKey(item.createdAt)).filter(Boolean))]
        .sort()
        .reverse();
    const current = monthKey(new Date());

    if (!months.includes(current)) months.unshift(current);
    if (!state.analyticsMonth || !months.includes(state.analyticsMonth)) {
        state.analyticsMonth = months[0];
    }

    const options = months.map((month) =>
        `<option value="${month}"${month === state.analyticsMonth ? ' selected' : ''}>` +
        monthLabel(month) + '</option>').join('');

    page.innerHTML = `
        <div class="card">
            <div class="card-head"><div><h2>Движение средств</h2><div class="subtitle">Переводы между своими счетами не считаются доходом или расходом</div></div>
                <select id="analytics-month" aria-label="Месяц аналитики" style="max-width:220px">${options}</select></div>
            <div id="analytics-content"></div>
        </div>
        <div class="card">
            <div class="card-head"><div><h2>Распределение по счетам</h2><div class="subtitle">Доля каждого счёта в общем балансе</div></div></div>
            ${renderAccountsDistribution()}
        </div>`;

    renderAnalyticsContent();
}

function monthShortLabel(key) {
    const parts = String(key).split('-');
    const date = new Date(Number(parts[0]), Number(parts[1]) - 1, 1);
    return date.toLocaleDateString('ru-RU', { month: 'short', year: '2-digit' });
}

function lastMonthKeys(count) {
    const keys = [];
    const now = new Date();
    for (let index = count - 1; index >= 0; index--) {
        const date = new Date(now.getFullYear(), now.getMonth() - index, 1);
        keys.push(date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0'));
    }
    return keys;
}

export function renderAnalyticsContent() {
    const container = $('analytics-content');
    if (!container) return;

    const month = state.analyticsMonth;
    const items = state.transactions.filter((item) => monthKey(item.createdAt) === month);

    let income = 0;
    let expense = 0;
    const byType = {};

    items.forEach((item) => {
        const direction = transactionDirection(item, null);
        const key = item.transactionType;
        if (!byType[key]) byType[key] = { count: 0, income: 0, expense: 0 };
        byType[key].count += 1;

        if (direction === 'in') {
            income += Number(item.amount);
            byType[key].income += Number(item.amount);
        }
        if (direction === 'out') {
            expense += Number(item.amount);
            byType[key].expense += Number(item.amount);
        }
    });

    const typeRows = Object.entries(byType)
        .sort((a, b) => b[1].count - a[1].count)
        .map(([type, data]) => `
            <tr>
                <td><span class="badge">${transactionTypeLabel(type)}</span></td>
                <td class="num">${data.count}</td>
                <td class="num positive">${data.income ? '+' + formatMoney(data.income) : '—'}</td>
                <td class="num negative">${data.expense ? '−' + formatMoney(data.expense) : '—'}</td>
            </tr>`).join('');

    const series = lastMonthKeys(6).map((key) => {
        let monthIncome = 0;
        let monthExpense = 0;
        state.transactions.forEach((item) => {
            if (monthKey(item.createdAt) !== key) return;
            const direction = transactionDirection(item, null);
            if (direction === 'in') monthIncome += Number(item.amount);
            if (direction === 'out') monthExpense += Number(item.amount);
        });
        return { key, income: monthIncome, expense: monthExpense };
    });

    const maxValue = Math.max(1, ...series.map((item) => Math.max(item.income, item.expense)));

    const barsHtml = series.map((item) => `
        <div class="bar-row">
            <span class="bar-label">${monthShortLabel(item.key)}</span>
            <div class="bar-track">
                <div class="bar bar-income" style="width:${item.income / maxValue * 100}%" title="Доходы: ${formatMoney(item.income)}"></div>
                <div class="bar bar-expense" style="width:${item.expense / maxValue * 100}%" title="Расходы: ${formatMoney(item.expense)}"></div>
                <span class="bar-value">${item.income > 0 ? '+' : ''}${formatMoney(item.income)} · ${item.expense > 0 ? '−' : ''}${formatMoney(item.expense)}</span>
            </div>
        </div>`).join('');

    container.innerHTML = `
        <div class="kpi-grid">
            <div class="kpi"><span class="kpi-label">Доходы</span>
                <span class="kpi-value positive">${income > 0 ? '+' : ''}${formatMoney(income)}</span>
                <span class="kpi-note">${monthLabel(month)}</span></div>
            <div class="kpi"><span class="kpi-label">Расходы</span>
                <span class="kpi-value negative">${expense > 0 ? '−' : ''}${formatMoney(expense)}</span>
                <span class="kpi-note">${monthLabel(month)}</span></div>
            <div class="kpi"><span class="kpi-label">Чистый поток</span>
                <span class="kpi-value ${income - expense >= 0 ? 'positive' : 'negative'}">${income - expense >= 0 ? '+' : '−'}${formatMoney(Math.abs(income - expense))}</span>
                <span class="kpi-note">${items.length} ${plural(items.length, 'операция', 'операции', 'операций')}</span></div>
        </div>
        <div style="height:22px"></div>
        <h3 style="margin-bottom:12px">Последние 6 месяцев</h3>
        <div class="bars">${barsHtml}</div>
        <div style="height:22px"></div>
        <h3 style="margin-bottom:12px">По типам операций</h3>
        <div class="table-wrap"><table><thead><tr><th>Тип</th><th class="num">Операций</th>
        <th class="num">Доходы</th><th class="num">Расходы</th></tr></thead><tbody>
        ${typeRows || emptyTableRow(4, 'В этом месяце операций нет')}
        </tbody></table></div>`;
}

function renderAccountsDistribution() {
    const total = sumBy(state.accounts, (account) => account.balance);

    if (!state.accounts.length) {
        return '<div class="empty-state">Нет счетов.</div>';
    }

    const rows = state.accounts.map((account) => {
        const share = total > 0 ? (Number(account.balance) / total * 100) : 0;
        return `
            <tr>
                <td><strong>${accountTitle(account)}</strong></td>
                <td class="num">${formatMoney(account.balance)}</td>
                <td class="num">${share.toFixed(1).replace('.', ',')}%</td>
            </tr>`;
    }).join('');

    return '<div class="table-wrap"><table><thead><tr><th>Счёт</th><th class="num">Баланс</th><th class="num">Доля</th></tr></thead>' +
        '<tbody>' + rows + '</tbody>' +
        '<tfoot><tr><td><strong>Итого</strong></td><td class="num"><strong>' + formatMoney(total) +
        '</strong></td><td class="num">100%</td></tr></tfoot></table></div>';
}
