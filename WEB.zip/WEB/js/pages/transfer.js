import { state } from '../state.js';
import { BankApi } from '../api.js';
import { accountTitle, accountTypeLabel, escapeHtml, formatMoney } from '../format.js';
import { accountById } from '../data.js';
import {
    isTransferPending,
    loadCoreData,
    setTransferPending
} from '../core/polling.js';
import { isStale } from '../core/router.js';
import { $, parseAmount, toast, updateLastUpdated } from '../ui.js';

export async function renderTransfer(page, token) {
    await loadCoreData();
    if (isStale(token)) return;

    const accountsHtml = state.accounts.map((account) => `
        <div class="transfer-account">
            <a href="#/accounts">${accountTitle(account)}</a>
            <strong>${formatMoney(account.balance)}</strong>
        </div>`).join('');

    page.innerHTML = `
        <div class="transfer-layout">
            <div class="card">
                <div class="card-head"><div><h2>Переводы</h2><div class="subtitle">Внутри банка — по номеру счёта, телефона или карты</div></div></div>
                <div class="tabs">
                    ${transferTab('own', 'Между своими')}
                    ${transferTab('phone', 'По телефону')}
                    ${transferTab('card', 'По карте')}
                </div>
                <div id="transfer-area" style="margin-top:20px"></div>
            </div>
            <div class="card">
                <div class="card-head"><div><h2>Ваши счета</h2><div class="subtitle">Доступные средства</div></div></div>
                ${accountsHtml}
                <p class="muted small" style="margin-top:16px">Переводы между своими счетами и внутри банка выполняются сразу, без комиссии.</p>
            </div>
        </div>`;

    renderTransferArea();
}

function transferTab(mode, label) {
    return `<button type="button" class="tab${state.transferMode === mode ? ' active' : ''}"` +
        ` data-action="transfer-mode" data-mode="${mode}">${label}</button>`;
}

function sourceAccountOptions(selectedId, disabledId = null) {
    return state.accounts.map((account) => {
        const selected = account.id === selectedId ? ' selected' : '';
        const disabled = account.id === disabledId ? ' disabled' : '';
        return `<option value="${account.id}"${selected}${disabled}>` +
            accountTitle(account) + ' — ' + formatMoney(account.balance) + '</option>';
    }).join('');
}

export function renderTransferArea() {
    const area = $('transfer-area');
    if (!area) return;

    if (!state.accounts.length) {
        area.innerHTML = '<div class="empty-state">Нет активных счетов для перевода.</div>';
        return;
    }

    if (state.transferMode === 'phone') {
        renderPhoneTransfer(area);
        return;
    }
    if (state.transferMode === 'card') {
        renderCardTransfer(area);
        return;
    }
    renderOwnTransfer(area);
}

function renderOwnTransfer(area) {
    const sourceId = Number(area.dataset.sourceId || 0) || state.accounts[0].id;
    const source = accountById(sourceId) || state.accounts[0];
    const target = state.accounts.find((account) => account.id !== source.id) || null;

    area.innerHTML = `
        <form class="transfer-form" id="transfer-own-form">
            <label class="field"><span>Счёт списания</span><select id="transfer-own-source">
                ${sourceAccountOptions(source.id)}</select></label>
            <label class="field"><span>Счёт зачисления</span><select id="transfer-own-target">
                ${target ? sourceAccountOptions(target.id, source.id) : ''}</select></label>
            <label class="field"><span>Сумма, ₽</span><input type="number" id="transfer-own-amount" min="0.01" step="0.01" placeholder="1000" required></label>
            <label class="field"><span>Назначение</span><input type="text" id="transfer-own-description" placeholder="Перевод между счетами"></label>
            <button type="submit" class="button button-primary" style="align-self:flex-start">Перевести</button>
        </form>`;

    $('transfer-own-source').addEventListener('change', () => {
        const newSource = Number($('transfer-own-source').value);
        $('transfer-area').dataset.sourceId = String(newSource);
        const newTarget = state.accounts.find((account) => account.id !== newSource);
        const targetSelect = $('transfer-own-target');
        targetSelect.innerHTML = newTarget ? sourceAccountOptions(newTarget.id, newSource) : '';
    });

    $('transfer-own-form').addEventListener('submit', handleOwnTransfer);
}

function renderPhoneTransfer(area) {
    area.innerHTML = `
        <form class="transfer-form" id="transfer-phone-form">
            <label class="field"><span>Счёт списания</span><select id="transfer-phone-source">
                ${sourceAccountOptions(state.accounts[0].id)}</select></label>
            <label class="field"><span>Телефон получателя</span><input type="tel" id="transfer-phone-number" placeholder="+79991234567" required></label>
            <div class="recipient-box" id="phone-recipient">Введите номер и нажмите «Проверить получателя».</div>
            <label class="field"><span>Сумма, ₽</span><input type="number" id="transfer-phone-amount" min="0.01" step="0.01" placeholder="1000" required></label>
            <label class="field"><span>Назначение</span><input type="text" id="transfer-phone-description" placeholder="Перевод по телефону"></label>
            <div class="inline">
                <button type="button" class="button button-secondary" id="lookup-phone">Проверить получателя</button>
                <button type="submit" class="button button-primary">Перевести</button>
            </div>
        </form>`;

    $('lookup-phone').addEventListener('click', lookupPhoneRecipient);
    $('transfer-phone-number').addEventListener('input', () => {
        $('phone-recipient').textContent = 'Введите номер и нажмите «Проверить получателя».';
    });
    $('transfer-phone-form').addEventListener('submit', handlePhoneTransfer);
}

function renderCardTransfer(area) {
    area.innerHTML = `
        <form class="transfer-form" id="transfer-card-form">
            <label class="field"><span>Счёт списания</span><select id="transfer-card-source">
                ${sourceAccountOptions(state.accounts[0].id)}</select></label>
            <label class="field"><span>Номер карты получателя</span><input type="text" id="transfer-card-number" inputmode="numeric" maxlength="19" placeholder="2200 0000 0000 0000" required></label>
            <div class="recipient-box" id="card-recipient">Введите 16 цифр и нажмите «Проверить карту».</div>
            <label class="field"><span>Сумма, ₽</span><input type="number" id="transfer-card-amount" min="0.01" step="0.01" placeholder="1000" required></label>
            <label class="field"><span>Назначение</span><input type="text" id="transfer-card-description" placeholder="Перевод на карту"></label>
            <div class="inline">
                <button type="button" class="button button-secondary" id="lookup-card">Проверить карту</button>
                <button type="submit" class="button button-primary">Перевести</button>
            </div>
        </form>`;

    $('lookup-card').addEventListener('click', lookupCardRecipient);
    $('transfer-card-number').addEventListener('input', () => {
        $('card-recipient').textContent = 'Введите 16 цифр и нажмите «Проверить карту».';
    });
    $('transfer-card-form').addEventListener('submit', handleCardTransfer);
}

async function lookupPhoneRecipient() {
    const box = $('phone-recipient');
    const phone = $('transfer-phone-number').value.trim();

    box.textContent = 'Ищем получателя…';
    try {
        const recipient = await BankApi.findRecipientByPhone(phone);
        box.innerHTML = '<strong>' + escapeHtml([recipient.firstName, recipient.lastName].filter(Boolean).join(' ')) + '</strong><br>' +
            accountTypeLabel(recipient.accountType) + ' · <span class="mono">' + escapeHtml(recipient.accountNumber) + '</span>';
    } catch (error) {
        box.textContent = error.message;
    }
}

async function lookupCardRecipient() {
    const box = $('card-recipient');
    const cardNumber = $('transfer-card-number').value.trim();

    box.textContent = 'Ищем карту…';
    try {
        const recipient = await BankApi.findRecipientByCard(cardNumber);
        box.innerHTML = '<strong>' + escapeHtml([recipient.firstName, recipient.lastName].filter(Boolean).join(' ')) + '</strong><br>' +
            escapeHtml(recipient.maskedCardNumber) + ' · ' + accountTypeLabel(recipient.accountType);
    } catch (error) {
        box.textContent = error.message;
    }
}

function validateTransferAmount(source, amount) {
    if (!Number.isFinite(amount) || amount <= 0) {
        toast('Введите сумму больше нуля.', 'error');
        return false;
    }
    if (amount > Number(source.balance)) {
        toast('Недостаточно средств на счёте списания.', 'error');
        return false;
    }
    return true;
}

async function completeTransfer(result, amount) {
    showTransferResult(result, amount);
    await loadCoreData();
    renderTransferArea();
    updateLastUpdated();
}

function showTransferResult(result, amount) {
    if (result && result.requiresApproval) {
        toast(result.message, 'warning');
        return;
    }
    toast('Перевод выполнен: ' + formatMoney(amount), 'success');
}

// Все три формы переводов отличаются только сборкой запроса и вызовом API:
// проверка суммы, блокировка кнопки и обновление данных общие.
async function submitTransfer(event, createRequest) {
    event.preventDefault();

    const request = createRequest();
    if (!request) return;
    if (!validateTransferAmount(request.source, request.amount)) return;

    if (!beginTransfer(event.target)) return;
    try {
        const result = await request.send();
        await completeTransfer(result, request.amount);
    } catch (error) {
        toast(error.message, 'error');
    } finally {
        endTransfer(event.target);
    }
}

function handleOwnTransfer(event) {
    return submitTransfer(event, () => {
        const source = accountById(Number($('transfer-own-source').value));
        const target = accountById(Number($('transfer-own-target').value));

        if (!source || !target) {
            toast('Выберите счёт списания и зачисления.', 'error');
            return null;
        }
        if (source.id === target.id) {
            toast('Выберите разные счета.', 'error');
            return null;
        }

        const amount = parseAmount($('transfer-own-amount').value);
        const description = $('transfer-own-description').value.trim() || 'Перевод между счетами';

        return {
            source,
            amount,
            send: () => BankApi.transfer({
                fromAccountId: source.id,
                targetAccountNumber: target.accountNumber,
                amount,
                description
            })
        };
    });
}

function handlePhoneTransfer(event) {
    return submitTransfer(event, () => {
        const source = accountById(Number($('transfer-phone-source').value));
        if (!source) return null;

        const amount = parseAmount($('transfer-phone-amount').value);
        const phone = $('transfer-phone-number').value.trim();

        return {
            source,
            amount,
            send: () => BankApi.transferByPhone({
                fromAccountId: source.id,
                phone,
                amount,
                description: $('transfer-phone-description').value.trim() || null
            })
        };
    });
}

function handleCardTransfer(event) {
    return submitTransfer(event, () => {
        const source = accountById(Number($('transfer-card-source').value));
        if (!source) return null;

        const amount = parseAmount($('transfer-card-amount').value);
        const cardNumber = $('transfer-card-number').value.trim();

        return {
            source,
            amount,
            send: () => BankApi.transferByCard({
                fromAccountId: source.id,
                cardNumber,
                amount,
                description: $('transfer-card-description').value.trim() || null
            })
        };
    });
}

function beginTransfer(form) {
    if (isTransferPending()) return false;
    setTransferPending(true);

    const button = form.querySelector('button[type="submit"]');
    if (button) {
        button.disabled = true;
        button.textContent = 'Отправляем…';
    }
    return true;
}

function endTransfer(form) {
    setTransferPending(false);

    const button = form.querySelector('button[type="submit"]');
    if (button) {
        button.disabled = false;
        button.textContent = 'Перевести';
    }
}
