import { state } from '../state.js';
import { BankApi } from '../api.js';
import {
    accountShortNumber,
    accountTitle,
    escapeHtml,
    formatMoney,
    formatPercent,
    formatQuantity,
    plural
} from '../format.js';
import { accountById, emptyTableRow, investmentAccount, sumBy } from '../data.js';
import { loadCoreData, startQuotesPolling } from '../core/polling.js';
import { isStale, renderPage } from '../core/router.js';
import { $, openModal, parseAmount, toast } from '../ui.js';

export async function renderInvestments(page, token) {
    await loadCoreData();
    if (isStale(token)) return;

    const account = investmentAccount();

    if (!account) {
        page.innerHTML = `
            <div class="card" style="max-width:720px">
                <h2>Инвестиционный счёт ещё не открыт</h2>
                <p class="muted" style="margin:10px 0 18px">Откройте отдельный счёт, чтобы покупать акции, драгоценные металлы и валюту. Цены акций обновляются каждые 3 секунды, металлы и валюта приходят из ЦБ РФ.</p>
                <button type="button" class="button button-primary" data-action="open-investment">Открыть инвестиционный счёт</button>
            </div>`;
        return;
    }

    const [quotes, portfolio] = await Promise.all([
        BankApi.getQuotes(),
        BankApi.getPortfolio(account.id)
    ]);
    if (isStale(token)) return;

    state.quotes = Array.isArray(quotes) ? quotes : [];
    state.portfolio = portfolio;

    if (!state.selectedSecurityId || !state.quotes.some((quote) => quote.id === state.selectedSecurityId)) {
        const firstStock = state.quotes.find((quote) => quote.kind === 'stock') || state.quotes[0];
        state.selectedSecurityId = firstStock ? firstStock.id : null;
    }

    page.innerHTML = `
        <div class="kpi-grid">
            <div class="kpi kpi-accent"><span class="kpi-label">Портфель</span>
                <span class="kpi-value" id="inv-total"></span>
                <span class="kpi-note">Счёт ${accountShortNumber(account)}</span></div>
            <div class="kpi"><span class="kpi-label">Свободно</span>
                <span class="kpi-value" id="inv-free"></span>
                <span class="kpi-note">Доступно для покупки</span></div>
            <div class="kpi"><span class="kpi-label">В инструментах</span>
                <span class="kpi-value" id="inv-holdings"></span>
                <span class="kpi-note" id="inv-positions"></span></div>
            <div class="kpi"><span class="kpi-label">Прибыль</span>
                <span class="kpi-value" id="inv-profit"></span>
                <span class="kpi-note">По текущим ценам</span></div>
        </div>
        <div class="investments-layout">
            <div class="card">
                <div class="card-head"><div><h2>Инструменты</h2><div class="subtitle">Акции меняются каждые 3 секунды</div></div></div>
                <div class="toolbar" style="margin-bottom:12px">
                    <div class="tabs" id="investment-kind-tabs">
                        ${investmentKindTab('all', 'Все')}
                        ${investmentKindTab('stock', 'Акции')}
                        ${investmentKindTab('metal', 'Металлы')}
                        ${investmentKindTab('currency', 'Валюта')}
                    </div>
                    <input type="search" id="investment-search" aria-label="Поиск по инструментам" placeholder="Поиск по тикеру или названию" value="${escapeHtml(state.investmentSearch)}" style="margin-left:auto;max-width:280px">
                </div>
                <div class="table-wrap investments-table">
                    <table><thead><tr><th>Инструмент</th><th class="num">Цена</th><th class="num">Изменение</th><th>Источник</th></tr></thead>
                    <tbody id="quotes-body"></tbody></table>
                </div>
            </div>
            <div class="card trade-panel" id="trade-panel"></div>
        </div>
        <div class="card">
            <div class="card-head"><div><h2>Мои активы</h2><div class="subtitle">Нажмите на позицию, чтобы продать её</div></div>
                <button type="button" class="button button-secondary button-small" data-action="fund">Пополнить счёт</button></div>
            <div id="holdings"></div>
        </div>`;

    renderQuoteTable();
    renderHoldings();
    renderTradePanel();
    updateInvestmentsSummary();
    startQuotesPolling(account.id, applyQuotesToUI);
}

function investmentKindTab(kind, label) {
    return `<button type="button" class="tab${state.investmentKind === kind ? ' active' : ''}"` +
        ` data-action="investment-kind" data-kind="${kind}">${label}</button>`;
}

function selectedQuote() {
    return state.quotes.find((quote) => quote.id === state.selectedSecurityId) || null;
}

function filteredQuotes() {
    return state.quotes.filter((quote) => {
        if (state.investmentKind !== 'all' && quote.kind !== state.investmentKind) return false;
        if (state.investmentSearch) {
            const haystack = (quote.ticker + ' ' + quote.name).toLowerCase();
            if (!haystack.includes(state.investmentSearch.toLowerCase())) return false;
        }
        return true;
    });
}

function priceClass(change) {
    const value = Number(change);
    if (value > 0) return 'price-up';
    if (value < 0) return 'price-down';
    return 'price-flat';
}

function changeText(quote) {
    const value = Number(quote.changePercent);
    const arrow = value > 0 ? '▲' : value < 0 ? '▼' : '—';
    return arrow + ' ' + formatPercent(value);
}

function sourceLabel(source) {
    return source === 'cbr' ? 'ЦБ РФ' : 'Симуляция';
}

function unitShort(kind) {
    if (kind === 'stock') return 'шт';
    if (kind === 'metal') return 'г';
    return 'ед.';
}

function quoteRowHtml(quote) {
    const cssClass = priceClass(quote.changePercent);
    const selected = quote.id === state.selectedSecurityId ? ' selected' : '';

    return `
        <tr class="quote-row${selected}" data-action="select-quote" data-id="${quote.id}" role="button" tabindex="0">
            <td><strong>${escapeHtml(quote.name)}</strong><div class="muted small">${quote.ticker} · ${quote.unit} · ${sourceLabel(quote.source)}</div></td>
            <td class="num quote-price ${cssClass}">${formatMoney(quote.price)}</td>
            <td class="num quote-change ${cssClass}">${changeText(quote)}</td>
            <td><span class="badge ${quote.source === 'cbr' ? 'badge-purple' : 'badge-blue'}">${sourceLabel(quote.source)}</span></td>
        </tr>`;
}

export function renderQuoteTable() {
    const body = $('quotes-body');
    if (!body) return;

    const rows = filteredQuotes().map(quoteRowHtml).join('');
    body.innerHTML = rows || emptyTableRow(4, 'Ничего не найдено');
}

function holdingForQuote(quote) {
    if (!state.portfolio || !Array.isArray(state.portfolio.holdings)) return null;
    return state.portfolio.holdings.find((holding) => holding.securityId === quote.id) || null;
}

function renderTradePanel() {
    const panel = $('trade-panel');
    if (!panel) return;

    const quote = selectedQuote();
    if (!quote) {
        panel.innerHTML = '<div class="empty-state">Выберите инструмент слева.</div>';
        return;
    }

    panel.innerHTML = `
        <div class="quote-title">${escapeHtml(quote.name)}</div>
        <div class="trade-meta">${quote.ticker} · ${quote.unit} · ${sourceLabel(quote.source)}</div>
        <div class="trade-price ${priceClass(quote.changePercent)}" id="trade-price">${formatMoney(quote.price)}</div>
        <div class="${priceClass(quote.changePercent)}" id="trade-change">${changeText(quote)}</div>
        <div style="height:16px"></div>
        <label class="field"><span>Количество, ${unitShort(quote.kind)}</span>
            <input type="number" id="trade-quantity" min="0.0001" step="${quote.kind === 'stock' ? '1' : '0.01'}" value="1"></label>
        <div class="trade-total"><span>Примерная сумма</span><strong id="trade-total">${formatMoney(quote.price)}</strong></div>
        <div class="trade-actions">
            <button type="button" class="button button-primary" data-action="buy">Купить</button>
            <button type="button" class="button button-ghost" data-action="sell">Продать</button>
        </div>
        <div class="trade-hint" id="trade-hint"></div>`;

    updateTradeHint();
    updateTradeTotal();
}

function updateTradeHint() {
    const hint = $('trade-hint');
    const quote = selectedQuote();
    if (!hint || !quote) return;

    const holding = holdingForQuote(quote);
    const free = state.portfolio ? Number(state.portfolio.balance) : 0;
    const quantity = holding ? Number(holding.quantity) : 0;

    hint.innerHTML = 'Свободно: <strong>' + formatMoney(free) + '</strong> · В портфеле: <strong>' +
        formatQuantity(quantity) + ' ' + unitShort(quote.kind) + '</strong>';
}

export function updateTradeTotal() {
    const total = $('trade-total');
    const input = $('trade-quantity');
    const quote = selectedQuote();
    if (!total || !input || !quote) return;

    const quantity = parseAmount(input.value);
    total.textContent = formatMoney(Number.isFinite(quantity) ? quantity * Number(quote.price) : 0);
}

function updateInvestmentsSummary() {
    const portfolio = state.portfolio;
    const total = portfolio ? Number(portfolio.totalValue) : 0;
    const free = portfolio ? Number(portfolio.balance) : 0;
    const holdingsValue = portfolio ? Number(portfolio.holdingsValue) : 0;
    const holdingsCount = portfolio && Array.isArray(portfolio.holdings) ? portfolio.holdings.length : 0;
    const profit = portfolio && Array.isArray(portfolio.holdings)
        ? sumBy(portfolio.holdings, (holding) => holding.profit)
        : 0;

    if ($('inv-total')) $('inv-total').textContent = formatMoney(total);
    if ($('inv-free')) $('inv-free').textContent = formatMoney(free);
    if ($('inv-holdings')) $('inv-holdings').textContent = formatMoney(holdingsValue);
    if ($('inv-positions')) $('inv-positions').textContent =
        holdingsCount + ' ' + plural(holdingsCount, 'позиция', 'позиции', 'позиций');
    if ($('inv-profit')) {
        $('inv-profit').textContent = (profit >= 0 ? '+' : '−') + formatMoney(Math.abs(profit));
        $('inv-profit').className = 'kpi-value ' + (profit >= 0 ? 'positive' : 'negative');
    }
}

function renderHoldings() {
    const container = $('holdings');
    if (!container) return;

    const holdings = state.portfolio && Array.isArray(state.portfolio.holdings) ? state.portfolio.holdings : [];

    if (!holdings.length) {
        container.innerHTML = '<div class="empty-state"><strong>Покупок пока нет</strong>' +
            'Выберите инструмент слева и нажмите «Купить».</div>';
        return;
    }

    const rows = holdings.map((holding) => {
        const profitClass = Number(holding.profit) > 0 ? 'positive' : Number(holding.profit) < 0 ? 'negative' : 'muted';
        const profitPrefix = Number(holding.profit) > 0 ? '+' : Number(holding.profit) < 0 ? '−' : '';

        return `
            <tr class="quote-row" data-action="select-quote" data-id="${holding.securityId}" role="button" tabindex="0">
                <td><strong>${holding.ticker}</strong><div class="muted small">${escapeHtml(holding.name)}</div></td>
                <td class="num">${formatQuantity(holding.quantity)} ${unitShort(holding.kind)}</td>
                <td class="num">${formatMoney(holding.avgPrice)}</td>
                <td class="num">${formatMoney(holding.currentPrice)}</td>
                <td class="num"><strong>${formatMoney(holding.value)}</strong></td>
                <td class="num"><span class="${profitClass}">${profitPrefix}${formatMoney(Math.abs(holding.profit))}</span></td>
            </tr>`;
    }).join('');

    container.innerHTML = `
        <div class="table-wrap"><table class="holdings-table">
            <thead><tr><th>Инструмент</th><th class="num">Количество</th><th class="num">Средняя цена</th>
            <th class="num">Текущая цена</th><th class="num">Стоимость</th><th class="num">Прибыль</th></tr></thead>
            <tbody>${rows}</tbody></table></div>`;
}

export function selectQuote(securityId) {
    if (!state.quotes.some((quote) => quote.id === securityId)) return;

    state.selectedSecurityId = securityId;
    document.querySelectorAll('.quote-row').forEach((row) => {
        row.classList.toggle('selected', Number(row.dataset.id) === securityId);
    });
    renderTradePanel();
}

export async function openInvestmentAccount() {
    try {
        await BankApi.openInvestment(state.user.id);
        toast('Инвестиционный счёт открыт.', 'success');
        await loadCoreData();
        renderPage();
    } catch (error) {
        toast(error.message, 'error');
    }
}

export function submitTrade(isBuy) {
    const quote = selectedQuote();
    const account = investmentAccount();
    if (!quote || !account) return;

    const quantity = parseAmount($('trade-quantity').value);
    if (!Number.isFinite(quantity) || quantity <= 0) {
        toast('Введите количество больше нуля.', 'error');
        return;
    }

    if (!isBuy) {
        const holding = holdingForQuote(quote);
        if (!holding || quantity > Number(holding.quantity)) {
            toast('На счёте недостаточно этого инструмента для продажи.', 'error');
            return;
        }
    }

    const estimated = quantity * Number(quote.price);

    openModal({
        title: isBuy ? 'Покупка' : 'Продажа',
        bodyHtml:
            '<p><strong>' + escapeHtml(quote.name) + '</strong> (' + quote.ticker + ')</p>' +
            '<p>Количество: <strong>' + formatQuantity(quantity) + ' ' + unitShort(quote.kind) + '</strong></p>' +
            '<p>Примерная сумма: <strong>' + formatMoney(estimated) + '</strong></p>' +
            '<p class="muted small">Итоговая цена фиксируется сервером в момент сделки и может немного отличаться.</p>',
        confirmText: isBuy ? 'Купить' : 'Продать',
        onConfirm: async () => {
            const result = isBuy
                ? await BankApi.buy(account.id, quote.id, quantity)
                : await BankApi.sell(account.id, quote.id, quantity);

            toast(result.message, 'success');
            await loadCoreData();
            state.portfolio = await BankApi.getPortfolio(account.id);
            updateInvestmentsSummary();
            renderHoldings();
            renderTradePanel();
        }
    });
}

export function openFundModal() {
    const account = investmentAccount();
    if (!account) return;

    const sources = state.accounts.filter((item) =>
        item.id !== account.id && item.status === 'active' && item.currency === account.currency);

    if (!sources.length) {
        toast('Нет счёта, с которого можно пополнить инвестиционный счёт.', 'error');
        return;
    }

    const sourceOptions = sources.map((source) =>
        `<option value="${source.id}">` + accountTitle(source) + ' — ' + formatMoney(source.balance) + '</option>').join('');

    openModal({
        title: 'Пополнение инвестиционного счёта',
        bodyHtml:
            `<label class="field"><span>Счёт списания</span><select id="fund-source">${sourceOptions}</select></label>` +
            '<label class="field"><span>Сумма, ₽</span><input type="number" id="fund-amount" min="0.01" step="0.01" value="1000"></label>',
        confirmText: 'Пополнить',
        onConfirm: async () => {
            const source = accountById(Number($('fund-source').value));
            const amount = parseAmount($('fund-amount').value);

            if (!source) throw new Error('Выберите счёт списания.');
            if (!Number.isFinite(amount) || amount <= 0) throw new Error('Введите сумму больше нуля.');
            if (amount > Number(source.balance)) throw new Error('Недостаточно средств на счёте списания.');

            const result = await BankApi.transfer({
                fromAccountId: source.id,
                targetAccountNumber: account.accountNumber,
                amount,
                description: 'Пополнение инвестиционного счёта'
            });

            if (result && result.requiresApproval) {
                throw new Error(result.message);
            }

            toast('Счёт пополнен: ' + formatMoney(amount), 'success');
            await loadCoreData();
            state.portfolio = await BankApi.getPortfolio(account.id);
            updateInvestmentsSummary();
            renderHoldings();
            updateTradeHint();
        }
    });
}

function applyQuotesToUI() {
    state.quotes.forEach((quote) => {
        const row = document.querySelector('#quotes-body tr[data-id="' + quote.id + '"]');
        if (!row) return;

        const priceCell = row.querySelector('.quote-price');
        const changeCell = row.querySelector('.quote-change');

        if (priceCell) {
            priceCell.textContent = formatMoney(quote.price);
            priceCell.className = 'num quote-price ' + priceClass(quote.changePercent);
        }
        if (changeCell) {
            changeCell.textContent = changeText(quote);
            changeCell.className = 'num quote-change ' + priceClass(quote.changePercent);
        }
    });

    const quote = selectedQuote();
    if (quote && $('trade-price')) {
        $('trade-price').textContent = formatMoney(quote.price);
        $('trade-price').className = 'trade-price ' + priceClass(quote.changePercent);
        $('trade-change').textContent = changeText(quote);
        $('trade-change').className = priceClass(quote.changePercent);
    }

    updateTradeHint();
    updateTradeTotal();
    updateInvestmentsSummary();
    renderHoldings();
}
