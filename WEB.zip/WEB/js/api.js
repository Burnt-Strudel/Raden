// Сайт и API отдаются одним сервером, поэтому запросы идут по относительным путям.
// Это работает и локально (http://localhost:5025), и через публичный туннель.
async function apiRequest(path, options = {}) {
    const config = { ...options };

    if (config.body && typeof config.body !== 'string') {
        config.body = JSON.stringify(config.body);
    }

    config.headers = {
        ...(config.body ? { 'Content-Type': 'application/json' } : {}),
        ...(options.headers || {})
    };

    let response;
    try {
        response = await fetch(path, config);
    } catch (error) {
        throw new Error('API недоступно. Проверьте подключение.');
    }

    const text = await response.text();
    let data = null;

    if (text) {
        try {
            data = JSON.parse(text);
        } catch {
            data = text;
        }
    }

    if (!response.ok) {
        let message = response.status === 403 ? 'Доступ запрещён' : 'Ошибка запроса';
        if (typeof data === 'string' && data.trim()) {
            message = data.trim().replace(/^"|"$/g, '');
        } else if (data && typeof data === 'object' && data.title) {
            message = data.title;
        }
        throw new Error(message);
    }

    return data;
}

const BankApi = {
    login(username, password) {
        return apiRequest('/api/auth/login', {
            method: 'POST',
            body: { username, password }
        });
    },

    register(payload) {
        return apiRequest('/api/auth/register', {
            method: 'POST',
            body: payload
        });
    },

    getAccounts(userId) {
        return apiRequest('/api/accounts/' + userId);
    },

    getTransactions(userId) {
        return apiRequest('/api/transactions/' + userId);
    },

    transfer(payload) {
        return apiRequest('/api/accounts/transfer', {
            method: 'POST',
            body: payload
        });
    },

    transferByPhone(payload) {
        return apiRequest('/api/accounts/transfer-by-phone', {
            method: 'POST',
            body: payload
        });
    },

    transferByCard(payload) {
        return apiRequest('/api/accounts/transfer-by-card', {
            method: 'POST',
            body: payload
        });
    },

    findRecipientByPhone(phone) {
        return apiRequest('/api/accounts/recipient-by-phone?phone=' + encodeURIComponent(phone));
    },

    findRecipientByCard(cardNumber) {
        return apiRequest('/api/accounts/recipient-by-card?cardNumber=' + encodeURIComponent(cardNumber));
    },

    openRegular(userId) {
        return apiRequest('/api/accounts/regular/open/' + userId, { method: 'POST' });
    },

    openSavings(userId) {
        return apiRequest('/api/accounts/savings/open/' + userId, { method: 'POST' });
    },

    openInvestment(userId) {
        return apiRequest('/api/accounts/investment/open/' + userId, { method: 'POST' });
    },

    closeAccount(accountId) {
        return apiRequest('/api/accounts/' + accountId, { method: 'DELETE' });
    },

    getQuotes() {
        return apiRequest('/api/investments/quotes');
    },

    getPortfolio(accountId) {
        return apiRequest('/api/investments/portfolio/' + accountId);
    },

    buy(accountId, securityId, quantity) {
        return apiRequest('/api/investments/buy', {
            method: 'POST',
            body: { accountId, securityId, quantity }
        });
    },

    sell(accountId, securityId, quantity) {
        return apiRequest('/api/investments/sell', {
            method: 'POST',
            body: { accountId, securityId, quantity }
        });
    }
};
