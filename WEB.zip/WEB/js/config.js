export const SESSION_KEY = 'project_bank_web_user';
export const OPERATIONS_PAGE_SIZE = 20;
export const CORE_REFRESH_MS = 10000;
export const QUOTES_REFRESH_MS = 3000;

export const PAGE_META = {
    overview: { title: 'Обзор', subtitle: 'Ваши финансы в одном месте' },
    accounts: { title: 'Счета', subtitle: 'Все счета, карты и реквизиты' },
    operations: { title: 'Операции', subtitle: 'История с фильтрами, поиском и экспортом' },
    transfer: { title: 'Переводы', subtitle: 'Между своими счетами, по телефону и карте' },
    investments: { title: 'Инвестиции', subtitle: 'Акции, драгоценные металлы и валюта' },
    analytics: { title: 'Аналитика', subtitle: 'Доходы, расходы и динамика по месяцам' },
    profile: { title: 'Профиль', subtitle: 'Данные клиента и настройки сессии' }
};
