@echo off
chcp 65001 >nul
cd /d "%~dp0"

netstat -ano | findstr ":5025" | findstr "LISTENING" >nul
if errorlevel 1 (
    echo API не запущено. Поднимите контейнеры:
    echo   docker compose -f ..\API\compose.yaml up -d
    pause
    exit /b 1
)

echo Project Bank - веб-версия
echo Адрес: http://localhost:5025
echo Сайт и API отдаёт один контейнер bank-api.
echo.
start "" http://localhost:5025/
