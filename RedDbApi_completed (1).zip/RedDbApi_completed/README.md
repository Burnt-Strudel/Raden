# Учебная система — MySQL + ASP.NET Core API + Avalonia Desktop

Проект дополнен по заданию: REST API, Docker Compose для MySQL и API, настольный клиент Avalonia.

## Структура

- `RedDbApi/` — ASP.NET Core 8 Web API, EF Core и Pomelo MySQL provider.
- `RedDbDesktop/` — Avalonia Desktop-клиент.
- `docker-compose.yml` — запуск MySQL и API.
- `database/reddb.sql` — готовый SQL-скрипт: создаёт БД, четыре таблицы, внешние ключи, индексы и демонстрационные записи. Этот же скрипт Docker выполняет при первом старте MySQL.
- `docker/Dockerfile.api` — сборка и запуск API в контейнере.

## Запуск через Docker

Требуется установленный Docker Desktop (Windows/macOS) или Docker Engine + Compose (Linux).

В корне проекта выполните:

```bash
docker compose up --build -d
```

Проверка:
- Swagger API: http://localhost:5000/swagger
- API: http://localhost:5000/api/students
- MySQL с хоста: `localhost:3306`, база `reddb`, пользователь `reddb`, пароль `reddb123`.

Остановка:

```bash
docker compose down
```

Данные MySQL хранятся в Docker volume `mysql_data` и сохраняются после обычной остановки контейнеров. Чтобы удалить контейнеры **вместе со всеми данными БД**, используйте `docker compose down -v`.

> `docker/init.sql` запускается MySQL только при первичной инициализации пустого volume. Если volume уже существует, изменение SQL-файла само по себе не изменит существующую БД.

## Подключение к уже имеющейся базе данных

В исходном архиве не было готовой схемы БД. Поэтому подготовлена новая БД `reddb` по требованиям задания и имеющимся C# моделям. Скрипт `database/reddb.sql` содержит структуру и демонстрационные записи:
- `institutions` (`id`, `name`)
- `groups_tbl` (`id`, `name`, `course`, `status`)
- `students` (`id`, `fio`, `group_id`, `institution_id`, `status`)
- `exams` (`id`, `student_id`, `subject`, `exam_date`, `grade`, `status`)

### Импорт базы в DBeaver

1. Открой DBeaver и подключись к локальному MySQL.
2. Подключись пользователем с административными правами (нужны права CREATE USER и GRANT), открой SQL Editor и загрузи файл `database/reddb.sql`.
3. Выполни весь скрипт (Alt+X / Execute SQL Script).
4. Обнови дерево баз данных — должна появиться `reddb` с таблицами `institutions`, `groups_tbl`, `students`, `exams`.

Подключение для локального запуска API: `Server=localhost;Port=3306;Database=reddb;User=reddb;Password=reddb123;CharSet=utf8mb4;`. Для Docker API адрес сервера — `db`, как настроено в `docker-compose.yml`.

Скрипт создаёт демонстрационные записи, чтобы можно было сразу проверить списки в API и Desktop. Это учебные примеры, их можно изменить или удалить. Если у тебя уже есть база с такими именами, сделай резервную копию и не запускай скрипт вслепую: он не удаляет существующие таблицы, но может добавить демонстрационные строки с ID 1–3.

Для Docker SQL выполняется только при первой инициализации пустого volume `mysql_data`. Если volume уже создан, импортируй SQL отдельно в DBeaver либо удали volume командой `docker compose down -v` (это удалит все данные в контейнерной БД).

## Запуск Desktop

Desktop-клиент подключается к API по адресу `http://localhost:5000/`.

1. Сначала запустите Docker Compose и дождитесь готовности API.
2. Установите .NET 8 SDK.
3. Из корня проекта выполните:

```bash
dotnet run --project RedDbDesktop/RedDbDesktop.csproj
```

В приложении есть вкладки для студентов, групп, учебных заведений и экзаменов. На каждой вкладке доступны просмотр, добавление, изменение и удаление записей. Для связей указываются ID группы, учебного заведения и студента из соответствующих вкладок.

Если API размещён не на `localhost:5000`, измените `BaseAddress` в `RedDbDesktop/MainWindow.cs`.

## REST API

Для каждого ресурса доступны операции:
- `GET /api/students` и `GET /api/students/{id}`
- `POST /api/students`
- `PUT /api/students/{id}`
- `DELETE /api/students/{id}`

Аналогичные маршруты доступны для `groups`, `institutions`, `exams`.

Пример JSON для добавления студента:

```json
{
  "fio": "Иванов Иван Иванович",
  "groupId": 1,
  "institutionId": 1,
  "status": "активен"
}
```

Пример JSON для экзамена:

```json
{
  "studentId": 1,
  "subject": "Математика",
  "examDate": "2026-12-10T09:00:00",
  "grade": 5,
  "status": "сдан"
}
```

## Проверка

В среде подготовки архива не установлены .NET SDK и Docker, поэтому выполнить фактическую `dotnet build`, запуск контейнеров и интеграционные запросы здесь невозможно. Файлы проекта и конфигурации подготовлены, но окончательную проверку компиляции и подключения к вашей конкретной существующей БД нужно выполнить на машине с .NET 8 и Docker. Команды проверки:

```bash
dotnet build RedDbApi/RedDbApi.csproj
dotnet build RedDbDesktop/RedDbDesktop.csproj
docker compose config
docker compose up --build
```
