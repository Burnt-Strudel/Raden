using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RedDbApi.Models;

[Table("institutions")]
public class Institution
{
    [Key, Column("id")] public int Id { get; set; }
    [Required, MaxLength(255), Column("name")] public string Name { get; set; } = string.Empty;
}

[Table("groups_tbl")]
public class Group
{
    [Key, Column("id")] public int Id { get; set; }
    [Required, MaxLength(100), Column("name")] public string Name { get; set; } = string.Empty;
    [Range(1, 10), Column("course")] public int Course { get; set; }
    [Required, MaxLength(50), Column("status")] public string Status { get; set; } = "активна";
}

[Table("students")]
public class Student
{
    [Key, Column("id")] public int Id { get; set; }
    [Required, MaxLength(255), Column("fio")] public string Fio { get; set; } = string.Empty;
    [Column("group_id")] public int? GroupId { get; set; }
    [Column("institution_id")] public int? InstitutionId { get; set; }
    [Required, MaxLength(50), Column("status")] public string Status { get; set; } = "активен";
}

[Table("exams")]
public class Exam
{
    [Key, Column("id")] public int Id { get; set; }
    [Column("student_id")] public int StudentId { get; set; }
    [Required, MaxLength(255), Column("subject")] public string Subject { get; set; } = string.Empty;
    [Column("exam_date")] public DateTime? ExamDate { get; set; }
    [Range(1, 5), Column("grade")] public int? Grade { get; set; }
    [Required, MaxLength(50), Column("status")] public string Status { get; set; } = "запланирован";
}
