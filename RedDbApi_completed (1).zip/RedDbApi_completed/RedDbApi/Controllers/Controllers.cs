using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RedDbApi.Data;
using RedDbApi.Models;

namespace RedDbApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class InstitutionsController(AppDbContext db) : ControllerBase
{
    [HttpGet] public Task<List<Institution>> GetAll() => db.Institutions.AsNoTracking().OrderBy(x => x.Id).ToListAsync();
    [HttpGet("{id:int}")]
    public async Task<ActionResult<Institution>> Get(int id)
    {
        var item = await db.Institutions.FindAsync(id);
        if (item is null) return NotFound();
        return Ok(item);
    }
    [HttpPost] public async Task<ActionResult<Institution>> Create(Institution item)
    {
        item.Id = 0; db.Institutions.Add(item); await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = item.Id }, item);
    }
    [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id, Institution item)
    {
        if (id != item.Id) return BadRequest("ID в адресе и объекте не совпадают.");
        if (!await db.Institutions.AnyAsync(x => x.Id == id)) return NotFound();
        db.Entry(item).State = EntityState.Modified; await db.SaveChangesAsync(); return NoContent();
    }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id)
    {
        var item = await db.Institutions.FindAsync(id); if (item is null) return NotFound();
        db.Institutions.Remove(item); await db.SaveChangesAsync(); return NoContent();
    }
}

[ApiController]
[Route("api/[controller]")]
public class GroupsController(AppDbContext db) : ControllerBase
{
    [HttpGet] public Task<List<Group>> GetAll() => db.Groups.AsNoTracking().OrderBy(x => x.Id).ToListAsync();
    [HttpGet("{id:int}")]
    public async Task<ActionResult<Group>> Get(int id)
    {
        var item = await db.Groups.FindAsync(id);
        if (item is null) return NotFound();
        return Ok(item);
    }
    [HttpPost] public async Task<ActionResult<Group>> Create(Group item)
    {
        item.Id = 0; db.Groups.Add(item); await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = item.Id }, item);
    }
    [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id, Group item)
    {
        if (id != item.Id) return BadRequest("ID в адресе и объекте не совпадают.");
        if (!await db.Groups.AnyAsync(x => x.Id == id)) return NotFound();
        db.Entry(item).State = EntityState.Modified; await db.SaveChangesAsync(); return NoContent();
    }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id)
    {
        var item = await db.Groups.FindAsync(id); if (item is null) return NotFound();
        db.Groups.Remove(item); await db.SaveChangesAsync(); return NoContent();
    }
}

[ApiController]
[Route("api/[controller]")]
public class StudentsController(AppDbContext db) : ControllerBase
{
    [HttpGet] public Task<List<Student>> GetAll() => db.Students.AsNoTracking().OrderBy(x => x.Id).ToListAsync();
    [HttpGet("{id:int}")]
    public async Task<ActionResult<Student>> Get(int id)
    {
        var item = await db.Students.FindAsync(id);
        if (item is null) return NotFound();
        return Ok(item);
    }
    [HttpPost] public async Task<ActionResult<Student>> Create(Student item)
    {
        if (item.GroupId is int g && !await db.Groups.AnyAsync(x => x.Id == g)) return BadRequest("Указанная группа не существует.");
        if (item.InstitutionId is int i && !await db.Institutions.AnyAsync(x => x.Id == i)) return BadRequest("Учебное заведение не существует.");
        item.Id = 0; db.Students.Add(item); await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = item.Id }, item);
    }
    [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id, Student item)
    {
        if (id != item.Id) return BadRequest("ID в адресе и объекте не совпадают.");
        if (!await db.Students.AnyAsync(x => x.Id == id)) return NotFound();
        if (item.GroupId is int g && !await db.Groups.AnyAsync(x => x.Id == g)) return BadRequest("Указанная группа не существует.");
        if (item.InstitutionId is int i && !await db.Institutions.AnyAsync(x => x.Id == i)) return BadRequest("Учебное заведение не существует.");
        db.Entry(item).State = EntityState.Modified; await db.SaveChangesAsync(); return NoContent();
    }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id)
    {
        var item = await db.Students.FindAsync(id); if (item is null) return NotFound();
        db.Students.Remove(item); await db.SaveChangesAsync(); return NoContent();
    }
}

[ApiController]
[Route("api/[controller]")]
public class ExamsController(AppDbContext db) : ControllerBase
{
    [HttpGet] public Task<List<Exam>> GetAll() => db.Exams.AsNoTracking().OrderBy(x => x.Id).ToListAsync();
    [HttpGet("{id:int}")]
    public async Task<ActionResult<Exam>> Get(int id)
    {
        var item = await db.Exams.FindAsync(id);
        if (item is null) return NotFound();
        return Ok(item);
    }
    [HttpPost] public async Task<ActionResult<Exam>> Create(Exam item)
    {
        if (!await db.Students.AnyAsync(x => x.Id == item.StudentId)) return BadRequest("Указанный студент не существует.");
        item.Id = 0; db.Exams.Add(item); await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = item.Id }, item);
    }
    [HttpPut("{id:int}")] public async Task<IActionResult> Update(int id, Exam item)
    {
        if (id != item.Id) return BadRequest("ID в адресе и объекте не совпадают.");
        if (!await db.Exams.AnyAsync(x => x.Id == id)) return NotFound();
        if (!await db.Students.AnyAsync(x => x.Id == item.StudentId)) return BadRequest("Указанный студент не существует.");
        db.Entry(item).State = EntityState.Modified; await db.SaveChangesAsync(); return NoContent();
    }
    [HttpDelete("{id:int}")] public async Task<IActionResult> Delete(int id)
    {
        var item = await db.Exams.FindAsync(id); if (item is null) return NotFound();
        db.Exams.Remove(item); await db.SaveChangesAsync(); return NoContent();
    }
}
