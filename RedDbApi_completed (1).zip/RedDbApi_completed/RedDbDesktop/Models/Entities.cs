namespace RedDbDesktop.Models;

public sealed class Institution { public int Id { get; set; } public string Name { get; set; } = ""; }
public sealed class Group { public int Id { get; set; } public string Name { get; set; } = ""; public int Course { get; set; } public string Status { get; set; } = "активна"; }
public sealed class Student { public int Id { get; set; } public string Fio { get; set; } = ""; public int? GroupId { get; set; } public int? InstitutionId { get; set; } public string Status { get; set; } = "активен"; }
public sealed class Exam { public int Id { get; set; } public int StudentId { get; set; } public string Subject { get; set; } = ""; public DateTime? ExamDate { get; set; } public int? Grade { get; set; } public string Status { get; set; } = "запланирован"; }
