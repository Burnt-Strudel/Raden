using System.Collections.ObjectModel;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;
using RedDbDesktop.Models;

namespace RedDbDesktop;

public sealed class MainWindow : Window
{
    public MainWindow()
    {
        Title = "Управление учебным заведением";
        Width = 1050;
        Height = 720;
        MinWidth = 800;
        MinHeight = 550;

        var tabs = new TabControl();
        tabs.Items.Add(new TabItem { Header = "Студенты", Content = new CrudPage<Student>(
            "api/students", ["ФИО", "ID группы (необязательно)", "ID учебного заведения (необязательно)", "Статус"],
            f => new Student { Fio = f[0], GroupId = NullableInt(f[1]), InstitutionId = NullableInt(f[2]), Status = f[3] },
            x => [x.Fio, x.GroupId?.ToString() ?? "", x.InstitutionId?.ToString() ?? "", x.Status],
            x => $"#{x.Id} — {x.Fio} | группа: {x.GroupId?.ToString() ?? "—"} | {x.Status}") });
        tabs.Items.Add(new TabItem { Header = "Группы", Content = new CrudPage<Group>(
            "api/groups", ["Название", "Курс (1–10)", "Статус"],
            f => new Group { Name = f[0], Course = int.Parse(f[1]), Status = f[2] },
            x => [x.Name, x.Course.ToString(), x.Status],
            x => $"#{x.Id} — {x.Name} | курс {x.Course} | {x.Status}") });
        tabs.Items.Add(new TabItem { Header = "Учебные заведения", Content = new CrudPage<Institution>(
            "api/institutions", ["Название"],
            f => new Institution { Name = f[0] },
            x => [x.Name],
            x => $"#{x.Id} — {x.Name}") });
        tabs.Items.Add(new TabItem { Header = "Экзамены", Content = new CrudPage<Exam>(
            "api/exams", ["ID студента", "Предмет", "Дата (ГГГГ-ММ-ДД, необязательно)", "Оценка (1–5, необязательно)", "Статус"],
            f => new Exam { StudentId = int.Parse(f[0]), Subject = f[1], ExamDate = string.IsNullOrWhiteSpace(f[2]) ? null : DateTime.Parse(f[2], CultureInfo.InvariantCulture), Grade = NullableInt(f[3]), Status = f[4] },
            x => [x.StudentId.ToString(), x.Subject, x.ExamDate?.ToString("yyyy-MM-dd") ?? "", x.Grade?.ToString() ?? "", x.Status],
            x => $"#{x.Id} — студент {x.StudentId} | {x.Subject} | оценка: {x.Grade?.ToString() ?? "—"} | {x.Status}") });

        Content = tabs;
    }

    private static int? NullableInt(string value) =>
        string.IsNullOrWhiteSpace(value) ? null : int.Parse(value, CultureInfo.InvariantCulture);
}

internal sealed class CrudPage<T> : UserControl where T : class
{
    private static readonly HttpClient Client = new() { BaseAddress = new Uri("http://localhost:5000/") };
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNameCaseInsensitive = true };
    private readonly string _endpoint;
    private readonly Func<string[], T> _create;
    private readonly Func<T, string[]> _read;
    private readonly Func<T, string> _display;
    private readonly ObservableCollection<T> _items = new();
    private readonly ListBox _list = new() { MinHeight = 250 };
    private readonly TextBox[] _inputs;
    private readonly TextBlock _message = new() { TextWrapping = TextWrapping.Wrap };
    private int? _selectedId;

    public CrudPage(string endpoint, string[] labels, Func<string[], T> create,
        Func<T, string[]> read, Func<T, string> display)
    {
        _endpoint = endpoint;
        _create = create;
        _read = read;
        _display = display;
        _inputs = labels.Select(label => new TextBox { Watermark = label, MinWidth = 240 }).ToArray();

        var form = new StackPanel { Spacing = 8, Margin = new Thickness(12) };
        form.Children.Add(new TextBlock { Text = "Поля записи", FontSize = 18, FontWeight = FontWeight.SemiBold });
        foreach (var input in _inputs) form.Children.Add(input);

        var buttons = new WrapPanel { Orientation = Orientation.Horizontal };
        var add = new Button { Content = "Добавить", Margin = new Thickness(0, 4, 8, 4) };
        var update = new Button { Content = "Изменить выбранную", Margin = new Thickness(0, 4, 8, 4) };
        var delete = new Button { Content = "Удалить выбранную", Margin = new Thickness(0, 4, 8, 4) };
        var refresh = new Button { Content = "Обновить", Margin = new Thickness(0, 4, 8, 4) };
        var clear = new Button { Content = "Очистить форму", Margin = new Thickness(0, 4, 8, 4) };
        buttons.Children.Add(add); buttons.Children.Add(update); buttons.Children.Add(delete);
        buttons.Children.Add(refresh); buttons.Children.Add(clear);
        form.Children.Add(buttons);
        form.Children.Add(_message);

        _list.ItemsSource = _items;
        _list.SelectionChanged += (_, _) =>
        {
            if (_list.SelectedItem is T item)
            {
                _selectedId = (int?)typeof(T).GetProperty("Id")?.GetValue(item);
                var values = _read(item);
                for (var i = 0; i < _inputs.Length; i++) _inputs[i].Text = values[i];
                _message.Text = $"Выбрана запись ID {_selectedId}.";
            }
        };

        add.Click += async (_, _) => await Run(async () =>
        {
            var item = _create(Values());
            using var response = await Client.PostAsJsonAsync(_endpoint, item);
            await EnsureSuccess(response);
            ClearForm();
            await Reload();
            _message.Text = "Запись успешно добавлена.";
        });

        update.Click += async (_, _) => await Run(async () =>
        {
            if (_selectedId is null) throw new InvalidOperationException("Сначала выберите запись в списке.");
            var item = _create(Values());
            typeof(T).GetProperty("Id")!.SetValue(item, _selectedId.Value);
            using var response = await Client.PutAsJsonAsync($"{_endpoint}/{_selectedId}", item);
            await EnsureSuccess(response);
            ClearForm();
            await Reload();
            _message.Text = "Запись успешно изменена.";
        });

        delete.Click += async (_, _) => await Run(async () =>
        {
            if (_selectedId is null) throw new InvalidOperationException("Сначала выберите запись в списке.");
            using var response = await Client.DeleteAsync($"{_endpoint}/{_selectedId}");
            await EnsureSuccess(response);
            ClearForm();
            await Reload();
            _message.Text = "Запись удалена.";
        });

        refresh.Click += async (_, _) => await Run(async () => { await Reload(); _message.Text = "Список обновлён."; });
        clear.Click += (_, _) => ClearForm();

        var layout = new Grid { ColumnDefinitions = new ColumnDefinitions("2*,3*") };
        layout.Children.Add(new Border { Child = form, Padding = new Thickness(8) });
        var listPanel = new StackPanel { Spacing = 8, Margin = new Thickness(12) };
        listPanel.Children.Add(new TextBlock { Text = "Записи из базы данных", FontSize = 18, FontWeight = FontWeight.SemiBold });
        listPanel.Children.Add(new ScrollViewer { Content = _list });
        Grid.SetColumn(listPanel, 1);
        layout.Children.Add(listPanel);
        Content = layout;

        AttachedToVisualTree += async (_, _) => await Run(Reload);
    }

    private string[] Values() => _inputs.Select(x => x.Text?.Trim() ?? "").ToArray();

    private void ClearForm()
    {
        foreach (var input in _inputs) input.Text = "";
        _selectedId = null;
        _list.SelectedItem = null;
    }

    private async Task Reload()
    {
        var data = await Client.GetFromJsonAsync<List<T>>(_endpoint, JsonOptions) ?? [];
        _items.Clear();
        foreach (var item in data) _items.Add(item);
    }

    private async Task Run(Func<Task> action)
    {
        try { await action(); }
        catch (Exception ex) { _message.Text = $"Ошибка: {ex.Message}"; }
    }

    private static async Task EnsureSuccess(HttpResponseMessage response)
    {
        if (response.IsSuccessStatusCode) return;
        var body = await response.Content.ReadAsStringAsync();
        throw new HttpRequestException($"HTTP {(int)response.StatusCode}: {body}");
    }
}
