﻿using System;
using System.Collections.Generic;

namespace BankApi.Models;

public partial class Application
{
    public int Id { get; set; }

    public int UserId { get; set; }

    public string Type { get; set; } = null!;

    public string Status { get; set; } = null!;

    public string? Description { get; set; }

    public DateTime? CreatedAt { get; set; }

    public int? ProcessedBy { get; set; }

    public virtual User? ProcessedByNavigation { get; set; }

    public virtual User User { get; set; } = null!;
}
