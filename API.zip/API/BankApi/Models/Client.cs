﻿using System;
using System.Collections.Generic;

namespace BankApi.Models;

public partial class Client
{
    public int Id { get; set; }

    public int UserId { get; set; }

    public string? PassportNumber { get; set; }

    public string? Address { get; set; }

    public DateOnly? DateOfBirth { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual User User { get; set; } = null!;
}
