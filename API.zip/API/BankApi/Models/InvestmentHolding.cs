namespace BankApi.Models;

public partial class InvestmentHolding
{
    public int Id { get; set; }

    public int AccountId { get; set; }

    public int SecurityId { get; set; }

    public decimal Quantity { get; set; }

    public decimal AvgPrice { get; set; }

    public virtual Account Account { get; set; } = null!;

    public virtual Security Security { get; set; } = null!;
}
