﻿using System;
using System.Collections.Generic;

namespace BankApi.Models;

public partial class OperationHistory
{
    public int Id { get; set; }

    public int? TransactionId { get; set; }

    public int UserId { get; set; }

    public string Action { get; set; } = null!;

    public string? Details { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual Transaction? Transaction { get; set; }

    public virtual User User { get; set; } = null!;
}
