namespace BankApi.Models
{
    public record LoginDto(string Username, string Password);
    public record RegisterDto(string Username, string Password, string Email, string FirstName, string LastName, string Phone);
    public record UserDto(int Id, string Username, string Email, string? Phone, string? FirstName, string? LastName, string Role, string Status);
    public record AccountDto(int Id, string AccountNumber, string CardNumber, int UserId, string AccountType, decimal Balance, string Currency, string Status);
    public record TransferDto(int FromAccountId, string TargetAccountNumber, decimal Amount, string Description);
    public record ManagerActionDto(int RequestId, bool Approve, int ManagerUserId);

    public sealed class PhoneRecipientDto
    {
        public int UserId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public int AccountId { get; set; }
        public string AccountNumber { get; set; } = string.Empty;
        public string AccountType { get; set; } = string.Empty;
    }

    public sealed class TransferByPhoneDto
    {
        public int FromAccountId { get; set; }
        public string Phone { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string? Description { get; set; }
    }

    public sealed class TransferByCardDto
    {
        public int FromAccountId { get; set; }
        public string CardNumber { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string? Description { get; set; }
    }

    public sealed class CardRecipientDto
    {
        public int UserId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string MaskedCardNumber { get; set; } = string.Empty;
        public int AccountId { get; set; }
        public string AccountNumber { get; set; } = string.Empty;
        public string AccountType { get; set; } = string.Empty;
    }

    public sealed class TransferResultDto
    {
        public bool RequiresApproval { get; set; }
        public string Message { get; set; } = string.Empty;
    }

    public sealed class InvestmentQuoteDto
    {
        public int Id { get; set; }
        public string Ticker { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Kind { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public decimal PrevPrice { get; set; }
        public decimal Change { get; set; }
        public decimal ChangePercent { get; set; }
        public string Unit { get; set; } = string.Empty;
        public string Source { get; set; } = string.Empty;
        public DateTime UpdatedAt { get; set; }
    }

    public sealed class InvestmentHoldingDto
    {
        public int SecurityId { get; set; }
        public string Ticker { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Kind { get; set; } = string.Empty;
        public decimal Quantity { get; set; }
        public decimal AvgPrice { get; set; }
        public string Unit { get; set; } = string.Empty;
        public decimal CurrentPrice { get; set; }
        public decimal Value { get; set; }
        public decimal Profit { get; set; }
    }

    public sealed class InvestmentPortfolioDto
    {
        public int AccountId { get; set; }
        public decimal Balance { get; set; }
        public decimal HoldingsValue { get; set; }
        public decimal TotalValue { get; set; }
        public List<InvestmentHoldingDto> Holdings { get; set; } = new();
    }

    public sealed class InvestmentOrderDto
    {
        public int AccountId { get; set; }
        public int SecurityId { get; set; }
        public decimal Quantity { get; set; }
    }

    public sealed class InvestmentOrderResultDto
    {
        public string Message { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public decimal Quantity { get; set; }
        public decimal Total { get; set; }
        public decimal AccountBalance { get; set; }
    }
}
