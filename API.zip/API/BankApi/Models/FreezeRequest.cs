﻿using System;
using System.Collections.Generic;

namespace BankApi.Models;

public partial class FreezeRequest
{
    public int Id { get; set; }

    public int AccountId { get; set; }

    public int UserId { get; set; }

    public string? Reason { get; set; }

    public string? Status { get; set; }

    public int? RequestedByManager { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual Account Account { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
