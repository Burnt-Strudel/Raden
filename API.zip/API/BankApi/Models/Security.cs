namespace BankApi.Models;

public partial class Security
{
    public int Id { get; set; }

    public string Ticker { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Kind { get; set; } = null!;

    public decimal Price { get; set; }

    public decimal PrevPrice { get; set; }

    public string Unit { get; set; } = null!;

    public string Source { get; set; } = null!;

    public decimal StepPercent { get; set; }

    public int LastDirection { get; set; }

    public DateTime UpdatedAt { get; set; }

    public virtual ICollection<InvestmentHolding> Holdings { get; set; } = new List<InvestmentHolding>();

    public virtual ICollection<InvestmentOrder> Orders { get; set; } = new List<InvestmentOrder>();
}
