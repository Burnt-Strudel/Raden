﻿using System;
using System.Collections.Generic;

namespace BankApi.Models;

public partial class Transaction
{
    public int Id { get; set; }

    public int? FromAccountId { get; set; }

    public int? ToAccountId { get; set; }

    public int UserId { get; set; }

    public decimal Amount { get; set; }

    public string TransactionType { get; set; } = null!;

    public string? Status { get; set; }

    public string? Description { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual Account? FromAccount { get; set; }

    public virtual ICollection<OperationHistory> OperationHistories { get; set; } = new List<OperationHistory>();

    public virtual Account? ToAccount { get; set; }

    public virtual User User { get; set; } = null!;
}
