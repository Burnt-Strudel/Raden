﻿using System;
using System.Collections.Generic;

namespace BankApi.Models;

public partial class User
{
    public int Id { get; set; }

    public string Username { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? Phone { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string Role { get; set; } = null!;

    public string Status { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<Account> Accounts { get; set; } = new List<Account>();

    public virtual ICollection<Application> ApplicationProcessedByNavigations { get; set; } = new List<Application>();

    public virtual ICollection<Application> ApplicationUsers { get; set; } = new List<Application>();

    public virtual Client? Client { get; set; }

    public virtual ICollection<FreezeRequest> FreezeRequests { get; set; } = new List<FreezeRequest>();

    public virtual ICollection<OperationHistory> OperationHistories { get; set; } = new List<OperationHistory>();

    public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
}
