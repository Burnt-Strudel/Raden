namespace BankApi.Models;

public partial class InvestmentOrder
{
    public int Id { get; set; }

    public int AccountId { get; set; }

    public int SecurityId { get; set; }

    public string OrderType { get; set; } = null!;

    public decimal Quantity { get; set; }

    public decimal Price { get; set; }

    public decimal Total { get; set; }

    public DateTime? CreatedAt { get; set; }

    public virtual Account Account { get; set; } = null!;

    public virtual Security Security { get; set; } = null!;
}
