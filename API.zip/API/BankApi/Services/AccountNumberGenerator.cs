using BankApi.Models;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Services;

public static class AccountNumberGenerator
{
    public static async Task<string> GenerateUniqueAsync(BankingDbContext context, string prefix)
    {
        while (true)
        {
            var accountNumber = prefix + Random.Shared
                .NextInt64(0, 1_000_000_000_000)
                .ToString("D12");

            var exists = await context.Accounts
                .AnyAsync(a => a.AccountNumber == accountNumber);

            if (!exists)
                return accountNumber;
        }
    }
}
