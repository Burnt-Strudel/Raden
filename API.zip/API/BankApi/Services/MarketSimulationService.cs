using BankApi.Models;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Services
{
    /// <summary>
    /// Раз в 3 секунды меняет цены акций случайным образом.
    /// Если движение продолжает прошлое направление, шаг постепенно уменьшается,
    /// а при развороте — увеличивается. Так график выглядит живее, но без резких скачков.
    /// </summary>
    public class MarketSimulationService : BackgroundService
    {
        private static readonly TimeSpan Interval = TimeSpan.FromSeconds(3);
        private const decimal MinStep = 0.0004m;
        private const decimal MaxStep = 0.0120m;

        private readonly IServiceProvider _services;
        private readonly ILogger<MarketSimulationService> _logger;

        public MarketSimulationService(IServiceProvider services, ILogger<MarketSimulationService> logger)
        {
            _services = services;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await TickAsync(stoppingToken);
                }
                catch (Exception ex) when (ex is not OperationCanceledException)
                {
                    _logger.LogWarning(ex, "Не удалось обновить имитационные цены акций.");
                }

                try
                {
                    await Task.Delay(Interval, stoppingToken);
                }
                catch (OperationCanceledException)
                {
                    return;
                }
            }
        }

        private async Task TickAsync(CancellationToken token)
        {
            using var scope = _services.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<BankingDbContext>();

            var stocks = await context.Securities
                .Where(s => s.Source == "simulation")
                .ToListAsync(token);

            if (stocks.Count == 0)
                return;

            foreach (var stock in stocks)
            {
                var direction = Random.Shared.NextDouble() < 0.5 ? -1 : 1;

                stock.StepPercent = direction == stock.LastDirection
                    ? Math.Max(MinStep, stock.StepPercent * 0.88m)
                    : Math.Min(MaxStep, stock.StepPercent * 1.12m);

                var change = stock.Price * stock.StepPercent * direction;

                stock.PrevPrice = stock.Price;
                stock.Price = Math.Max(1m, Math.Round(stock.Price + change, 2));
                stock.LastDirection = direction;
                stock.UpdatedAt = DateTime.Now;
            }

            await context.SaveChangesAsync(token);
        }
    }
}
