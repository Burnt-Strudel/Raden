using System.Globalization;
using System.Text;
using System.Xml.Linq;
using BankApi.Models;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Services
{
    /// <summary>
    /// Загружает официальные курсы валют и цены на драгоценные металлы с сайта ЦБ РФ.
    /// Акции не загружаются: их цена имитируется в MarketSimulationService.
    /// </summary>
    public class CbrMarketService : BackgroundService
    {
        private const string DailyUrl = "https://www.cbr.ru/scripts/XML_daily.asp";
        private const string MetalsUrl = "https://www.cbr.ru/scripts/xml_metall.asp?date_req1={0}&date_req2={1}";

        private static readonly Dictionary<string, string> MetalCodes = new()
        {
            ["1"] = "XAU",
            ["2"] = "XAG",
            ["3"] = "XPT",
            ["4"] = "XPD"
        };

        private static readonly HashSet<string> CurrencyCodes = new() { "USD", "EUR", "CNY" };

        private readonly IHttpClientFactory _httpFactory;
        private readonly IServiceProvider _services;
        private readonly ILogger<CbrMarketService> _logger;

        public CbrMarketService(
            IHttpClientFactory httpFactory,
            IServiceProvider services,
            ILogger<CbrMarketService> logger)
        {
            _httpFactory = httpFactory;
            _services = services;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await RefreshAsync(stoppingToken);
                }
                catch (Exception ex) when (ex is not OperationCanceledException)
                {
                    _logger.LogWarning(ex, "Не удалось обновить данные ЦБ РФ, используются последние сохранённые цены.");
                }

                try
                {
                    await Task.Delay(TimeSpan.FromHours(6), stoppingToken);
                }
                catch (OperationCanceledException)
                {
                    return;
                }
            }
        }

        private async Task RefreshAsync(CancellationToken token)
        {
            var quotes = new Dictionary<string, decimal>();

            var client = _httpFactory.CreateClient("cbr");

            var currencyXml = await client.GetByteArrayAsync(DailyUrl, token);
            foreach (var (code, price) in ParseCurrencies(Decode1251(currencyXml)))
                quotes[code] = price;

            var today = DateTime.UtcNow.Date;
            var metalsUrl = string.Format(
                CultureInfo.InvariantCulture,
                MetalsUrl,
                today.AddDays(-10).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture),
                today.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));

            var metalsXml = await client.GetByteArrayAsync(metalsUrl, token);
            foreach (var (code, price) in ParseMetals(Decode1251(metalsXml)))
                quotes[code] = price;

            if (quotes.Count == 0)
            {
                _logger.LogWarning("ЦБ РФ вернул пустой ответ, цены оставлены без изменений.");
                return;
            }

            using var scope = _services.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<BankingDbContext>();

            var securities = await context.Securities
                .Where(s => s.Source == "cbr")
                .ToListAsync(token);

            var updated = 0;
            foreach (var security in securities)
            {
                if (!quotes.TryGetValue(security.Ticker, out var price) || price <= 0)
                    continue;

                security.PrevPrice = security.Price;
                security.Price = Math.Round(price, 4);
                security.UpdatedAt = DateTime.Now;
                updated++;
            }

            await context.SaveChangesAsync(token);
            _logger.LogInformation("Цены ЦБ РФ обновлены: {Count} инструментов.", updated);
        }

        private static string Decode1251(byte[] bytes)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            return Encoding.GetEncoding(1251).GetString(bytes);
        }

        private static IEnumerable<(string Code, decimal Price)> ParseCurrencies(string xml)
        {
            var document = XDocument.Parse(xml);

            foreach (var valute in document.Descendants("Valute"))
            {
                var code = (string?)valute.Element("CharCode");
                if (code == null || !CurrencyCodes.Contains(code))
                    continue;

                var nominal = ParseDecimal((string?)valute.Element("Nominal")) ?? 1m;
                var value = ParseDecimal((string?)valute.Element("Value"));
                if (value == null || nominal <= 0)
                    continue;

                yield return (code, value.Value / nominal);
            }
        }

        private static IEnumerable<(string Code, decimal Price)> ParseMetals(string xml)
        {
            var document = XDocument.Parse(xml);
            var latest = new Dictionary<string, (DateTime Date, decimal Price)>();

            foreach (var record in document.Descendants("Record"))
            {
                var metalCode = (string?)record.Attribute("Code");
                if (metalCode == null || !MetalCodes.TryGetValue(metalCode, out var ticker))
                    continue;

                if (!DateTime.TryParseExact(
                        (string?)record.Attribute("Date"),
                        "dd.MM.yyyy",
                        CultureInfo.InvariantCulture,
                        DateTimeStyles.None,
                        out var date))
                    continue;

                var buy = ParseDecimal((string?)record.Element("Buy"));
                var sell = ParseDecimal((string?)record.Element("Sell"));
                var price = buy.HasValue && sell.HasValue
                    ? (buy.Value + sell.Value) / 2m
                    : buy ?? sell;

                if (price is null or <= 0)
                    continue;

                if (!latest.TryGetValue(ticker, out var current) || date >= current.Date)
                    latest[ticker] = (date, price.Value);
            }

            return latest.Select(pair => (pair.Key, pair.Value.Price));
        }

        private static decimal? ParseDecimal(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            return decimal.TryParse(
                value.Replace(',', '.').Trim(),
                NumberStyles.Number,
                CultureInfo.InvariantCulture,
                out var result)
                ? result
                : null;
        }
    }
}
