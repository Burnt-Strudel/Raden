using BankApi.Models;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Services
{
    /// <summary>
    /// Приводит схему существующей базы к версии с инвестициями.
    /// Миграции EF в проекте не используются, поэтому DDL выполняется при старте API
    /// и безопасен для повторного запуска.
    /// </summary>
    public static class DatabaseInitializer
    {
        private static readonly string[] Statements =
        {
            @"ALTER TABLE accounts
              MODIFY account_type ENUM('regular','savings','investment') NOT NULL DEFAULT 'regular'",

            @"ALTER TABLE transactions
              MODIFY transaction_type ENUM('deposit','withdrawal','transfer','interest','fee','investment') NOT NULL",

            @"CREATE TABLE IF NOT EXISTS securities (
                id INT NOT NULL AUTO_INCREMENT,
                ticker VARCHAR(16) NOT NULL,
                name VARCHAR(100) NOT NULL,
                kind ENUM('stock','metal','currency') NOT NULL,
                price DECIMAL(18,4) NOT NULL,
                prev_price DECIMAL(18,4) NOT NULL,
                unit VARCHAR(16) NOT NULL,
                source ENUM('simulation','cbr') NOT NULL,
                step_percent DECIMAL(8,6) NOT NULL DEFAULT 0.004000,
                last_direction TINYINT NOT NULL DEFAULT 1,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY ticker (ticker)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            @"CREATE TABLE IF NOT EXISTS investment_holdings (
                id INT NOT NULL AUTO_INCREMENT,
                account_id INT NOT NULL,
                security_id INT NOT NULL,
                quantity DECIMAL(18,4) NOT NULL DEFAULT 0,
                avg_price DECIMAL(18,4) NOT NULL DEFAULT 0,
                PRIMARY KEY (id),
                UNIQUE KEY account_security (account_id, security_id),
                KEY security_id (security_id),
                CONSTRAINT investment_holdings_ibfk_1 FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE CASCADE,
                CONSTRAINT investment_holdings_ibfk_2 FOREIGN KEY (security_id) REFERENCES securities (id) ON DELETE CASCADE
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            @"CREATE TABLE IF NOT EXISTS investment_orders (
                id INT NOT NULL AUTO_INCREMENT,
                account_id INT NOT NULL,
                security_id INT NOT NULL,
                order_type ENUM('buy','sell') NOT NULL,
                quantity DECIMAL(18,4) NOT NULL,
                price DECIMAL(18,4) NOT NULL,
                total DECIMAL(15,2) NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY account_id (account_id),
                KEY security_id (security_id),
                CONSTRAINT investment_orders_ibfk_1 FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE CASCADE,
                CONSTRAINT investment_orders_ibfk_2 FOREIGN KEY (security_id) REFERENCES securities (id) ON DELETE CASCADE
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            @"INSERT IGNORE INTO securities
                (ticker, name, kind, price, prev_price, unit, source, step_percent, last_direction)
              VALUES
                ('SBER',  'Сбербанк',              'stock',    318.42,   318.42,   '₽/шт', 'simulation', 0.004000, 1),
                ('GAZP',  'Газпром',               'stock',    128.75,   128.75,   '₽/шт', 'simulation', 0.004000, 1),
                ('LKOH',  'Лукойл',                'stock',   6840.00,  6840.00,   '₽/шт', 'simulation', 0.004000, 1),
                ('YDEX',  'Яндекс',                'stock',   4325.50,  4325.50,   '₽/шт', 'simulation', 0.004000, 1),
                ('GMKN',  'Норникель',             'stock',    142.30,   142.30,   '₽/шт', 'simulation', 0.004000, 1),
                ('ROSN',  'Роснефть',              'stock',    598.80,   598.80,   '₽/шт', 'simulation', 0.004000, 1),
                ('MTSS',  'МТС',                   'stock',    276.45,   276.45,   '₽/шт', 'simulation', 0.004000, 1),
                ('AFLT',  'Аэрофлот',              'stock',     58.90,    58.90,   '₽/шт', 'simulation', 0.004000, 1),
                ('XAU',   'Золото',                'metal',  10861.28, 10861.28,   '₽/г',  'cbr',        0.000000, 1),
                ('XAG',   'Серебро',               'metal',    136.72,   136.72,   '₽/г',  'cbr',        0.000000, 1),
                ('XPT',   'Платина',               'metal',   3862.33,  3862.33,   '₽/г',  'cbr',        0.000000, 1),
                ('XPD',   'Палладий',              'metal',   2598.86,  2598.86,   '₽/г',  'cbr',        0.000000, 1),
                ('USD',   'Доллар США',            'currency',  78.50,    78.50,   '₽',    'cbr',        0.000000, 1),
                ('EUR',   'Евро',                  'currency',  91.20,    91.20,   '₽',    'cbr',        0.000000, 1),
                ('CNY',   'Китайский юань',        'currency',  10.85,    10.85,   '₽',    'cbr',        0.000000, 1)"
        };

        public static async Task InitializeAsync(BankingDbContext context, ILogger logger)
        {
            const int maxAttempts = 30;

            for (var attempt = 1; attempt <= maxAttempts; attempt++)
            {
                try
                {
                    foreach (var sql in Statements)
                        await context.Database.ExecuteSqlRawAsync(sql);

                    logger.LogInformation("Схема инвестиций готова (попытка {Attempt}).", attempt);
                    return;
                }
                catch (Exception ex) when (attempt < maxAttempts)
                {
                    logger.LogWarning(ex, "База данных ещё не готова, повтор через 2 секунды (попытка {Attempt}).", attempt);
                    await Task.Delay(TimeSpan.FromSeconds(2));
                }
            }
        }
    }
}
