using BankApi.Models;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Services;

public static class CardNumberGenerator
{
    public static async Task<string> GenerateUniqueAsync(BankingDbContext context)
    {
        while (true)
        {
            var cardNumber = "2200" + Random.Shared
                .NextInt64(0, 1_000_000_000_000)
                .ToString("D12");

            var exists = await context.Accounts
                .AnyAsync(a => a.CardNumber == cardNumber);

            if (!exists)
                return cardNumber;
        }
    }
}
