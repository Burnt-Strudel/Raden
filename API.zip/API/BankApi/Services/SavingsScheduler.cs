﻿using BankApi.Models;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Services
{
    public class SavingsScheduler : BackgroundService
    {
        private readonly IServiceProvider _services;
        public SavingsScheduler(IServiceProvider services) => _services = services;

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                
                await Task.Delay(TimeSpan.FromDays(1), stoppingToken);

                if (DateTime.Now.Day == 1) 
                {
                    using var scope = _services.CreateScope();
                    var context = scope.ServiceProvider.GetRequiredService<BankingDbContext>();

                    var savingsAccounts = await context.Accounts
                        .Where(a => a.AccountType == "savings" && a.Status == "active")
                        .ToListAsync(stoppingToken);

                    foreach (var acc in savingsAccounts)
                    {
                        decimal interest = acc.Balance * 0.05m;
                        if (interest <= 0) continue;

                        acc.Balance += interest;

                        context.Transactions.Add(new Transaction
                        {
                            FromAccountId = null,
                            ToAccountId = acc.Id,
                            UserId = acc.UserId,
                            Amount = interest,
                            TransactionType = "interest", 
                            Status = "completed",
                            Description = "Ежемесячные 5% на остаток накопительного счета"
                        });
                    }
                    await context.SaveChangesAsync(stoppingToken);
                }
            }
        }
    }
}
