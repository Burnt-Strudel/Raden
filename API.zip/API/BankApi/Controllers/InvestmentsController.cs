using BankApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InvestmentsController : ControllerBase
    {
        private readonly BankingDbContext _context;

        public InvestmentsController(BankingDbContext context)
        {
            _context = context;
        }

        [HttpGet("quotes")]
        public async Task<IActionResult> GetQuotes()
        {
            var securities = await _context.Securities
                .OrderBy(s => s.Kind == "stock" ? 0 : s.Kind == "metal" ? 1 : 2)
                .ThenBy(s => s.Name)
                .ToListAsync();

            return Ok(securities.Select(ToQuote));
        }

        [HttpGet("portfolio/{accountId:int}")]
        public async Task<IActionResult> GetPortfolio(int accountId)
        {
            var account = await _context.Accounts.FindAsync(accountId);
            if (account == null) return NotFound("Счёт не найден.");
            if (account.AccountType != "investment")
                return BadRequest("Счёт не является инвестиционным.");

            var holdings = await _context.InvestmentHoldings
                .Include(h => h.Security)
                .Where(h => h.AccountId == accountId && h.Quantity > 0)
                .ToListAsync();

            var items = holdings.Select(h =>
            {
                var price = h.Security.Price;
                var value = Math.Round(h.Quantity * price, 2);
                return new InvestmentHoldingDto
                {
                    SecurityId = h.SecurityId,
                    Ticker = h.Security.Ticker,
                    Name = h.Security.Name,
                    Kind = h.Security.Kind,
                    Quantity = h.Quantity,
                    AvgPrice = h.AvgPrice,
                    Unit = UnitLabel(h.Security),
                    CurrentPrice = price,
                    Value = value,
                    Profit = Math.Round(value - h.Quantity * h.AvgPrice, 2)
                };
            })
            .OrderByDescending(h => h.Value)
            .ToList();

            var holdingsValue = items.Sum(h => h.Value);

            return Ok(new InvestmentPortfolioDto
            {
                AccountId = account.Id,
                Balance = account.Balance,
                HoldingsValue = holdingsValue,
                TotalValue = account.Balance + holdingsValue,
                Holdings = items
            });
        }

        [HttpPost("buy")]
        public async Task<IActionResult> Buy([FromBody] InvestmentOrderDto dto)
        {
            if (dto.Quantity <= 0)
                return BadRequest("Количество должно быть больше нуля.");

            var account = await _context.Accounts.FindAsync(dto.AccountId);
            var invalidAccount = ValidateAccount(account);
            if (invalidAccount != null) return invalidAccount;

            var security = await _context.Securities.FindAsync(dto.SecurityId);
            if (security == null) return NotFound("Инструмент не найден.");

            var total = Math.Round(security.Price * dto.Quantity, 2);
            if (total <= 0) return BadRequest("Сумма сделки слишком мала.");

            if (account!.Balance < total)
                return BadRequest("Недостаточно средств на инвестиционном счёте. Пополните счёт переводом.");

            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                account.Balance -= total;

                var holding = await _context.InvestmentHoldings
                    .FirstOrDefaultAsync(h => h.AccountId == account.Id && h.SecurityId == security.Id);

                if (holding == null)
                {
                    holding = new InvestmentHolding
                    {
                        AccountId = account.Id,
                        SecurityId = security.Id,
                        Quantity = dto.Quantity,
                        AvgPrice = security.Price
                    };
                    _context.InvestmentHoldings.Add(holding);
                }
                else
                {
                    var newQuantity = holding.Quantity + dto.Quantity;
                    holding.AvgPrice = Math.Round(
                        (holding.Quantity * holding.AvgPrice + total) / newQuantity, 4);
                    holding.Quantity = newQuantity;
                }

                _context.InvestmentOrders.Add(new InvestmentOrder
                {
                    AccountId = account.Id,
                    SecurityId = security.Id,
                    OrderType = "buy",
                    Quantity = dto.Quantity,
                    Price = security.Price,
                    Total = total
                });

                _context.Transactions.Add(new Transaction
                {
                    FromAccountId = account.Id,
                    UserId = account.UserId,
                    Amount = total,
                    TransactionType = "investment",
                    Status = "completed",
                    Description = $"Покупка {security.Ticker} ({security.Name}), {FormatQuantity(dto.Quantity)} {UnitLabel(security)}"
                });

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                return Ok(new InvestmentOrderResultDto
                {
                    Message = $"Куплено {security.Ticker}: {FormatQuantity(dto.Quantity)} {UnitLabel(security)}.",
                    Price = security.Price,
                    Quantity = dto.Quantity,
                    Total = total,
                    AccountBalance = account.Balance
                });
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        [HttpPost("sell")]
        public async Task<IActionResult> Sell([FromBody] InvestmentOrderDto dto)
        {
            if (dto.Quantity <= 0)
                return BadRequest("Количество должно быть больше нуля.");

            var account = await _context.Accounts.FindAsync(dto.AccountId);
            var invalidAccount = ValidateAccount(account);
            if (invalidAccount != null) return invalidAccount;

            var security = await _context.Securities.FindAsync(dto.SecurityId);
            if (security == null) return NotFound("Инструмент не найден.");

            var holding = await _context.InvestmentHoldings
                .FirstOrDefaultAsync(h => h.AccountId == account!.Id && h.SecurityId == security.Id);

            if (holding == null || holding.Quantity < dto.Quantity)
                return BadRequest("На счёте недостаточно этого инструмента для продажи.");

            var total = Math.Round(security.Price * dto.Quantity, 2);

            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                account!.Balance += total;
                holding.Quantity -= dto.Quantity;

                if (holding.Quantity <= 0)
                    _context.InvestmentHoldings.Remove(holding);

                _context.InvestmentOrders.Add(new InvestmentOrder
                {
                    AccountId = account.Id,
                    SecurityId = security.Id,
                    OrderType = "sell",
                    Quantity = dto.Quantity,
                    Price = security.Price,
                    Total = total
                });

                _context.Transactions.Add(new Transaction
                {
                    ToAccountId = account.Id,
                    UserId = account.UserId,
                    Amount = total,
                    TransactionType = "investment",
                    Status = "completed",
                    Description = $"Продажа {security.Ticker} ({security.Name}), {FormatQuantity(dto.Quantity)} {UnitLabel(security)}"
                });

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                return Ok(new InvestmentOrderResultDto
                {
                    Message = $"Продано {security.Ticker}: {FormatQuantity(dto.Quantity)} {UnitLabel(security)}.",
                    Price = security.Price,
                    Quantity = dto.Quantity,
                    Total = total,
                    AccountBalance = account.Balance
                });
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        private IActionResult? ValidateAccount(Account? account)
        {
            if (account == null) return NotFound("Счёт не найден.");
            if (account.AccountType != "investment")
                return BadRequest("Операции доступны только для инвестиционного счёта.");
            if (account.Status != "active")
                return BadRequest("Инвестиционный счёт заблокирован или закрыт.");
            return null;
        }

        private static InvestmentQuoteDto ToQuote(Security security)
        {
            var change = Math.Round(security.Price - security.PrevPrice, 4);
            var changePercent = security.PrevPrice > 0
                ? Math.Round(change / security.PrevPrice * 100m, 2)
                : 0m;

            return new InvestmentQuoteDto
            {
                Id = security.Id,
                Ticker = security.Ticker,
                Name = security.Name,
                Kind = security.Kind,
                Price = security.Price,
                PrevPrice = security.PrevPrice,
                Change = change,
                ChangePercent = changePercent,
                Unit = security.Unit,
                Source = security.Source,
                UpdatedAt = security.UpdatedAt
            };
        }

        internal static string UnitLabel(Security security) => security.Kind switch
        {
            "stock" => "шт",
            "metal" => "г",
            _ => "ед."
        };

        private static string FormatQuantity(decimal quantity) =>
            quantity == Math.Truncate(quantity)
                ? quantity.ToString("0")
                : quantity.ToString("0.####");
    }
}
