﻿using BankApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionsController : ControllerBase
    {
        private readonly BankingDbContext _context;
        public TransactionsController(BankingDbContext context) => _context = context;

        [HttpGet("{userId}")]
        public async Task<IActionResult> GetUserHistory(int userId)
        {
            var history = await _context.Transactions
                .Where(t => t.UserId == userId)
                .OrderByDescending(t => t.CreatedAt)
                .ToListAsync();

            return Ok(history);
        }
    }
}
