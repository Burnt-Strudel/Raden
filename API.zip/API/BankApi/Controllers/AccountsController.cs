using BankApi.Models;
using BankApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountsController : ControllerBase
    {
        private readonly BankingDbContext _context;

        public AccountsController(BankingDbContext context)
        {
            _context = context;
        }

        [HttpGet("{userId:int}")]
        public async Task<IActionResult> GetAccounts(int userId)
        {
            var accounts = await _context.Accounts
                .Where(a => a.UserId == userId && a.Status == "active")
                .Select(a => new AccountDto(
                    a.Id,
                    a.AccountNumber,
                    a.CardNumber,
                    a.UserId,
                    a.AccountType,
                    a.Balance,
                    a.Currency,
                    a.Status))
                .ToListAsync();

            return Ok(accounts);
        }

        [HttpGet("recipient-by-phone")]
        public async Task<IActionResult> FindRecipientByPhone([FromQuery] string phone)
        {
            var normalizedInput = NormalizeRussianPhone(phone);
            if (normalizedInput == null)
                return BadRequest("Введите корректный российский номер телефона.");

            var users = await _context.Users
                .Where(u => u.Status == "active" && u.Phone != null)
                .Select(u => new
                {
                    u.Id,
                    u.Phone,
                    u.FirstName,
                    u.LastName
                })
                .ToListAsync();

            var user = users.FirstOrDefault(u =>
                NormalizeRussianPhone(u.Phone) == normalizedInput);

            if (user == null)
                return NotFound("Пользователь с таким номером не найден.");

            var recipientAccount = await _context.Accounts
                .Where(a => a.UserId == user.Id && a.Status == "active")
                .OrderBy(a => a.AccountType == "regular" ? 0 : 1)
                .ThenBy(a => a.Id)
                .FirstOrDefaultAsync();

            if (recipientAccount == null)
                return NotFound("У пользователя нет активного банковского счёта.");

            return Ok(new PhoneRecipientDto
            {
                UserId = user.Id,
                FirstName = user.FirstName ?? string.Empty,
                LastName = user.LastName ?? string.Empty,
                Phone = normalizedInput,
                AccountId = recipientAccount.Id,
                AccountNumber = recipientAccount.AccountNumber,
                AccountType = recipientAccount.AccountType
            });
        }

        [HttpGet("recipient-by-card")]
        public async Task<IActionResult> FindRecipientByCard([FromQuery] string cardNumber)
        {
            var normalizedCard = NormalizeCardNumber(cardNumber);
            if (normalizedCard == null)
                return BadRequest("Введите корректный номер карты из 16 цифр.");

            var account = await _context.Accounts
                .Include(a => a.User)
                .FirstOrDefaultAsync(a => a.CardNumber == normalizedCard);

            if (account == null || account.Status != "active")
                return NotFound("Карта не найдена или счёт по ней закрыт.");

            if (account.User == null)
                return NotFound("Владелец карты не найден.");

            return Ok(new CardRecipientDto
            {
                UserId = account.UserId,
                FirstName = account.User.FirstName ?? string.Empty,
                LastName = account.User.LastName ?? string.Empty,
                Phone = account.User.Phone ?? string.Empty,
                MaskedCardNumber = MaskCardNumber(account.CardNumber),
                AccountId = account.Id,
                AccountNumber = account.AccountNumber,
                AccountType = account.AccountType
            });
        }

        [HttpPost("transfer-by-phone")]
        public async Task<IActionResult> MakeTransferByPhone([FromBody] TransferByPhoneDto dto)
        {
            if (dto == null || dto.Amount <= 0)
                return BadRequest("Сумма перевода должна быть больше нуля.");

            var normalizedPhone = NormalizeRussianPhone(dto.Phone);
            if (normalizedPhone == null)
                return BadRequest("Некорректный номер телефона получателя.");

            var source = await _context.Accounts
                .FirstOrDefaultAsync(a => a.Id == dto.FromAccountId);

            if (source == null || source.Status != "active")
                return BadRequest("Счёт списания не найден, заблокирован или закрыт.");

            if (source.Balance < dto.Amount)
                return BadRequest("Недостаточно средств на счёте.");

            var users = await _context.Users
                .Where(u => u.Status == "active" && u.Phone != null)
                .Select(u => new { u.Id, u.Phone })
                .ToListAsync();

            var recipient = users.FirstOrDefault(u =>
                NormalizeRussianPhone(u.Phone) == normalizedPhone);

            if (recipient == null)
                return NotFound("Пользователь с таким номером не найден.");

            if (recipient.Id == source.UserId)
                return BadRequest("Нельзя переводить деньги самому себе.");

            var target = await _context.Accounts
                .Where(a => a.UserId == recipient.Id && a.Status == "active")
                .OrderBy(a => a.AccountType == "regular" ? 0 : 1)
                .ThenBy(a => a.Id)
                .FirstOrDefaultAsync();

            if (target == null)
                return NotFound("У получателя нет активного банковского счёта.");

            if (source.Currency != target.Currency)
                return BadRequest("Валюта счетов не совпадает. Перевод невозможен.");

            var description = string.IsNullOrWhiteSpace(dto.Description)
                ? $"Перевод по телефону {normalizedPhone}"
                : dto.Description.Trim();

            var result = await ExecuteTransferAsync(source, target, dto.Amount, description);
            return Ok(result);
        }

        [HttpPost("transfer-by-card")]
        public async Task<IActionResult> MakeTransferByCard([FromBody] TransferByCardDto dto)
        {
            if (dto == null || dto.Amount <= 0)
                return BadRequest("Сумма перевода должна быть больше нуля.");

            var normalizedCard = NormalizeCardNumber(dto.CardNumber);
            if (normalizedCard == null)
                return BadRequest("Введите корректный номер карты из 16 цифр.");

            var source = await _context.Accounts
                .FirstOrDefaultAsync(a => a.Id == dto.FromAccountId);

            if (source == null || source.Status != "active")
                return BadRequest("Счёт списания не найден, заблокирован или закрыт.");

            if (source.Balance < dto.Amount)
                return BadRequest("Недостаточно средств на счёте.");

            var target = await _context.Accounts
                .FirstOrDefaultAsync(a => a.CardNumber == normalizedCard);

            if (target == null || target.Status != "active")
                return NotFound("Карта получателя не найдена или неактивна.");

            if (target.UserId == source.UserId)
                return BadRequest("Для перевода на свою карту используйте перевод между счетами.");

            if (source.Currency != target.Currency)
                return BadRequest("Валюта счетов не совпадает. Перевод невозможен.");

            var description = string.IsNullOrWhiteSpace(dto.Description)
                ? $"Перевод на карту {MaskCardNumber(normalizedCard)}"
                : dto.Description.Trim();

            var result = await ExecuteTransferAsync(source, target, dto.Amount, description);
            return Ok(result);
        }

        [HttpPost("transfer")]
        public async Task<IActionResult> MakeTransfer([FromBody] TransferDto dto)
        {
            if (dto.Amount <= 0)
                return BadRequest("Сумма перевода должна быть больше нуля.");

            var source = await _context.Accounts.FindAsync(dto.FromAccountId);
            if (source == null || source.Status != "active")
                return BadRequest("Счёт списания недоступен или заблокирован.");

            if (source.Balance < dto.Amount)
                return BadRequest("Недостаточно средств на счёте.");

            var target = await _context.Accounts
                .FirstOrDefaultAsync(a => a.AccountNumber == dto.TargetAccountNumber);

            if (target == null || target.Status != "active")
                return BadRequest("Счёт получателя не найден или неактивен.");

            if (target.Id == source.Id)
                return BadRequest("Выберите другой счёт для перевода.");

            if (source.Currency != target.Currency)
                return BadRequest("Валюта счетов не совпадает.");

            var result = await ExecuteTransferAsync(source, target, dto.Amount, dto.Description);
            return Ok(result);
        }

        [HttpPost("request-block/{accountId:int}/{userId:int}")]
        public async Task<IActionResult> RequestBlock(int accountId, int userId)
        {
            var account = await _context.Accounts.FindAsync(accountId);
            if (account == null) return NotFound("Счёт не найден.");
            if (account.UserId != userId) return Forbid();
            if (account.Status != "active") return BadRequest("Счёт не активен.");

            var request = new FreezeRequest
            {
                AccountId = accountId,
                UserId = userId,
                Reason = "Запрос пользователя на блокировку счёта",
                Status = "pending"
            };

            _context.FreezeRequests.Add(request);
            await _context.SaveChangesAsync();
            return Ok(true);
        }

        [HttpDelete("{accountId:int}")]
        public async Task<IActionResult> CloseAccount(int accountId)
        {
            var account = await _context.Accounts.FindAsync(accountId);
            if (account == null) return NotFound("Счёт не найден.");
            if (account.Balance != 0)
                return BadRequest("Баланс счёта должен быть равен 0 рублей для его закрытия.");

            account.Status = "closed";
            await _context.SaveChangesAsync();
            return Ok(true);
        }
        [HttpPost("regular/open/{userId:int}")]
        public async Task<IActionResult> OpenRegular(int userId)
        {
            var userExists = await _context.Users
                .AnyAsync(u => u.Id == userId && u.Status == "active");

            if (!userExists)
                return NotFound("Пользователь не найден или заблокирован.");

            var existingAccount = await _context.Accounts
                .AnyAsync(a =>
                    a.UserId == userId &&
                    a.AccountType == "regular" &&
                    a.Status == "active");

            if (existingAccount)
                return BadRequest("У вас уже есть активный обычный счёт.");

            var account = new Account
            {
                AccountNumber = await AccountNumberGenerator.GenerateUniqueAsync(_context, "40817810"),
                CardNumber = await CardNumberGenerator.GenerateUniqueAsync(_context),
                UserId = userId,
                AccountType = "regular",
                Balance = 0m,
                Currency = "RUB",
                Status = "active"
            };

            _context.Accounts.Add(account);

            await _context.SaveChangesAsync();

            return Ok(true);
        }

        [HttpPost("savings/open/{userId:int}")]
        public async Task<IActionResult> OpenSavings(int userId)
        {
            var userExists = await _context.Users.AnyAsync(u => u.Id == userId && u.Status == "active");
            if (!userExists) return NotFound("Пользователь не найден или заблокирован.");

            var app = new Application
            {
                UserId = userId,
                Type = "account_open",
                Status = "approved",
                Description = "Открытие накопительного счёта пользователя через приложение"
            };
            _context.Applications.Add(app);
            await _context.SaveChangesAsync();

            var savingsAccount = new Account
            {
                AccountNumber = await AccountNumberGenerator.GenerateUniqueAsync(_context, "40820810"),
                CardNumber = await CardNumberGenerator.GenerateUniqueAsync(_context),
                UserId = userId,
                AccountType = "savings",
                Balance = 0m,
                Currency = "RUB",
                Status = "active"
            };

            _context.Accounts.Add(savingsAccount);
            _context.Deposits.Add(new Deposit
            {
                Account = savingsAccount,
                Amount = 0m,
                InterestRate = 5m,
                StartDate = DateOnly.FromDateTime(DateTime.UtcNow),
                Status = "active"
            });

            await _context.SaveChangesAsync();
            return Ok(true);
        }

        [HttpPost("investment/open/{userId:int}")]
        public async Task<IActionResult> OpenInvestment(int userId)
        {
            var userExists = await _context.Users.AnyAsync(u => u.Id == userId && u.Status == "active");
            if (!userExists) return NotFound("Пользователь не найден или заблокирован.");

            var existingAccount = await _context.Accounts
                .AnyAsync(a =>
                    a.UserId == userId &&
                    a.AccountType == "investment" &&
                    a.Status == "active");

            if (existingAccount)
                return BadRequest("У вас уже есть активный инвестиционный счёт.");

            var account = new Account
            {
                AccountNumber = await AccountNumberGenerator.GenerateUniqueAsync(_context, "40817810"),
                CardNumber = await CardNumberGenerator.GenerateUniqueAsync(_context),
                UserId = userId,
                AccountType = "investment",
                Balance = 0m,
                Currency = "RUB",
                Status = "active"
            };

            _context.Accounts.Add(account);
            await _context.SaveChangesAsync();

            return Ok(true);
        }

        private async Task<TransferResultDto> ExecuteTransferAsync(
            Account source,
            Account target,
            decimal amount,
            string description)
        {
            var isOwnTransfer = source.UserId == target.UserId;

            if (!isOwnTransfer && amount > 10000m)
            {
                _context.Transactions.Add(new Transaction
                {
                    FromAccountId = source.Id,
                    ToAccountId = target.Id,
                    UserId = source.UserId,
                    Amount = amount,
                    TransactionType = "transfer",
                    Status = "pending",
                    Description = $"[Ожидает одобрения (>10к)] {description}"
                });

                await _context.SaveChangesAsync();

                return new TransferResultDto
                {
                    RequiresApproval = true,
                    Message = "Сумма превышает 10 000 ₽. Перевод отправлен менеджеру."
                };
            }

            await using var dbTransaction = await _context.Database.BeginTransactionAsync();
            try
            {
                source.Balance -= amount;
                target.Balance += amount;

                _context.Transactions.Add(new Transaction
                {
                    FromAccountId = source.Id,
                    ToAccountId = target.Id,
                    UserId = source.UserId,
                    Amount = amount,
                    TransactionType = "transfer",
                    Status = "completed",
                    Description = description
                });

                await _context.SaveChangesAsync();
                await dbTransaction.CommitAsync();

                return new TransferResultDto
                {
                    RequiresApproval = false,
                    Message = "Перевод успешно выполнен."
                };
            }
            catch
            {
                await dbTransaction.RollbackAsync();
                throw;
            }
        }

        private static string? NormalizeCardNumber(string? cardNumber)
        {
            if (string.IsNullOrWhiteSpace(cardNumber)) return null;

            var digits = new string(cardNumber.Where(char.IsDigit).ToArray());
            return digits.Length == 16 ? digits : null;
        }

        private static string MaskCardNumber(string cardNumber) =>
            $"•••• {cardNumber[^4..]}";

        private static string? NormalizeRussianPhone(string? phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return null;

            var digits = new string(phone.Where(c => c >= '0' && c <= '9').ToArray());

            if (digits.Length == 10)
                digits = "7" + digits;
            else if (digits.Length == 11 && digits[0] == '8')
                digits = "7" + digits[1..];

            if (digits.Length != 11 || digits[0] != '7')
                return null;

            return digits;
        }
    }
}
