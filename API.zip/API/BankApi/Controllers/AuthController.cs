﻿using BankApi.Models;
using BankApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly BankingDbContext _context;
        public AuthController(BankingDbContext context) => _context = context;

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto dto)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == dto.Username && u.PasswordHash == dto.Password);

            if (user == null) return Unauthorized("Неверный логин или пароль");
            if (user.Status == "blocked") return Forbid("Аккаунт заблокирован менеджером.");
            if (user.Status == "deleted") return Forbid("Аккаунт удален.");

            return Ok(new UserDto(
                user.Id,
                user.Username,
                user.Email,
                user.Phone,
                user.FirstName,
                user.LastName,
                user.Role,
                user.Status));
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto dto)
        {
            if (await _context.Users.AnyAsync(u => u.Username == dto.Username || u.Email == dto.Email))
                return BadRequest("Логин или Email уже заняты.");

            var user = new User
            {
                Username = dto.Username,
                PasswordHash = dto.Password, 
                Email = dto.Email,
                Phone = dto.Phone,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Role = "client",
                Status = "active"
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            var account = new Account
            {
                AccountNumber = await AccountNumberGenerator.GenerateUniqueAsync(_context, "40817810"),
                CardNumber = await CardNumberGenerator.GenerateUniqueAsync(_context),
                UserId = user.Id,
                AccountType = "regular",
                Balance = 0.00m,
                Currency = "RUB",
                Status = "active"
            };

            _context.Accounts.Add(account);
            await _context.SaveChangesAsync();

            return Ok(true);
        }
    }
}
