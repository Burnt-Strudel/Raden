﻿using BankApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BankApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ManagerController : ControllerBase
    {
        private readonly BankingDbContext _context;
        public ManagerController(BankingDbContext context) => _context = context;

        [HttpGet("pending-actions")]
        public async Task<IActionResult> GetPendingActions()
        {
            var pendingTransRaw = await _context.Transactions
                .Where(t => t.Status == "pending")
                .ToListAsync();

            var pendingTrans = pendingTransRaw.Select(t => {
                var accountNum = _context.Accounts.Find(t.FromAccountId)?.AccountNumber ?? "0000";
                var maskedAccount = accountNum.Length > 4 ? $"*{accountNum.Substring(accountNum.Length - 4)}" : accountNum;

                return new
                {
                    Id = t.Id,
                    Type = "Transfer",
                    Info = $"[Перевод] Счет списания: {maskedAccount} | Сумма: {t.Amount:N2} ₽"
                };
            }).ToList();

            var pendingFreezesRaw = await _context.FreezeRequests
                .Where(f => f.Status == "pending")
                .ToListAsync();

            var pendingFreezes = pendingFreezesRaw.Select(f => {
                var accountNum = _context.Accounts.Find(f.AccountId)?.AccountNumber ?? "0000";
                var maskedAccount = accountNum.Length > 4 ? $"*{accountNum.Substring(accountNum.Length - 4)}" : accountNum;

                return new
                {
                    Id = f.Id,
                    Type = "Freeze",
                    Info = $"[Блокировка] Запрос на заморозку счета {maskedAccount}"
                };
            }).ToList();

            return Ok(new { Transfers = pendingTrans, Freezes = pendingFreezes });
        }

        [HttpPost("process-transfer")]
        public async Task<IActionResult> ProcessTransfer([FromBody] ManagerActionDto dto)
        {
            var trans = await _context.Transactions.FindAsync(dto.RequestId);
            if (trans == null || trans.Status != "pending") return BadRequest("Транзакция не найдена.");

            if (dto.Approve)
            {
                var source = await _context.Accounts.FindAsync(trans.FromAccountId);
                var target = await _context.Accounts.FindAsync(trans.ToAccountId);

                if (source != null && target != null && source.Balance >= trans.Amount)
                {
                    source.Balance -= trans.Amount;
                    target.Balance += trans.Amount;
                    trans.Status = "completed";
                }
                else
                {
                    trans.Status = "rejected";
                }
            }
            else
            {
                trans.Status = "rejected";
            }

            await _context.SaveChangesAsync();
            return Ok(true);
        }

        [HttpPost("process-freeze")]
        public async Task<IActionResult> ProcessFreeze([FromBody] ManagerActionDto dto)
        {
            var req = await _context.FreezeRequests.FindAsync(dto.RequestId);
            if (req == null || req.Status != "pending") return BadRequest("Запрос не найден.");

            req.Status = dto.Approve ? "approved" : "rejected";
            req.RequestedByManager = dto.ManagerUserId;

            if (dto.Approve)
            {
                var account = await _context.Accounts.FindAsync(req.AccountId);
                if (account != null) account.Status = "frozen"; 
            }

            await _context.SaveChangesAsync();
            return Ok(true);
        }
    }
}
