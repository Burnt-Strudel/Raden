CREATE DATABASE IF NOT EXISTS banking_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE banking_db;

CREATE TABLE users (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL DEFAULT '',
  phone VARCHAR(32) NOT NULL DEFAULT '',
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  role ENUM('client','manager','admin') NOT NULL DEFAULT 'client',
  status ENUM('active','blocked') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB;

CREATE TABLE clients (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  passport VARCHAR(32) NOT NULL,
  address VARCHAR(255) NOT NULL,
  birth_date DATE NOT NULL,
  CONSTRAINT fk_clients_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE accounts (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  account_number VARCHAR(34) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  account_type ENUM('regular','savings') NOT NULL DEFAULT 'regular',
  balance DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  currency CHAR(3) NOT NULL DEFAULT 'RUB',
  status ENUM('active','closed','frozen') NOT NULL DEFAULT 'active',
  CONSTRAINT fk_accounts_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE applications (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  application_type VARCHAR(40) NOT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  description TEXT,
  CONSTRAINT fk_applications_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE deposits (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  account_id INT NOT NULL,
  amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  interest_rate DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  start_date DATE NOT NULL,
  end_date DATE NULL,
  status ENUM('active','closed') NOT NULL DEFAULT 'active',
  CONSTRAINT fk_deposits_account FOREIGN KEY (account_id) REFERENCES accounts(id)
) ENGINE=InnoDB;

CREATE TABLE freeze_requests (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  account_id INT NOT NULL,
  user_id INT NOT NULL,
  reason TEXT NOT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  reviewed_by INT NULL,
  CONSTRAINT fk_freeze_account FOREIGN KEY (account_id) REFERENCES accounts(id),
  CONSTRAINT fk_freeze_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_freeze_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE operation_history (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  account_id INT NOT NULL,
  operation_type VARCHAR(100) NOT NULL,
  details TEXT,
  CONSTRAINT fk_history_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_history_account FOREIGN KEY (account_id) REFERENCES accounts(id)
) ENGINE=InnoDB;

CREATE TABLE transactions (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  from_account_id INT NULL,
  to_account_id INT NULL,
  user_id INT NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  transaction_type ENUM('deposit','withdrawal','transfer','interest') NOT NULL,
  status ENUM('pending','completed','rejected') NOT NULL DEFAULT 'pending',
  description TEXT,
  CONSTRAINT fk_transactions_from FOREIGN KEY (from_account_id) REFERENCES accounts(id),
  CONSTRAINT fk_transactions_to FOREIGN KEY (to_account_id) REFERENCES accounts(id),
  CONSTRAINT fk_transactions_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;
