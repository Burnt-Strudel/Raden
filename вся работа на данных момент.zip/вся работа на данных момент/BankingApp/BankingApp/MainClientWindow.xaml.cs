
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using BankingApp.Models;

namespace BankingApp
{
    public partial class MainClientWindow : Window
    {
        private readonly User _user;

        public Account? SelectedAccount { get; private set; }

        public MainClientWindow(User user)
        {
            InitializeComponent();

            _user = user;

            string name = !string.IsNullOrWhiteSpace(user.FirstName)
                ? $"{user.FirstName} {user.LastName}".Trim()
                : user.Username;

            TxtUserName.Text = name;

            RefreshData();
        }

        public async void RefreshData()
        {
            await RefreshDataAsync();
        }

        private async Task RefreshDataAsync()
        {
            try
            {
                var accounts = await ApiClient.GetAccountsAsync(_user.Id);

                LstAccounts.ItemsSource = accounts;
                LstAccounts.SelectedItem = null;

                PanelActions.Visibility = Visibility.Collapsed;
                SelectedAccount = null;
            }
            catch (Exception ex)
            {
                BankMessageBox.Show(
                    "Не удалось загрузить счета: " + ex.Message,
                    "Ошибка");
            }
        }

        private void LstAccounts_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (LstAccounts.SelectedItem is Account acc)
            {
                SelectedAccount = acc;

                TxtBalance.Text =
                    $"Номер: {acc.AccountNumber}\n" +
                    $"Доступно: {acc.Balance:N2} ₽\n" +
                    $"Тип: {acc.AccountType} · {acc.Status}";

                PanelActions.Visibility = Visibility.Visible;

                BtnGoTransfer.IsEnabled = true;
                BtnTransferPhone.IsEnabled = true;
                BtnBlock.IsEnabled = true;
                BtnDelete.IsEnabled = true;
            }
        }

        // ПЕРЕВОД ПО НОМЕРУ КАРТЫ
        private void BtnGoTransfer_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureSelectedAccount())
                return;

            var window = new TransferWindowCard(this)
            {
                Owner = this
            };

            window.ShowDialog();
        }

        // ПЕРЕВОД ПО ТЕЛЕФОНУ
        private void BtnTransferPhone_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureSelectedAccount())
                return;

            var window = new TransferWindow(this)
            {
                Owner = this
            };

            window.ShowDialog();
        }

        private bool EnsureSelectedAccount()
        {
            if (SelectedAccount == null && LstAccounts.Items.Count > 0)
                LstAccounts.SelectedIndex = 0;

            if (SelectedAccount == null)
            {
                BankMessageBox.Show(
                    "Сначала выберите счёт, с которого будут списаны деньги.",
                    "Перевод");

                return false;
            }

            return true;
        }

        private void BtnHistory_Click(object sender, RoutedEventArgs e)
        {
            var window = new TransactionHistoryWindow(_user.Id)
            {
                Owner = this
            };

            window.ShowDialog();
        }

        private void BtnBackToAccounts_Click(object sender, RoutedEventArgs e)
        {
            PanelActions.Visibility = Visibility.Collapsed;
            LstAccounts.SelectedItem = null;
            SelectedAccount = null;
        }

        private async void BtnCreateRegularAccount_Click(
            object sender,
            RoutedEventArgs e)
        {
            bool confirm = BankMessageBox.ShowConfirm(
                "Создать новый обычный счёт?",
                "Новый счёт");

            if (!confirm)
                return;

            bool success = await ApiClient.OpenRegularAccountAsync(_user.Id);

            if (success)
            {
                BankMessageBox.Show(
                    "Новый счёт успешно создан!",
                    "Успех");

                await RefreshDataAsync();
            }
            else
            {
                BankMessageBox.Show(
                    "Не удалось создать счёт. Проверьте работу API.",
                    "Ошибка");
            }
        }

        private async void BtnGoSavings_Click(
            object sender,
            RoutedEventArgs e)
        {
            bool confirm = BankMessageBox.ShowConfirm(
                "Открыть новый накопительный счёт под 5% годовых?",
                "Накопительный счёт");

            if (!confirm)
                return;

            bool success = await ApiClient.OpenSavingsAccountAsync(_user.Id);

            if (success)
            {
                BankMessageBox.Show(
                    "Накопительный счёт успешно создан!",
                    "Успех");

                await RefreshDataAsync();
            }
            else
            {
                BankMessageBox.Show(
                    "Не удалось открыть счёт. Проверьте API.",
                    "Ошибка");
            }
        }

        private async void BtnBlock_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (SelectedAccount == null)
                return;

            bool success = await ApiClient.RequestBlockAccountAsync(
                SelectedAccount.Id,
                _user.Id);

            if (success)
            {
                BankMessageBox.Show(
                    "Заявка на блокировку отправлена менеджеру.",
                    "Заявка принята");
            }
            else
            {
                BankMessageBox.Show(
                    "Ошибка при отправке заявки.",
                    "Ошибка");
            }
        }

        private async void BtnDelete_Click(
            object sender,
            RoutedEventArgs e)
        {
            if (SelectedAccount == null)
                return;

            if (SelectedAccount.Balance != 0)
            {
                BankMessageBox.Show(
                    "Для закрытия счёта баланс должен быть 0.00 ₽",
                    "Ошибка");

                return;
            }

            bool confirm = BankMessageBox.ShowConfirm(
                "Закрыть этот счёт?",
                "Внимание");

            if (!confirm)
                return;

            bool success = await ApiClient.DeleteAccountAsync(
                SelectedAccount.Id);

            if (success)
            {
                BankMessageBox.Show(
                    "Счёт успешно закрыт.",
                    "Готово");

                await RefreshDataAsync();
            }
            else
            {
                BankMessageBox.Show(
                    "Не удалось закрыть счёт.",
                    "Ошибка");
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            new AuthWindow().Show();
            Close();
        }
    }
}
