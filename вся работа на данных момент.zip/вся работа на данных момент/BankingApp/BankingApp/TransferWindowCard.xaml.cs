﻿
using System;
using System.Globalization;
using System.Windows;
using BankingApp.Models;

namespace BankingApp
{
    public partial class TransferWindowCard : Window
    {
        private readonly MainClientWindow _parent;
        private bool _busy;

        public TransferWindowCard(MainClientWindow parent)
        {
            InitializeComponent();

            _parent = parent;

            if (_parent.SelectedAccount == null)
            {
                Loaded += (_, _) => Close();
                return;
            }

            TxtFrom.Text =
                $"Счёт списания: {_parent.SelectedAccount.AccountNumber}\n" +
                $"Доступно: {_parent.SelectedAccount.Balance:N2} ₽";
        }

        private async void BtnSend_Click(object sender, RoutedEventArgs e)
        {
            if (_busy)
                return;

            if (_parent.SelectedAccount == null)
                return;

            string cardNumber = TxtTarget.Text.Trim();
            string amountText = TxtSum.Text.Trim().Replace(',', '.');

            if (string.IsNullOrWhiteSpace(cardNumber))
            {
                BankMessageBox.Show(
                    "Введите номер карты получателя.",
                    "Перевод");

                return;
            }

            if (!decimal.TryParse(
                amountText,
                NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture,
                out decimal amount) || amount <= 0)
            {
                BankMessageBox.Show(
                    "Введите корректную сумму перевода.",
                    "Ошибка");

                return;
            }

            if (amount > _parent.SelectedAccount.Balance)
            {
                BankMessageBox.Show(
                    "Недостаточно средств на выбранном счёте.",
                    "Ошибка");

                return;
            }

            bool confirm = BankMessageBox.ShowConfirm(
                $"Номер карты: {cardNumber}\n" +
                $"Сумма: {amount:N2} ₽\n\n" +
                "Подтвердить перевод?",
                "Подтверждение");

            if (!confirm)
                return;

            _busy = true;
            BtnSend.IsEnabled = false;

            try
            {
                var dto = new TransferDto
                {
                    FromAccountId = _parent.SelectedAccount.Id,
                    TargetAccountNumber = cardNumber,
                    Amount = amount,
                    Description = $"Перевод на карту {cardNumber}"
                };

                bool success = await ApiClient.MakeTransferAsync(dto);

                if (!success)
                {
                    BankMessageBox.Show(
                        "Сервер отклонил перевод. Проверьте номер карты и баланс.",
                        "Ошибка перевода");

                    return;
                }

                BankMessageBox.Show(
                    amount > 10000
                        ? "Перевод принят и ожидает проверки менеджером."
                        : "Перевод успешно выполнен!",
                    "Результат");

                _parent.RefreshData();
                Close();
            }
            catch (Exception ex)
            {
                BankMessageBox.Show(
                    "Ошибка перевода: " + ex.Message,
                    "Ошибка");
            }
            finally
            {
                _busy = false;

                if (IsVisible)
                    BtnSend.IsEnabled = true;
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
