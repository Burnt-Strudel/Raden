using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RedDbApi.Data;
using RedDbApi.Models;

namespace RedDbApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class InstitutionsController : ControllerBase
{
    private readonly AppDbContext _db;
    public InstitutionsController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<List<Institution>>> GetAll() => await _db.Institutions.ToListAsync();

    [HttpGet("{id}")]
    public async Task<ActionResult<Institution>> Get(int id)
    {
        var item = await _db.Institutions.FindAsync(id);
        return item == null ? NotFound() : Ok(item);
    }

    [HttpPost]
    public async Task<ActionResult<Institution>> Create(Institution item)
    {
        _db.Institutions.Add(item);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = item.Id }, item);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Institution item)
    {
        if (id != item.Id) return BadRequest();
        _db.Entry(item).State = EntityState.Modified;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var item = await _db.Institutions.FindAsync(id);
        if (item == null) return NotFound();
        _db.Institutions.Remove(item);
        await _db.SaveChangesAsync();
        return Ok();
    }
}

[ApiController]
[Route("api/[controller]")]
public class GroupsController : ControllerBase
{
    private readonly AppDbContext _db;
    public GroupsController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<List<Group>>> GetAll() => await _db.Groups.ToListAsync();

    [HttpGet("{id}")]
    public async Task<ActionResult<Group>> Get(int id)
    {
        var item = await _db.Groups.FindAsync(id);
        return item == null ? NotFound() : Ok(item);
    }

    [HttpPost]
    public async Task<ActionResult<Group>> Create(Group item)
    {
        _db.Groups.Add(item);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = item.Id }, item);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Group item)
    {
        if (id != item.Id) return BadRequest();
        _db.Entry(item).State = EntityState.Modified;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var item = await _db.Groups.FindAsync(id);
        if (item == null) return NotFound();
        _db.Groups.Remove(item);
        await _db.SaveChangesAsync();
        return Ok();
    }
}

[ApiController]
[Route("api/[controller]")]
public class StudentsController : ControllerBase
{
    private readonly AppDbContext _db;
    public StudentsController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<List<Student>>> GetAll() => await _db.Students.ToListAsync();

    [HttpGet("{id}")]
    public async Task<ActionResult<Student>> Get(int id)
    {
        var item = await _db.Students.FindAsync(id);
        return item == null ? NotFound() : Ok(item);
    }

    [HttpPost]
    public async Task<ActionResult<Student>> Create(Student item)
    {
        _db.Students.Add(item);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = item.Id }, item);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Student item)
    {
        if (id != item.Id) return BadRequest();
        _db.Entry(item).State = EntityState.Modified;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var item = await _db.Students.FindAsync(id);
        if (item == null) return NotFound();
        _db.Students.Remove(item);
        await _db.SaveChangesAsync();
        return Ok();
    }
}

[ApiController]
[Route("api/[controller]")]
public class ExamsController : ControllerBase
{
    private readonly AppDbContext _db;
    public ExamsController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<List<Exam>>> GetAll() => await _db.Exams.ToListAsync();

    [HttpGet("{id}")]
    public async Task<ActionResult<Exam>> Get(int id)
    {
        var item = await _db.Exams.FindAsync(id);
        return item == null ? NotFound() : Ok(item);
    }

    [HttpPost]
    public async Task<ActionResult<Exam>> Create(Exam item)
    {
        _db.Exams.Add(item);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = item.Id }, item);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Exam item)
    {
        if (id != item.Id) return BadRequest();
        _db.Entry(item).State = EntityState.Modified;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var item = await _db.Exams.FindAsync(id);
        if (item == null) return NotFound();
        _db.Exams.Remove(item);
        await _db.SaveChangesAsync();
        return Ok();
    }
}