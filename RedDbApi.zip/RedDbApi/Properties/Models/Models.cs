using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RedDbApi.Models;

[Table("institutions")]
public class Institution
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("name")]
    [MaxLength(255)]
    public string Name { get; set; } = string.Empty;
}

[Table("groups_tbl")]
public class Group
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("name")]
    [MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [Column("course")]
    public int Course { get; set; }

    [Column("status")]
    [MaxLength(50)]
    public string Status { get; set; } = "активна";
}

[Table("students")]
public class Student
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("fio")]
    [MaxLength(255)]
    public string Fio { get; set; } = string.Empty;

    [Column("group_id")]
    public int? GroupId { get; set; }

    [Column("institution_id")]
    public int? InstitutionId { get; set; }

    [Column("status")]
    [MaxLength(50)]
    public string Status { get; set; } = "активен";
}

[Table("exams")]
public class Exam
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("student_id")]
    public int StudentId { get; set; }

    [Column("subject")]
    [MaxLength(255)]
    public string Subject { get; set; } = string.Empty;

    [Column("exam_date")]
    public DateTime? ExamDate { get; set; }

    [Column("grade")]
    public int? Grade { get; set; }

    [Column("status")]
    [MaxLength(50)]
    public string Status { get; set; } = "запланирован";
}